import logging
import asyncpg
import os
import asyncio
import google.generativeai as genai
from aiogram import Bot, Dispatcher, types, F, html
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandObject, StateFilter
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.fsm.storage.base import StorageKey
from dotenv import load_dotenv
from aiogram.client.default import DefaultBotProperties
from aiogram.types import (
    InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup,
    KeyboardButton, ReplyKeyboardRemove
)
from aiogram.utils.keyboard import InlineKeyboardBuilder
from datetime import datetime, timedelta, timezone
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter
from typing import Optional, Tuple, Dict, Any, List, Set, Union
from aiogram.dispatcher.middlewares.base import BaseMiddleware
import itertools
import secrets # <-- NEW: For generating secure tokens
import json
from chat.start_chat_api import start_chat_api

# --- Dummy HTTP Server Imports ---
from aiohttp import web

# --- Constants --
CATEGORIES = [
    "Relationship", "Family","Exam", "School", "Friendship",
    "Religion", "Mental", "Addiction", "Harassment", "Crush", "Health", "Trauma", "Sexual",
    "Other"
]
INTERESTS = [
       "Anime", "Manga", "Comics", "Cartoons", "Drawing", "Painting", "Photography", "Filmmaking", "Writing", "Poetry",
"Books", "Novels", "Short Stories", "Philosophy", "History", "Science", "Math", "Psychology", "Politics", "Economics",
"Movies", "TV Shows", "Series", "Theatre", "Acting", "Cinematography", "Screenwriting",
"Music", "Singing", "Instruments", "Piano", "Guitar", "Drums", "DJing", "Rap", "Dance", "Choreography",
"Gaming", "Esports", "Chess", "Puzzles", "Board Games", "Card Games", "Strategy Games", "RPG",
"Tech", "Coding", "AI", "Robotics", "Cybersecurity", "Electronics", "Gadgets", "Web Dev", "App Dev", "Blockchain",
"Sports", "Football", "Basketball", "Tennis", "Running", "Cycling", "Swimming", "Martial Arts", "Boxing", "Yoga", "Gym",
"Travel", "Adventure", "Camping", "Hiking", "Exploration", "Road Trips", "Backpacking",
"Food", "Cooking", "Baking", "Coffee", "Tea", "Wine", "Street Food", "Nutrition", "Veganism",
"Career", "Entrepreneurship", "Startups", "Business", "Finance", "Investing", "Marketing", "Networking",
"Nature", "Animals", "Birdwatching", "Gardening", "Stargazing", "Astronomy",
"Culture", "Languages", "Religion", "Traditions", "Festivals",
"Fashion", "Style", "Makeup", "Design", "DIY",
"Collecting", "Stamps", "Coins", "Sneakers", "Toys", "Figurines",
"Social Media", "Blogging", "Podcasting", "Streaming", "Vlogging"
]
GENDERS = ["Male", "Female", "Helicopter"]
CAMPUSES = ["College of Social Sciences",
  "College of Humanities, Language Studies, Journalism and Communication",
  "College of Development Studies",
  "College of Business and Economics",
  "College of Law and Governance Studies",
  "College of Education and Behavioral Studies",
  "College of Natural and Computational Sciences",
  "Skunder Boghossian College of Performing and Visual Arts",
  "College of Veterinary Medicine and Agriculture",
  "College of Health Sciences",
  "College of Technology and Built Environment (CTBE)"]

YEARS = ["1st Year", "2nd Year", "3rd Year", "4th Year", "5th Year", "6th Year", "Other"]
DEPARTMENTS = [
  "African Studies", "Archaeology and Heritage Management", "History", "Political Science",
  "Social Anthropology", "Social Work and Social Development", "Sociology", "Philosophy",
  "Amharic Language, Literature and Folklore", "Foreign Language and Literature",
  "Journalism and Communication", "Linguistics", "Oromo Language, Literature and Folklore",
  "Philology", "Teaching English as Foreign Language", "Tigrigna Language, Literature and Folklore",
  "Centre for Development Research", "Centre for Food Security Studies", "Centre for Gender Studies",
  "Centre for Population Studies", "Centre for Regional and Local Development Studies",
  "Centre for Rural Development", "Centre for Environment and Development",
  "Accounting and Finance", "Economics", "Management", "Public Administration",
  "Business Information System", "Business Leadership", "Corporate Finance", "Development Economics",
  "Digital Marketing", "Human Resource Management", "Logistics and Supply Chain Management",
  "Marketing Management", "Project Management", "School of Law", "Educational Planning and Management",
  "Psychology", "Biology", "Chemistry", "Geology", "Mathematics", "Physics", "Statistics",
  "Design", "Fine Arts", "Multimedia Theater", "Film Production", "Yared School of Music",
  "Yoftahe Nigussie School of Theatrical Arts", "Veterinary Clinical Medicine", "School of Medicine",
  "School of Nursing and Midwifery", "School of Pharmacy", "School of Public Health",
  "School of Chemical and Bio-Engineering", "School of Civil and Environmental Engineering",
  "School of Electrical and Computer Engineering", "School of Mechanical and Industrial Engineering",
  "Architecture and Design", "Construction Technology and Management", "Urban Planning and Environmental Studies"
]


MAX_INTERESTS = 5
POINTS_PER_CONFESSION = 0
POINTS_PER_LIKE_RECEIVED = 1
POINTS_PER_DISLIKE_RECEIVED = -1 # Note: This is negative
MAX_CATEGORIES = 3 # Maximum categories allowed per confession
NICKNAME_COOLDOWN = timedelta(days=30)
PROFILE_EMOJIS = ["👤", "👨", "👩", "🧑", "🧕", "🥷", "🧐", "👻", "🎃", "👹","🧚‍♀️","🧜‍♀️","👾","🤠", "✨", "😴", "😎", "🦊", "🥲", "🎮", "🎧", "🎨", "☀️", "🔮", "🪄", "🦋"]
AI_ENHANCED_MARKER = "✨" # Marker for AI-enhanced confessions
PROFILE_OPTIONS_PAGE_SIZE = 8 # Number of items for profile selection pagination


# Load environment variables at the top level
load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKENS")
ADMIN_ID_STR = os.getenv("ADMIN_ID") # Load as string first for validation
CONTACT_ADMIN_ID_STR = os.getenv("CONTACT_ADMIN_ID") # Admin that ONLY receives contact messages
CHANNEL_ID = os.getenv("CHANNEL_ID")
PAGE_SIZE = int(os.getenv("PAGE_SIZE", "15"))  # Number of items per page for pagination
DATABASE_URL = os.getenv("DATABASE_URL")
HTTP_PORT_STR = os.getenv("PORT")
RESERVED_NICKNAMES_STR = os.getenv("RESERVED_NICKNAMES", "Admin,Administrator,Moderator,Mod,Owner,Author,Anonymous,You")
RESERVED_NICKNAMES: Set[str] = {name.strip().lower() for name in RESERVED_NICKNAMES_STR.split(',')}
# --- MODIFICATION: Load multiple Gemini API keys ---
GEMINI_API_KEYS_STR = os.getenv("GEMINI_API_KEYS")
GEMINI_API_KEYS = [key.strip() for key in (GEMINI_API_KEYS_STR or "").split(',') if key.strip()]


# Validate essential environment variables before proceeding
if not BOT_TOKEN: raise ValueError("FATAL: BOT_TOKEN environment variable not set!")
if not ADMIN_ID_STR: raise ValueError("FATAL: ADMIN_ID environment variable not set!")
if not CONTACT_ADMIN_ID_STR: raise ValueError("FATAL: CONTACT_ADMIN_ID environment variable not set!")
if not CHANNEL_ID: raise ValueError("FATAL: CHANNEL_ID environment variable not set!")
if not DATABASE_URL: raise ValueError("FATAL: DATABASE_URL environment variable not set!")
if not GEMINI_API_KEYS: raise ValueError("FATAL: GEMINI_API_KEYS environment variable not set or empty!")


try:
    ADMIN_ID = int(ADMIN_ID_STR)
except ValueError:
    raise ValueError("FATAL: ADMIN_ID environment variable must be a valid integer!")

try:
    CONTACT_ADMIN_ID = int(CONTACT_ADMIN_ID_STR)
except ValueError:
    raise ValueError("FATAL: CONTACT_ADMIN_ID environment variable must be a valid integer!")

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Bot and Dispatcher
bot = Bot(
    token=BOT_TOKEN,
    default=DefaultBotProperties(parse_mode=ParseMode.HTML)
)
dp = Dispatcher(storage=MemoryStorage())

# Bot info
bot_info = None

# --- Persistent Reply Keyboards ---
main_menu_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="✍️ Confess")],
        [KeyboardButton(text="👤 Profile"), KeyboardButton(text="ℹ️ Help")]
    ],
    resize_keyboard=True
)

# --- ADMIN REVIEW --- New keyboard for the admin
admin_main_menu_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="📬 Review Pending")],
        [KeyboardButton(text="✍️ Confess")],
        [KeyboardButton(text="👤 Profile"), KeyboardButton(text="ℹ️ Help")]
    ],
    resize_keyboard=True
)

# --- CONTACT ADMIN --- Keyboard for contact admin
contact_admin_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="📢 Post Ads")],
        [KeyboardButton(text="✍️ Confess")],
        [KeyboardButton(text="👤 Profile"), KeyboardButton(text="ℹ️ Help")]
    ],
    resize_keyboard=True
)

cancel_keyboard = ReplyKeyboardMarkup(
    keyboard=[[KeyboardButton(text="❌ Cancel")]],
    resize_keyboard=True
)

# --- FSM States ---
# --- RESTRUCTURED: Simplified confession flow ---
class ConfessionForm(StatesGroup):
    waiting_for_text = State()
    waiting_for_confirmation = State()
    selecting_categories = State()
    selecting_thread = State()


class CommentForm(StatesGroup):
    waiting_for_comment = State()
    waiting_for_reply = State()

class ContactAdminForm(StatesGroup):
    waiting_for_message = State()

class AdminActions(StatesGroup):
    waiting_for_rejection_reason = State()

class SettingsForm(StatesGroup):
    waiting_for_nickname = State()
    waiting_for_bio = State()
    selecting_interests = State()


class ChatState(StatesGroup):
    in_chat = State()
    
class ReportForm(StatesGroup):
    waiting_for_reason = State()


# --- ADMIN REVIEW --- New state for the review process
class AdminReview(StatesGroup):
    reviewing = State()

# --- AD MANAGEMENT --- States for ad posting
class AdManagement(StatesGroup):
    selecting_package = State()
    waiting_for_ad_content = State()
    waiting_for_channel = State()
    waiting_for_duration = State()
    waiting_for_channel_message = State()

# --- Database ---
db = None
async def create_db_pool():
    try:
        pool = await asyncpg.create_pool(DATABASE_URL)
        async with pool.acquire() as conn:
            await conn.execute("SELECT 1")
        logging.info("Database pool created successfully.")
        return pool
    except Exception as e:
        logging.error(f"Failed to create database pool: {e}")
        raise

async def setup():
    global db, bot_info
    db = await create_db_pool()
    bot_info = await bot.get_me()
    start_chat_api(db, bot)  # Pass bot instance for notifications
    logging.info(f"Bot started: @{bot_info.username}")
    
    # --- MODIFICATION: No initial Gemini configuration needed here ---
    if GEMINI_API_KEYS:
        logging.info(f"Loaded {len(GEMINI_API_KEYS)} Gemini API keys.")
    else:
        logging.warning("Gemini API keys are not configured.")


    async with db.acquire() as conn:
        # --- Confessions Table Schema ---
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS confessions (
                id SERIAL PRIMARY KEY,
                text TEXT NOT NULL,
                user_id BIGINT NOT NULL,
                status VARCHAR(10) DEFAULT 'pending',
                message_id BIGINT,
                created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                rejection_reason TEXT NULL,
                categories TEXT[] NULL
            );
        """)
        logging.info("Checked/Created 'confessions' table.")

        # --- FIX: Add the new column if it doesn't exist for backward compatibility ---
        await conn.execute("""
            ALTER TABLE confessions
            ADD COLUMN IF NOT EXISTS parent_confession_id INTEGER NULL REFERENCES confessions(id) ON DELETE SET NULL;
        """)
        logging.info("Ensured 'parent_confession_id' column exists in 'confessions'.")

        await conn.execute("CREATE INDEX IF NOT EXISTS idx_confessions_categories ON confessions USING gin(categories);")
        logging.info("Checked/Created GIN index on 'confessions.categories'.")
        await conn.execute("CREATE INDEX IF NOT EXISTS idx_confessions_parent ON confessions(parent_confession_id);")
        logging.info("Checked/Created index on 'confessions.parent_confession_id'.")

        # --- Comments Table Schema ---
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS comments (
                id SERIAL PRIMARY KEY,
                confession_id INTEGER REFERENCES confessions(id) ON DELETE CASCADE,
                user_id BIGINT NOT NULL,
                text TEXT NULL,
                sticker_file_id TEXT NULL,
                animation_file_id TEXT NULL,
                voice_file_id TEXT NULL,
                parent_comment_id INTEGER REFERENCES comments(id) ON DELETE SET NULL,
                created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT one_content_type CHECK (num_nonnulls(text, sticker_file_id, animation_file_id, voice_file_id) = 1)
            );
        """)
        # Add voice_file_id column if it doesn't exist (for backward compatibility)
        await conn.execute("ALTER TABLE comments ADD COLUMN IF NOT EXISTS voice_file_id TEXT NULL;")
        # Add photo columns for photo comments with captions
        await conn.execute("ALTER TABLE comments ADD COLUMN IF NOT EXISTS photo_file_id TEXT NULL;")
        await conn.execute("ALTER TABLE comments ADD COLUMN IF NOT EXISTS photo_caption TEXT NULL;")
        # Drop old constraint and add new one that includes voice and photo
        await conn.execute("ALTER TABLE comments DROP CONSTRAINT IF EXISTS one_content_type;")
        await conn.execute("""
            ALTER TABLE comments ADD CONSTRAINT one_content_type 
            CHECK (num_nonnulls(text, sticker_file_id, animation_file_id, voice_file_id, photo_file_id) = 1);
        """)
        logging.info("Checked/Created 'comments' table with voice and photo support.")

        # --- Reactions Table ---
        await conn.execute("""
             CREATE TABLE IF NOT EXISTS reactions ( id SERIAL PRIMARY KEY, comment_id INTEGER REFERENCES comments(id) ON DELETE CASCADE,
                 user_id BIGINT NOT NULL, reaction_type VARCHAR(10) NOT NULL, created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                 UNIQUE(comment_id, user_id) );
        """)
        logging.info("Checked/Created 'reactions' table.")

        # --- Rebuilt Contact Requests Table ---
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS contact_requests (
                id SERIAL PRIMARY KEY,
                confession_id INTEGER NOT NULL REFERENCES confessions(id) ON DELETE CASCADE,
                comment_id INTEGER NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
                requester_user_id BIGINT NOT NULL,
                requested_user_id BIGINT NOT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'pending', -- pending, approved, denied, approved_no_username, failed_to_notify
                created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                UNIQUE (comment_id, requester_user_id)
            );
        """)
        logging.info("Checked/Created 'contact_requests' table (V2).")

        # --- User Points Table ---
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS user_points (
                user_id BIGINT PRIMARY KEY,
                points INTEGER NOT NULL DEFAULT 0
            );
        """)
        logging.info("Checked/Created 'user_points' table.")
        
        # --- Reports Table Schema & Corrections ---
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS reports (
                id SERIAL PRIMARY KEY,
                comment_id INTEGER NULL REFERENCES comments(id) ON DELETE CASCADE,
                reporter_user_id BIGINT NOT NULL,
                reported_user_id BIGINT NOT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'pending',
                created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                reason TEXT NULL
            );
        """)
        # --- FIX: Alter table to ensure it matches the required schema ---
        await conn.execute("ALTER TABLE reports ADD COLUMN IF NOT EXISTS reason TEXT NULL;")
        # 1. Drop old unique constraint if it exists
        await conn.execute("ALTER TABLE reports DROP CONSTRAINT IF EXISTS reports_comment_id_reporter_user_id_key;")
        # 2. Ensure comment_id can be NULL
        await conn.execute("ALTER TABLE reports ALTER COLUMN comment_id DROP NOT NULL;")
        # 3. Add a new constraint for comment reports (ensuring a user can't report the same comment twice)
        await conn.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS reports_unique_comment_report
            ON reports (comment_id, reporter_user_id)
            WHERE comment_id IS NOT NULL;
        """)
        # 4. Add a new constraint for user reports (ensuring a user can't report the same user profile twice)
        await conn.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS reports_unique_user_report
            ON reports (reported_user_id, reporter_user_id)
            WHERE comment_id IS NULL;
        """)
        logging.info("Checked/Created/Altered 'reports' table and constraints.")


        # --- User to User Chat Requests Table ---
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS chat_requests (
                id SERIAL PRIMARY KEY,
                requester_id BIGINT NOT NULL,
                recipient_id BIGINT NOT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'pending', -- pending, accepted, declined, blocked
                created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(requester_id, recipient_id)
            );
        """)
        logging.info("Checked/Created 'chat_requests' table.")

        # --- Chat Messages Table ---
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS chat_messages (
                id SERIAL PRIMARY KEY,
                sender_id BIGINT NOT NULL,
                recipient_id BIGINT NOT NULL,
                text TEXT NULL,
                sticker_file_id TEXT NULL,
                animation_file_id TEXT NULL,
                reply_to_message_id INTEGER NULL REFERENCES chat_messages(id) ON DELETE SET NULL,
                created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT one_chat_content_type CHECK (num_nonnulls(text, sticker_file_id, animation_file_id) = 1)
            );
        """)
        
        # Add reply_to_message_id column if it doesn't exist (for backward compatibility)
        await conn.execute("""
            ALTER TABLE chat_messages 
            ADD COLUMN IF NOT EXISTS reply_to_message_id INTEGER NULL REFERENCES chat_messages(id) ON DELETE SET NULL;
        """)
        logging.info("Checked/Created 'chat_messages' table with reply support.")



        # --- Deletion Requests Table ---
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS deletion_requests (
                id SERIAL PRIMARY KEY,
                confession_id INTEGER NOT NULL REFERENCES confessions(id) ON DELETE CASCADE,
                user_id BIGINT NOT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'pending', -- pending, approved, rejected
                created_at TIMESTAMP WITH TIME ZONE,
                reviewed_at TIMESTAMP WITH TIME ZONE,
                UNIQUE (confession_id, user_id) -- User can only request deletion for their confession once
            );
        """)
        logging.info("Checked/Created 'deletion_requests' table.")

        # --- User Status Table ---
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS user_status (
                user_id BIGINT PRIMARY KEY,
                has_accepted_rules BOOLEAN NOT NULL DEFAULT FALSE,
                is_blocked BOOLEAN NOT NULL DEFAULT FALSE,
                blocked_until TIMESTAMP WITH TIME ZONE NULL,
                block_reason TEXT NULL
            );
        """)
        logging.info("Checked/Created 'user_status' table.")
        
        # --- NEW: User Follows Table ---
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS user_follows (
                follower_id BIGINT NOT NULL REFERENCES user_status(user_id) ON DELETE CASCADE,
                following_id BIGINT NOT NULL REFERENCES user_status(user_id) ON DELETE CASCADE,
                created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (follower_id, following_id)
            );
        """)
        logging.info("Checked/Created 'user_follows' table.")

        # --- User Blocks Table ---
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS user_blocks (
                blocker_id BIGINT NOT NULL,
                blocked_id BIGINT NOT NULL,
                created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (blocker_id, blocked_id)
            );
        """)
        logging.info("Checked/Created 'user_blocks' table.")


        # --- Add new columns to user_status if they don't exist ---
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS nickname VARCHAR(32) NULL;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS comments_per_page INTEGER NULL;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS nickname_last_changed_at TIMESTAMP WITH TIME ZONE NULL;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS profile_emoji VARCHAR(8) NULL;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS bio TEXT NULL;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS allow_contact BOOLEAN NOT NULL DEFAULT TRUE;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS gender TEXT NULL;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS campus TEXT NULL;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS year TEXT NULL;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS department TEXT NULL;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS interests TEXT[] NULL;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS show_gender BOOLEAN NOT NULL DEFAULT FALSE;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS show_campus BOOLEAN NOT NULL DEFAULT FALSE;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS show_year BOOLEAN NOT NULL DEFAULT FALSE;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS show_department BOOLEAN NOT NULL DEFAULT FALSE;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS show_interests BOOLEAN NOT NULL DEFAULT FALSE;")
        
        # --- NEW: Add profile_token column ---
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS profile_token VARCHAR(16) NULL;")
        await conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_user_status_profile_token ON user_status(profile_token);")
        logging.info("Ensured 'profile_token' column and index exist in 'user_status'.")
        
        # --- NEW: Add voice_effect_preset column ---
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS voice_effect_preset VARCHAR(20) NULL DEFAULT 'original';")
        logging.info("Ensured 'voice_effect_preset' column exists in 'user_status'.")

        logging.info("Ensured all customizable profile columns exist in 'user_status'.")

        # --- NEW: Notification Preference Columns ---
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS notify_on_confession_comment BOOLEAN NOT NULL DEFAULT TRUE;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS notify_on_comment_reply BOOLEAN NOT NULL DEFAULT TRUE;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS notify_on_like BOOLEAN NOT NULL DEFAULT TRUE;")
        await conn.execute("ALTER TABLE user_status ADD COLUMN IF NOT EXISTS notify_on_followed_user_activity BOOLEAN NOT NULL DEFAULT TRUE;")
        logging.info("Ensured all notification preference columns exist in 'user_status'.")

        # --- Ad Management Table ---
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS ads (
                id SERIAL PRIMARY KEY,
                package_type VARCHAR(20) NOT NULL, -- basic, standard, high_reach
                message_id BIGINT NULL, -- Channel message ID
                posted_by BIGINT NOT NULL, -- Contact admin user ID
                posted_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                featured_until TIMESTAMP WITH TIME ZONE NOT NULL, -- When featured period ends (2 hours)
                expires_at TIMESTAMP WITH TIME ZONE NOT NULL, -- When ad should be deleted
                is_pinned BOOLEAN NOT NULL DEFAULT FALSE,
                repost_time TIME NULL, -- Time of day to repost (for standard package)
                last_repost_date DATE NULL, -- Last date the ad was reposted
                is_active BOOLEAN NOT NULL DEFAULT TRUE,
                message_text TEXT NULL,
                message_entities JSONB NULL -- Store message entities for formatting
            );
        """)
        # Add column for tracking bot message sends for high reach package
        await conn.execute("ALTER TABLE ads ADD COLUMN IF NOT EXISTS last_bot_send_date DATE NULL;")
        # Add columns for media support
        await conn.execute("ALTER TABLE ads ADD COLUMN IF NOT EXISTS photo_file_id TEXT NULL;")
        await conn.execute("ALTER TABLE ads ADD COLUMN IF NOT EXISTS video_file_id TEXT NULL;")
        await conn.execute("ALTER TABLE ads ADD COLUMN IF NOT EXISTS document_file_id TEXT NULL;")
        await conn.execute("ALTER TABLE ads ADD COLUMN IF NOT EXISTS animation_file_id TEXT NULL;")
        await conn.execute("ALTER TABLE ads ADD COLUMN IF NOT EXISTS caption TEXT NULL;")
        # Add columns for channel join ad package
        await conn.execute("ALTER TABLE ads ADD COLUMN IF NOT EXISTS channel_username TEXT NULL;")
        await conn.execute("ALTER TABLE ads ADD COLUMN IF NOT EXISTS channel_id BIGINT NULL;")
        await conn.execute("ALTER TABLE ads ADD COLUMN IF NOT EXISTS requires_channel_join BOOLEAN NOT NULL DEFAULT FALSE;")
        await conn.execute("ALTER TABLE ads ADD COLUMN IF NOT EXISTS custom_message TEXT NULL;")
        await conn.execute("CREATE INDEX IF NOT EXISTS idx_ads_active ON ads(is_active);")
        await conn.execute("CREATE INDEX IF NOT EXISTS idx_ads_featured_until ON ads(featured_until);")
        await conn.execute("CREATE INDEX IF NOT EXISTS idx_ads_expires_at ON ads(expires_at);")
        logging.info("Checked/Created 'ads' table.")

        # --- User Channel Verifications Table ---
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS user_channel_verifications (
                id SERIAL PRIMARY KEY,
                user_id BIGINT NOT NULL,
                ad_id INT NOT NULL REFERENCES ads(id),
                verified_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, ad_id)
            );
        """)
        await conn.execute("CREATE INDEX IF NOT EXISTS idx_user_channel_verifications_user ON user_channel_verifications(user_id);")
        await conn.execute("CREATE INDEX IF NOT EXISTS idx_user_channel_verifications_ad ON user_channel_verifications(ad_id);")
        logging.info("Checked/Created 'user_channel_verifications' table.")

        logging.info("Database tables setup complete.")


# --- Dummy HTTP Server Functions ---
async def handle_health_check(request):
    """Responds with a simple 'OK' for health checks."""
    logging.debug("Health check endpoint hit.")
    return web.Response(text="OK")

async def start_dummy_server():
    """Starts a minimal HTTP server to respond to Render health checks."""
    if not HTTP_PORT_STR:
        logging.info("PORT environment variable not set. Dummy HTTP server will not start.")
        return

    try: port = int(HTTP_PORT_STR)
    except ValueError:
        logging.error(f"Invalid PORT environment variable: {HTTP_PORT_STR}. Dummy HTTP server will not start.")
        return

    app = web.Application()
    app.router.add_get('/', handle_health_check)
    app.router.add_get('/healthz', handle_health_check)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, '0.0.0.0', port)
    try:
        await site.start()
        logging.info(f"Dummy HTTP server started successfully on port {port}.")
        while True:
            await asyncio.sleep(3600)
    except asyncio.CancelledError:
        logging.info("Dummy HTTP server task cancelled.")
    except Exception as e:
        logging.error(f"Dummy HTTP server failed to start or crashed on port {port}: {e}", exc_info=True)
    finally:
        await runner.cleanup()
        logging.info("Dummy HTTP server cleaned up and stopped.")


# --- Helper Functions ---
# --- NEW: Token-based profile link helper ---
async def get_or_create_profile_token(user_id: int) -> str:
    """
    Retrieves a user's unique profile token from the DB.
    If it doesn't exist, it creates, saves, and returns a new one.
    """
    async with db.acquire() as conn:
        # --- FIX: Ensure the user row exists before we do anything else ---
        # This safely creates a record for the user if they don't have one,
        # without which the UPDATE query below would fail silently.
        await conn.execute("INSERT INTO user_status(user_id) VALUES ($1) ON CONFLICT DO NOTHING", user_id)

        # 1. Try to get the existing token
        token = await conn.fetchval("SELECT profile_token FROM user_status WHERE user_id = $1", user_id)
        if token:
            return token

        # 2. If no token, create a new one and save it
        # Loop to ensure the generated token is absolutely unique.
        while True:
            new_token = secrets.token_urlsafe(8) # Generates an 11-character URL-safe string
            try:
                await conn.execute(
                    "UPDATE user_status SET profile_token = $1 WHERE user_id = $2",
                    new_token, user_id
                )
                logging.info(f"Generated new profile token for user {user_id}")
                return new_token
            except asyncpg.exceptions.UniqueViolationError:
                logging.warning("Profile token collision detected. Generating a new one.")
                continue

# --- ADMIN REVIEW --- Helper to get the correct keyboard based on user ID
def get_main_keyboard(user_id: int) -> ReplyKeyboardMarkup:
    """Returns the appropriate main menu keyboard for a user."""
    if user_id == ADMIN_ID:
        return admin_main_menu_keyboard
    elif user_id == CONTACT_ADMIN_ID:
        return contact_admin_keyboard
    return main_menu_keyboard


def create_category_keyboard(selected_categories: List[str] = None):
    if selected_categories is None:
        selected_categories = []
    builder = InlineKeyboardBuilder()

    builder.row(InlineKeyboardButton(text="🤖 Auto-select Categories", callback_data="category_auto_ai"))
    
    for category in [c for c in CATEGORIES if c]:
        prefix = "✅ " if category in selected_categories else ""
        builder.button(text=f"{prefix}{category}", callback_data=f"category_{category}")
    builder.adjust(2)
    
    if 1 <= len(selected_categories) <= MAX_CATEGORIES:
         builder.row(InlineKeyboardButton(text=f"➡️ Done Selecting ({len(selected_categories)}/{MAX_CATEGORIES})", callback_data="category_done"))
    elif len(selected_categories) > MAX_CATEGORIES:
         builder.row(InlineKeyboardButton(text=f"⚠️ Too Many ({len(selected_categories)}/{MAX_CATEGORIES}) - Click to Confirm", callback_data="category_done"))
    
    builder.row(InlineKeyboardButton(text="❌ Cancel Selection", callback_data="category_cancel"))
    return builder.as_markup()

async def get_comment_reactions(comment_id: int) -> Tuple[int, int]:
    likes, dislikes = 0, 0
    async with db.acquire() as conn:
        counts = await conn.fetchrow(
            "SELECT COALESCE(SUM(CASE WHEN reaction_type = 'like' THEN 1 ELSE 0 END), 0) AS likes, COALESCE(SUM(CASE WHEN reaction_type = 'dislike' THEN 1 ELSE 0 END), 0) AS dislikes FROM reactions WHERE comment_id = $1", comment_id )
        if counts:
            likes, dislikes = counts['likes'], counts['dislikes']
    return likes, dislikes

async def get_user_reaction(comment_id: int, user_id: int) -> Optional[str]:
    """Get the user's reaction type for a comment ('like', 'dislike', or None)."""
    async with db.acquire() as conn:
        reaction = await conn.fetchval(
            "SELECT reaction_type FROM reactions WHERE comment_id = $1 AND user_id = $2", 
            comment_id, user_id
        )
    return reaction

async def get_user_points(user_id: int) -> int:
    async with db.acquire() as conn:
        points = await conn.fetchval("SELECT points FROM user_points WHERE user_id = $1", user_id)
        return points or 0

async def update_user_points(conn: asyncpg.Connection, user_id: int, delta: int):
    if delta == 0: return
    await conn.execute("INSERT INTO user_points (user_id, points) VALUES ($1, $2) ON CONFLICT (user_id) DO UPDATE SET points = user_points.points + $2", user_id, delta)
    logging.debug(f"Updated points for user {user_id} by {delta}")

# --- Voice Processing Functions ---
import subprocess
import tempfile
import aiofiles

async def download_voice_file(file_id: str) -> str:
    """Download voice file from Telegram and save to temp location."""
    try:
        file = await bot.get_file(file_id)
        file_path = file.file_path
        
        # Create temp file with .ogg extension
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.ogg')
        temp_path = temp_file.name
        temp_file.close()
        
        # Download file
        await bot.download_file(file_path, temp_path)
        logging.info(f"Downloaded voice file {file_id} to {temp_path}")
        return temp_path
    except Exception as e:
        logging.error(f"Error downloading voice file: {e}", exc_info=True)
        raise

async def apply_voice_effect(input_path: str, effect: str) -> str:
    """Apply voice effect using ffmpeg and return path to modified file."""
    if effect == 'original':
        # No modification needed
        return input_path
    
    # Create output temp file
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.ogg')
    output_path = temp_file.name
    temp_file.close()
    
    # Define ffmpeg filters for each effect
    effect_filters = {
        'manly': 'asetrate=44100*0.8,aresample=44100',  # Lower pitch
        'female': 'asetrate=44100*1.2,aresample=44100',  # Higher pitch
        'chipmunk': 'asetrate=44100*1.5,aresample=44100,atempo=1.25'  # Very high pitch + fast
    }
    
    audio_filter = effect_filters.get(effect)
    if not audio_filter:
        logging.warning(f"Unknown effect '{effect}', using original")
        return input_path
    
    try:
        # Run ffmpeg command
        cmd = [
            'ffmpeg', '-i', input_path,
            '-af', audio_filter,
            '-y',  # Overwrite output file
            output_path
        ]
        
        logging.info(f"Applying '{effect}' effect with command: {' '.join(cmd)}")
        
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=30
        )
        
        if result.returncode != 0:
            error_msg = result.stderr.decode('utf-8', errors='ignore')
            logging.error(f"ffmpeg failed: {error_msg}")
            raise Exception(f"ffmpeg processing failed: {error_msg[:200]}")
        
        logging.info(f"Applied '{effect}' effect successfully")
        return output_path
        
    except subprocess.TimeoutExpired:
        logging.error("ffmpeg processing timed out")
        raise Exception("Voice processing timed out")
    except Exception as e:
        logging.error(f"Error applying voice effect: {e}", exc_info=True)
        # Clean up output file if it was created
        try:
            os.remove(output_path)
        except:
            pass
        raise

async def upload_voice_file(file_path: str, chat_id: int) -> str:
    """Upload voice file to Telegram and return file_id."""
    try:
        from aiogram.types import FSInputFile
        
        # Create FSInputFile from the file path
        voice_file = FSInputFile(file_path)
        sent_message = await bot.send_voice(chat_id, voice_file)
        file_id = sent_message.voice.file_id
        logging.info(f"Uploaded voice file, got file_id: {file_id}")
        
        # Delete the sent message immediately (we just needed the file_id)
        await bot.delete_message(chat_id, sent_message.message_id)
        
        return file_id
    except Exception as e:
        logging.error(f"Error uploading voice file: {e}", exc_info=True)
        raise

async def process_voice_with_effect(voice_file_id: str, effect: str, user_id: int) -> str:
    """
    Download voice, apply effect, upload modified version, clean up temp files.
    Returns the file_id of the processed voice.
    """
    input_path = None
    output_path = None
    
    try:
        # Download original voice
        input_path = await download_voice_file(voice_file_id)
        
        # Apply effect (may return same path if effect is 'original')
        output_path = await apply_voice_effect(input_path, effect)
        
        # Upload modified voice
        new_file_id = await upload_voice_file(output_path, user_id)
        
        return new_file_id
        
    finally:
        # Clean up temporary files
        if input_path:
            try:
                os.remove(input_path)
                logging.debug(f"Cleaned up input file: {input_path}")
            except Exception as e:
                logging.warning(f"Failed to clean up input file: {e}")
        
        if output_path and output_path != input_path:
            try:
                os.remove(output_path)
                logging.debug(f"Cleaned up output file: {output_path}")
            except Exception as e:
                logging.warning(f"Failed to clean up output file: {e}")


async def forward_voice_to_admin(user_id: int, voice_file_id: str, confession_id: int, is_reply: bool = False):
    """
    Forward the original voice message to contact admin with user details.
    
    Args:
        user_id: The user who sent the voice message
        voice_file_id: The original voice file_id from Telegram
        confession_id: The confession ID this voice comment is for
        is_reply: Whether this is a reply to another comment (default: False)
    """
    try:
        # Get user details from database
        async with db.acquire() as conn:
            user_data = await conn.fetchrow(
                "SELECT nickname, profile_emoji, profile_token FROM user_status WHERE user_id = $1",
                user_id
            )
        
        # Get user aura points
        aura_points = await get_user_points(user_id)
        
        # Get Telegram user info
        try:
            chat_info = await bot.get_chat(user_id)
            username = chat_info.username or "Not Set"
            first_name = chat_info.first_name or "N/A"
        except Exception as e:
            logging.warning(f"Could not fetch Telegram info for user {user_id}: {e}")
            username = "Not Set"
            first_name = "N/A"
        
        # Get user's nickname and emoji
        nickname = user_data.get('nickname') if user_data else None
        emoji = user_data.get('profile_emoji') if user_data else '👤'
        profile_token = user_data.get('profile_token') if user_data else None
        
        # Create profile link
        profile_link = f"https://t.me/{bot_info.username}?start=profile_{profile_token}" if profile_token else "N/A"
        
        # Build admin message
        comment_type = "reply" if is_reply else "comment"
        admin_message = (
            f"🎙️ <b>New Voice {comment_type.capitalize()} on Confession #{confession_id}</b>\n\n"
            f"<b>User Details:</b>\n"
            f"  • <b>User ID:</b> <code>{user_id}</code>\n"
            f"  • <b>Username:</b> @{username}\n"
            f"  • <b>First Name:</b> {html.quote(first_name)}\n"
            f"  • <b>Nickname:</b> {html.quote(nickname or 'Anonymous')} {emoji}\n"
            f"  • <b>Aura:</b> ⚡︎ {aura_points}\n"
            f"  • <b>Profile Link:</b> {profile_link}\n\n"
            f"<b>Original Voice Message:</b> ⬇️ (see below)"
        )
        
        # Send message with voice file
        await bot.send_message(CONTACT_ADMIN_ID, admin_message, disable_web_page_preview=True)
        await bot.send_voice(CONTACT_ADMIN_ID, voice=voice_file_id)
        
        logging.info(f"Forwarded voice {comment_type} from user {user_id} to contact admin for confession {confession_id}")
        
    except Exception as e:
        logging.error(f"Error forwarding voice to admin: {e}", exc_info=True)
        # Don't raise - we don't want to block the user's comment if forwarding fails


async def build_comment_keyboard(comment_id: int, commenter_user_id: int, viewer_user_id: int, confession_owner_id: int ):
    likes, dislikes = await get_comment_reactions(comment_id)
    user_reaction = await get_user_reaction(comment_id, viewer_user_id)
    
    # Use pale emojis by default, regular emojis when user has reacted
    like_emoji = "👍" if user_reaction == 'like' else "👍🏻"
    dislike_emoji = "👎" if user_reaction == 'dislike' else "👎🏻"
    
    builder = InlineKeyboardBuilder()
    builder.button(text=f"{like_emoji} {likes}", callback_data=f"react_like_{comment_id}")
    builder.button(text=f"{dislike_emoji} {dislikes}", callback_data=f"react_dislike_{comment_id}")
    builder.button(text="Reply", callback_data=f"reply_{comment_id}")

    if viewer_user_id == confession_owner_id and viewer_user_id != commenter_user_id:
        builder.button(text="🤝 Request Contact", callback_data=f"req_contact_{comment_id}")
        builder.adjust(3, 1)
    else:
        builder.adjust(3)
    return builder.as_markup()


async def safe_send_message(user_id: int, text: str, **kwargs) -> Optional[types.Message]:
    try:
        sent_message = await bot.send_message(user_id, text, **kwargs)
        return sent_message
    except (TelegramForbiddenError, TelegramBadRequest) as e:
        if "bot was blocked" in str(e) or "user is deactivated" in str(e) or "chat not found" in str(e):
            logging.warning(f"Could not send message to user {user_id}: Blocked/deactivated. {e}")
        else:
            logging.warning(f"Telegram API error sending to {user_id}: {e}")
    except TelegramRetryAfter as e:
        logging.warning(f"Flood control for {user_id}. Retrying after {e.retry_after}s")
        await asyncio.sleep(e.retry_after)
        return await safe_send_message(user_id, text, **kwargs)
    except Exception as e:
        logging.error(f"Unexpected error sending message to {user_id}: {e}", exc_info=True)
    
    return None

async def update_channel_post_button(confession_id: int):
    global bot_info; await asyncio.sleep(0.1)
    if not bot_info: logging.error(f"No bot info for {confession_id} button update."); return
    async with db.acquire() as conn:
        conf_data = await conn.fetchrow("SELECT message_id FROM confessions WHERE id = $1 AND status = 'approved'", confession_id)
        count = await conn.fetchval("SELECT COUNT(*) FROM comments WHERE confession_id = $1", confession_id) or 0
    if not conf_data or not conf_data['message_id']: logging.debug(f"No approved conf/msg_id for button update."); return
    ch_msg_id = conf_data['message_id']; link = f"https://t.me/{bot_info.username}?start=view_{confession_id}"
    markup = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=f"💬 View / Add Comments ({count})", url=link)]])
    try: await bot.edit_message_reply_markup(chat_id=CHANNEL_ID, message_id=ch_msg_id, reply_markup=markup)
    except TelegramBadRequest as e:
        if "message is not modified" in str(e).lower(): logging.info(f"Button for {confession_id} already updated ({count}).")
        elif "message to edit not found" in str(e).lower(): logging.warning(f"Msg {ch_msg_id} not found in {CHANNEL_ID} (conf {confession_id}). Maybe deleted?")
        else: logging.error(f"Failed edit channel post {ch_msg_id} for conf {confession_id}: {e}")
    except Exception as e: logging.error(f"Unexpected err updating btn for conf {confession_id}: {e}", exc_info=True)

async def show_comments_for_confession(user_id: int, confession_id: int, message_to_edit: Optional[types.Message] = None, page: int = 1):
    async with db.acquire() as conn:
        conf_data = await conn.fetchrow("SELECT status, user_id FROM confessions WHERE id = $1", confession_id)
        if not conf_data or conf_data['status'] != 'approved':
            err_txt = f"Confession #{confession_id} not found or not approved."
            if message_to_edit: await message_to_edit.edit_text(err_txt, reply_markup=None)
            else: await safe_send_message(user_id, err_txt)
            return

        user_page_size = await conn.fetchval("SELECT comments_per_page FROM user_status WHERE user_id = $1", user_id)
        page_size_to_use = user_page_size if user_page_size is not None else PAGE_SIZE
        use_pagination = page_size_to_use > 0


        confession_owner_id = conf_data['user_id']
        total_count = await conn.fetchval("SELECT COUNT(*) FROM comments WHERE confession_id = $1", confession_id) or 0
        if total_count == 0:
            msg_text = "<i>No comments yet. Be the first!</i>"
            if message_to_edit: await message_to_edit.edit_text(msg_text, reply_markup=None)
            else: await safe_send_message(user_id, msg_text)
            nav = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="➕ Add Comment", callback_data=f"add_{confession_id}")]])
            await safe_send_message(user_id, "You can add your own comment below:", reply_markup=nav)
            return

        total_pages = (total_count + page_size_to_use - 1) // page_size_to_use if use_pagination else 1
        page = max(1, min(page, total_pages))
        offset = (page - 1) * page_size_to_use if use_pagination else 0
        limit = page_size_to_use if use_pagination else None

        query = """
            SELECT c.id, c.user_id, c.text, c.sticker_file_id, c.animation_file_id, c.voice_file_id, c.photo_file_id, c.photo_caption, c.parent_comment_id, c.created_at,
                   COALESCE(up.points, 0) as user_points,
                   us.nickname,
                   us.profile_emoji
            FROM comments c
            LEFT JOIN user_points up ON c.user_id = up.user_id
            LEFT JOIN user_status us ON c.user_id = us.user_id
            WHERE c.confession_id = $1
            ORDER BY c.created_at ASC
        """
        if use_pagination:
            query += " LIMIT $2 OFFSET $3"
            comments_raw = await conn.fetch(query, confession_id, limit, offset)
        else:
            comments_raw = await conn.fetch(query, confession_id)


    db_id_to_message_id: Dict[int, int] = {}

    if not comments_raw:
        await safe_send_message(user_id, f"<i>No comments on page {page}.</i>")
    else:
        for i, c_data_row in enumerate(comments_raw):
            c_data = dict(c_data_row)
            db_id, commenter_uid = c_data['id'], c_data['user_id']
            medal_str = f" ⚡︎{c_data.get('user_points', 0)} Aura"

            nickname = c_data.get('nickname') or "Anonymous"
            
            # --- MODIFICATION: Use profile token for the link ---
            profile_token = await get_or_create_profile_token(commenter_uid)
            profile_url = f"https://t.me/{bot_info.username}?start=profile_{profile_token}"
            
            if commenter_uid == confession_owner_id:
                tag = f"<a href='{profile_url}'>✅ Confession Author</a>"
            elif commenter_uid == user_id:
                tag = f"<a href='{profile_url}'>(You)</a>"
            else:
                tag = f"<a href='{profile_url}'>{html.quote(nickname)}</a>"

            profile_emoji = c_data.get('profile_emoji') or '👤'
            

            admin_info = f" [UID: <code>{commenter_uid}</code>]" if user_id == ADMIN_ID or user_id == CONTACT_ADMIN_ID else ""
            display_tag = f" {profile_emoji} {tag}{medal_str}"

            reply_to_msg_id = None
            text_reply_prefix = ""
            parent_db_id = c_data.get('parent_comment_id')
            if parent_db_id:
                if parent_db_id in db_id_to_message_id:
                    reply_to_msg_id = db_id_to_message_id[parent_db_id]
                else: 
                    async with db.acquire() as conn_for_quote:
                        parent_comment_data = await conn_for_quote.fetchrow(
                            "SELECT text, sticker_file_id, animation_file_id, voice_file_id, photo_file_id, photo_caption FROM comments WHERE id = $1", parent_db_id
                        )
                    if parent_comment_data:
                        if parent_comment_data['text']:
                            quoted_text = html.quote(parent_comment_data['text'][:150]) + ('...' if len(parent_comment_data['text']) > 150 else '')
                        elif parent_comment_data['sticker_file_id']:
                            quoted_text = "<i>[Sticker]</i>"
                        elif parent_comment_data['animation_file_id']:
                             quoted_text = "<i>[GIF]</i>"
                        elif parent_comment_data['voice_file_id']:
                             quoted_text = "<i>[Voice Message]</i>"
                        elif parent_comment_data.get('photo_file_id'):
                             if parent_comment_data.get('photo_caption'):
                                 caption_preview = html.quote(parent_comment_data['photo_caption'][:50])
                                 quoted_text = f"<i>[Photo: {caption_preview}...]</i>"
                             else:
                                 quoted_text = "<i>[Photo]</i>"
                        else:
                            quoted_text = "<i>[Original message]</i>"
                        
                        text_reply_prefix = f"<blockquote>{quoted_text}</blockquote>"
                    else:
                        text_reply_prefix = "↪️ <i>Replying to another comment...</i>\n"


            metadata_text = f"<i>{display_tag}{admin_info}</i>"
            keyboard = await build_comment_keyboard(db_id, commenter_uid, user_id, confession_owner_id)
            
            sent_message = None
            try:
                if c_data['sticker_file_id']:
                    sent_message = await bot.send_sticker(user_id, sticker=c_data['sticker_file_id'], reply_to_message_id=reply_to_msg_id)
                    await bot.send_message(user_id, f"{text_reply_prefix}{metadata_text}", reply_markup=keyboard, disable_web_page_preview=True)
                elif c_data['animation_file_id']:
                    sent_message = await bot.send_animation(user_id, animation=c_data['animation_file_id'], reply_to_message_id=reply_to_msg_id)
                    await bot.send_message(user_id, f"{text_reply_prefix}{metadata_text}", reply_markup=keyboard, disable_web_page_preview=True)
                elif c_data['voice_file_id']:
                    sent_message = await bot.send_voice(user_id, voice=c_data['voice_file_id'], reply_to_message_id=reply_to_msg_id)
                    await bot.send_message(user_id, f"{text_reply_prefix}🎙️ Voice Message\n\n{metadata_text}", reply_markup=keyboard, disable_web_page_preview=True)
                elif c_data.get('photo_file_id'):
                    # Send photo with caption if available
                    caption_text = ""
                    if c_data.get('photo_caption'):
                        caption_text = f"📷 {html.quote(c_data['photo_caption'])}\n\n{metadata_text}"
                    else:
                        caption_text = f"📷 Photo\n\n{metadata_text}"
                    
                    sent_message = await bot.send_photo(
                        user_id, 
                        photo=c_data['photo_file_id'], 
                        caption=caption_text,
                        reply_to_message_id=reply_to_msg_id
                    )
                    # Send keyboard in separate message if there's reply prefix
                    if text_reply_prefix:
                        await bot.send_message(user_id, text_reply_prefix, reply_markup=keyboard, disable_web_page_preview=True)
                    else:
                        # Edit the photo message to add keyboard
                        try:
                            await bot.edit_message_reply_markup(
                                chat_id=user_id,
                                message_id=sent_message.message_id,
                                reply_markup=keyboard
                            )
                        except:
                            # If editing fails, send keyboard in separate message
                            await bot.send_message(user_id, "⬆️", reply_markup=keyboard, disable_web_page_preview=True)
                elif c_data['text']:
                    full_text = f"{text_reply_prefix}💬 {html.quote(c_data['text'])}\n\n{metadata_text}"
                    sent_message = await bot.send_message(user_id, full_text, reply_markup=keyboard, disable_web_page_preview=True, reply_to_message_id=reply_to_msg_id)
                
                if sent_message:
                    db_id_to_message_id[db_id] = sent_message.message_id

            except Exception as e:
                logging.warning(f"Could not send comment to {user_id}: {e}")
                await safe_send_message(user_id, f"⚠️ Error displaying comment.")
            await asyncio.sleep(0.1)

    nav_row = []
    if use_pagination:
        if page > 1: nav_row.append(InlineKeyboardButton(text="⬅️ Prev", callback_data=f"comments_page_{confession_id}_{page-1}"))
        if total_pages > 1: nav_row.append(InlineKeyboardButton(text=f"Page {page}/{total_pages}", callback_data="noop"))
        if page < total_pages: nav_row.append(InlineKeyboardButton(text="Next ➡️", callback_data=f"comments_page_{confession_id}_{page+1}"))
    
    nav_keyboard = InlineKeyboardMarkup(inline_keyboard=[nav_row, [InlineKeyboardButton(text="➕ Add Comment", callback_data=f"add_{confession_id}")]])
    
    if use_pagination:
        end_txt = f"Displaying page {page}/{total_pages}. Total {total_count} Comments"
    else:
        end_txt = f"Showing all {total_count} comments"

    await safe_send_message(user_id, end_txt, reply_markup=nav_keyboard)

async def show_comment_thread(user_id: int, confession_id: int, parent_comment_id: int):
    """Shows only a specific comment thread (parent comment and its replies)."""
    async with db.acquire() as conn:
        conf_data = await conn.fetchrow("SELECT status, user_id FROM confessions WHERE id = $1", confession_id)
        if not conf_data or conf_data['status'] != 'approved':
            await safe_send_message(user_id, f"Confession #{confession_id} not found or not approved.")
            return

        confession_owner_id = conf_data['user_id']
        
        # Fetch the parent comment
        parent_comment = await conn.fetchrow("""
            SELECT c.id, c.user_id, c.text, c.sticker_file_id, c.animation_file_id, c.voice_file_id, c.photo_file_id, c.photo_caption, c.created_at,
                   COALESCE(up.points, 0) as user_points,
                   us.nickname,
                   us.profile_emoji
            FROM comments c
            LEFT JOIN user_points up ON c.user_id = up.user_id
            LEFT JOIN user_status us ON c.user_id = us.user_id
            WHERE c.id = $1 AND c.confession_id = $2
        """, parent_comment_id, confession_id)
        
        if not parent_comment:
            await safe_send_message(user_id, "The comment you're looking for was not found or has been deleted.")
            return
        
        # Fetch all replies to this parent comment
        replies = await conn.fetch("""
            SELECT c.id, c.user_id, c.text, c.sticker_file_id, c.animation_file_id, c.voice_file_id, c.photo_file_id, c.photo_caption, c.created_at,
                   COALESCE(up.points, 0) as user_points,
                   us.nickname,
                   us.profile_emoji
            FROM comments c
            LEFT JOIN user_points up ON c.user_id = up.user_id
            LEFT JOIN user_status us ON c.user_id = us.user_id
            WHERE c.parent_comment_id = $1 AND c.confession_id = $2
            ORDER BY c.created_at ASC
        """, parent_comment_id, confession_id)

    # Display thread header
    await safe_send_message(user_id, f"<b>📌 Comment Thread in Confession #{confession_id}</b>")
    
    db_id_to_message_id: Dict[int, int] = {}
    
    # Display parent comment
    async def display_comment(c_data, is_parent=False):
        db_id, commenter_uid = c_data['id'], c_data['user_id']
        medal_str = f" ⚡︎{c_data.get('user_points', 0)} Aura"
        nickname = c_data.get('nickname') or "Anonymous"
        
        profile_token = await get_or_create_profile_token(commenter_uid)
        profile_url = f"https://t.me/{bot_info.username}?start=profile_{profile_token}"
        
        if commenter_uid == confession_owner_id:
            tag = f"<a href='{profile_url}'>✅ Confession Author</a>"
        elif commenter_uid == user_id:
            tag = f"<a href='{profile_url}'>(You)</a>"
        else:
            tag = f"<a href='{profile_url}'>{html.quote(nickname)}</a>"

        profile_emoji = c_data.get('profile_emoji') or '👤'
        admin_info = f" [UID: <code>{commenter_uid}</code>]" if user_id == ADMIN_ID else ""
        display_tag = f" {profile_emoji} {tag}{medal_str}"

        reply_to_msg_id = None
        text_reply_prefix = ""
        
        # For replies, add a reference to the parent
        if not is_parent and parent_comment_id in db_id_to_message_id:
            reply_to_msg_id = db_id_to_message_id[parent_comment_id]

        metadata_text = f"<i>{display_tag}{admin_info}</i>"
        keyboard = await build_comment_keyboard(db_id, commenter_uid, user_id, confession_owner_id)
        
        sent_message = None
        try:
            if c_data['sticker_file_id']:
                sent_message = await bot.send_sticker(user_id, sticker=c_data['sticker_file_id'], reply_to_message_id=reply_to_msg_id)
                await bot.send_message(user_id, f"{text_reply_prefix}{metadata_text}", reply_markup=keyboard, disable_web_page_preview=True)
            elif c_data['animation_file_id']:
                sent_message = await bot.send_animation(user_id, animation=c_data['animation_file_id'], reply_to_message_id=reply_to_msg_id)
                await bot.send_message(user_id, f"{text_reply_prefix}{metadata_text}", reply_markup=keyboard, disable_web_page_preview=True)
            elif c_data.get('voice_file_id'):
                sent_message = await bot.send_voice(user_id, voice=c_data['voice_file_id'], reply_to_message_id=reply_to_msg_id)
                await bot.send_message(user_id, f"{text_reply_prefix}🎙️ Voice Message\n\n{metadata_text}", reply_markup=keyboard, disable_web_page_preview=True)
            elif c_data.get('photo_file_id'):
                # Send photo with caption if available
                caption_text = ""
                if c_data.get('photo_caption'):
                    caption_text = f"📷 {html.quote(c_data['photo_caption'])}\n\n{metadata_text}"
                else:
                    caption_text = f"📷 Photo\n\n{metadata_text}"
                
                sent_message = await bot.send_photo(
                    user_id, 
                    photo=c_data['photo_file_id'], 
                    caption=caption_text,
                    reply_to_message_id=reply_to_msg_id
                )
                # Try to add keyboard to photo message
                try:
                    await bot.edit_message_reply_markup(
                        chat_id=user_id,
                        message_id=sent_message.message_id,
                        reply_markup=keyboard
                    )
                except:
                    # If editing fails, send keyboard in separate message
                    await bot.send_message(user_id, "⬆️", reply_markup=keyboard, disable_web_page_preview=True)
            elif c_data['text']:
                full_text = f"{text_reply_prefix}💬 {html.quote(c_data['text'])}\n\n{metadata_text}"
                sent_message = await bot.send_message(user_id, full_text, reply_markup=keyboard, disable_web_page_preview=True, reply_to_message_id=reply_to_msg_id)
            
            if sent_message:
                db_id_to_message_id[db_id] = sent_message.message_id

        except Exception as e:
            logging.warning(f"Could not send comment to {user_id}: {e}")
            await safe_send_message(user_id, f"⚠️ Error displaying comment.")
        await asyncio.sleep(0.1)
    
    # Display parent comment first
    await display_comment(dict(parent_comment), is_parent=True)
    
    # Display all replies
    for reply_row in replies:
        await display_comment(dict(reply_row), is_parent=False)
    
    # Add navigation buttons
    total_count = 1 + len(replies)
    nav_keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💬 View All Comments", callback_data=f"browse_{confession_id}")],
        [InlineKeyboardButton(text="➕ Add Reply", callback_data=f"reply_{parent_comment_id}")]
    ])
    
    await safe_send_message(user_id, f"<i>End of thread ({total_count} message{'s' if total_count != 1 else ''} displayed)</i>", reply_markup=nav_keyboard)

# --- Public Profile Viewer ---
async def show_public_profile(viewer_user_id: int, profile_user_id: int):
    async with db.acquire() as conn:
        await conn.execute("INSERT INTO user_status(user_id) VALUES ($1) ON CONFLICT DO NOTHING", profile_user_id)
        
        profile_data = await conn.fetchrow("""
            SELECT 
                us.nickname, us.profile_emoji, us.bio, us.allow_contact, 
                us.gender, us.campus, us.year, us.department, us.interests,
                us.show_gender, us.show_campus, us.show_year, us.show_department, us.show_interests,
                COALESCE(up.points, 0) as points
            FROM user_status us
            LEFT JOIN user_points up ON us.user_id = up.user_id
            WHERE us.user_id = $1
        """, profile_user_id)

        # --- NEW: Get follower/following counts ---
        follower_count = await conn.fetchval("SELECT COUNT(*) FROM user_follows WHERE following_id = $1", profile_user_id) or 0
        following_count = await conn.fetchval("SELECT COUNT(*) FROM user_follows WHERE follower_id = $1", profile_user_id) or 0
        
        # --- NEW: Check if viewer is following this user ---
        is_following = await conn.fetchval("SELECT 1 FROM user_follows WHERE follower_id = $1 AND following_id = $2", viewer_user_id, profile_user_id) is not None

    if not profile_data:
        await safe_send_message(viewer_user_id, "This user's profile could not be found.")
        return

    nickname = html.quote(profile_data.get('nickname') or "Anonymous")
    emoji = profile_data.get('profile_emoji') or '👤'
    points = profile_data.get('points', 0)
    bio = html.quote(profile_data.get('bio') or "This user has not set a bio yet.")
    allow_contact = profile_data.get('allow_contact', False)

    profile_text = (
        f"{emoji} <b>{nickname}'s Public Profile</b>\n\n"
        f"⚡︎ <b>Aura Points:</b> {points}\n"
        f"👥 <b>Followers:</b> {follower_count} | <b>Following:</b> {following_count}\n\n"
        f"📝 <b>Bio:</b>\n<i>{bio}</i>\n"
    )

    details = []
    if profile_data.get('show_gender') and profile_data.get('gender'):
        details.append(f"<b>Gender:</b> {html.quote(profile_data['gender'])}")
    if profile_data.get('show_campus') and profile_data.get('campus'):
        details.append(f"<b>Campus:</b> {html.quote(profile_data['campus'])}")
    if profile_data.get('show_year') and profile_data.get('year'):
        details.append(f"<b>Year:</b> {html.quote(profile_data['year'])}")
    if profile_data.get('show_department') and profile_data.get('department'):
        details.append(f"<b>Department:</b> {html.quote(profile_data['department'])}")
    if profile_data.get('show_interests') and profile_data.get('interests'):
        interests_str = ", ".join(profile_data['interests'])
        details.append(f"<b>Interests:</b> {html.quote(interests_str)}")
    
    if details:
        profile_text += "\n" + "\n".join(details)


    builder = InlineKeyboardBuilder()
    if viewer_user_id != profile_user_id:
        # --- NEW: Add Follow/Unfollow button ---
        if is_following:
            builder.button(text="✅ Unfollow", callback_data=f"unfollow_user_{profile_user_id}")
        else:
            builder.button(text="➕ Follow", callback_data=f"follow_user_{profile_user_id}")

        builder.button(text="⚠️ Report User", callback_data=f"report_user_{profile_user_id}")
        
        async with db.acquire() as conn:
            chat_status = await conn.fetchval(
                "SELECT status FROM chat_requests WHERE (requester_id = $1 AND recipient_id = $2) OR (requester_id = $2 AND recipient_id = $1)",
                viewer_user_id, profile_user_id
            )

        if chat_status == 'accepted':
             builder.button(text="💬 Send Message", callback_data=f"start_chat_{profile_user_id}")
        elif chat_status == 'pending':
            builder.button(text="⏳ Chat Request Sent", callback_data="noop")
        elif allow_contact:
            builder.button(text="🤝 Request to Chat", callback_data=f"request_chat_{profile_user_id}")
    
    builder.adjust(1)
    await safe_send_message(viewer_user_id, profile_text, reply_markup=builder.as_markup())


# --- CHANNEL JOIN AD HELPERS ---
async def get_active_channel_join_ad() -> Optional[Dict[str, Any]]:
    """Check if there's an active channel join ad requirement."""
    async with db.acquire() as conn:
        ad = await conn.fetchrow("""
            SELECT id, channel_username, channel_id, custom_message, expires_at
            FROM ads
            WHERE is_active = TRUE 
            AND requires_channel_join = TRUE
            AND expires_at > NOW()
            ORDER BY posted_at DESC
            LIMIT 1
        """)
        return dict(ad) if ad else None


async def check_user_channel_verification(user_id: int, ad_id: int) -> bool:
    """Check if user has verified their membership for a specific ad."""
    async with db.acquire() as conn:
        verified = await conn.fetchval("""
            SELECT 1 FROM user_channel_verifications
            WHERE user_id = $1 AND ad_id = $2
        """, user_id, ad_id)
        return verified is not None


async def show_channel_join_requirement(user_id: int, ad: Dict[str, Any]):
    """Show the channel join requirement message to the user."""
    channel_username = ad['channel_username']
    custom_message = ad['custom_message']
    ad_id = ad['id']
    
    message_text = (
        "<b>📢 Channel Join Required</b>\n\n"
        f"{html.quote(custom_message)}\n\n"
        f"<b>Channel:</b> @{channel_username}\n\n"
        "Please join the channel to continue using the bot."
    )
    
    # Create inline keyboard with join and verify buttons
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="📢 Join Channel",
            url=f"https://t.me/{channel_username}"
        )],
        [InlineKeyboardButton(
            text="✅ I've Joined",
            callback_data=f"verify_channel_{ad_id}"
        )]
    ])
    
    await safe_send_message(user_id, message_text, reply_markup=keyboard)


class BlockUserMiddleware(BaseMiddleware):
    async def __call__(self, handler, event: types.TelegramObject, data: Dict[str, Any]) -> Any:
        user = data.get('event_from_user')
        if not user:
            return await handler(event, data)

        user_id = user.id
        if user_id in [ADMIN_ID, CONTACT_ADMIN_ID]:
            return await handler(event, data)

        async with db.acquire() as conn:
            status = await conn.fetchrow("SELECT is_blocked, blocked_until, block_reason FROM user_status WHERE user_id = $1", user_id)
        
        if status and status['is_blocked']:
            now = datetime.now(timezone.utc)
            if status['blocked_until'] and status['blocked_until'] < now:
                async with db.acquire() as conn:
                    await conn.execute("UPDATE user_status SET is_blocked = FALSE, blocked_until = NULL, block_reason = NULL WHERE user_id = $1", user_id)
                return await handler(event, data)
            else:
                expiry_info = f"until {status['blocked_until'].strftime('%Y-%m-%d %H:%M %Z')}" if status['blocked_until'] else "permanently"
                reason_info = f"\nReason: <i>{html.quote(status['block_reason'])}</i>" if status['block_reason'] else ""
                
                block_message = f"❌ <b>You are blocked from using this bot {expiry_info}.</b>{reason_info}"

                if isinstance(event, types.CallbackQuery):
                    await event.answer(f"You are blocked {expiry_info}.", show_alert=True)
                elif isinstance(event, types.Message):
                    await event.answer(block_message)
                return

        return await handler(event, data)

# --- Handlers ---

# --- FIX: Corrected parsing for follow/unfollow actions ---
@dp.callback_query(F.data.startswith(("follow_user_", "unfollow_user_")))
async def handle_follow_toggle(callback_query: types.CallbackQuery):
    parts = callback_query.data.split('_') # e.g., ['follow', 'user', '12345']
    action = parts[0] # 'follow' or 'unfollow'
    profile_user_id = int(parts[2])
    viewer_user_id = callback_query.from_user.id

    if profile_user_id == viewer_user_id:
        await callback_query.answer("You cannot follow yourself.", show_alert=True)
        return

    async with db.acquire() as conn:
        if action == "follow":
            try:
                await conn.execute(
                    "INSERT INTO user_follows (follower_id, following_id) VALUES ($1, $2)",
                    viewer_user_id, profile_user_id
                )
                await callback_query.answer(f"You are now following this user.", show_alert=False)

                # Send notification to the followed user
                viewer_info = await conn.fetchrow("SELECT nickname, profile_emoji FROM user_status WHERE user_id = $1", viewer_user_id)
                viewer_nickname = html.quote(viewer_info.get('nickname') or "An anonymous user") if viewer_info else "An anonymous user"
                viewer_emoji = viewer_info.get('profile_emoji') if viewer_info else '👤'
                
                await safe_send_message(
                    profile_user_id,
                    f"🆕 You have a new follower: {viewer_emoji} <b>{viewer_nickname}</b>!"
                )
            except asyncpg.exceptions.UniqueViolationError:
                await callback_query.answer("You are already following this user.", show_alert=True)
        
        elif action == "unfollow":
            await conn.execute(
                "DELETE FROM user_follows WHERE follower_id = $1 AND following_id = $2",
                viewer_user_id, profile_user_id
            )
            await callback_query.answer("You have unfollowed this user.", show_alert=False)

    # Refresh the profile view by deleting the old message and sending a new one
    try:
        await callback_query.message.delete()
    except TelegramBadRequest:
        pass # Message might already be gone or inaccessible
    await show_public_profile(viewer_user_id, profile_user_id)

@dp.message(Command("rules"))
async def show_rules(message: types.Message):
    rules_text = (
        "<b>📜 Bot Rules & Regulations</b>\n\n"
        "<b>To keep the community safe, respectful, and meaningful, please follow these guidelines when using the bot:</b>\n\n"
        "1.  <b>Stay Relevant:</b> This space is mainly for sharing confessions, experiences, and thoughts.\n\n - Avoid using it just to ask random questions you could easily Google or ask in the right place.\n\n - Some student-related questions may be approved if they benefit the community.\n\n"
        "2.  <b>Respectful Communication:</b> Sensitive topics (political, religious, cultural, etc.) are allowed but must be discussed with respect.\n\n"
        "3.  <b>No Harmful Content:</b> You may mention names, but at your own risk.\n\n - The bot and admins are not responsible for any consequences.\n\n - If someone mentioned requests removal, their name will be taken down.\n\n"
        "4.  <b>Names & Responsibility:</b> Do not share personal identifying information about yourself or others.\n\n"
        "5.  <b>Anonymity & Privacy:</b> don’t reveal private details of others (contacts, adress, etc.) without consent.\n\n"
        "6.  <b>Constructive Environment:</b> Keep confessions genuine. Avoid spam, trolling, or repeated submissions.\n\n - Respect moderators’ decisions on approvals, edits, or removals.\n\n\n"
        "<i>Use this space to connect, share, and learn, not to spread misinformation or cause unnecessary drama.</i>"
    )
    await message.answer(rules_text, reply_markup=get_main_keyboard(message.from_user.id))

@dp.message(Command("start"))
async def start(message: types.Message, state: FSMContext, command: CommandObject | None = None):
    await state.clear()
    user_id = message.from_user.id
    
    # Skip channel check for admins
    if user_id not in [ADMIN_ID, CONTACT_ADMIN_ID]:
        # Check for active channel join requirement
        active_ad = await get_active_channel_join_ad()
        if active_ad:
            # Check if user has already verified
            is_verified = await check_user_channel_verification(user_id, active_ad['id'])
            if not is_verified:
                # Show channel join requirement
                await show_channel_join_requirement(user_id, active_ad)
                return
    
    keyboard = get_main_keyboard(user_id)

    async with db.acquire() as conn:
        has_accepted = await conn.fetchval("SELECT has_accepted_rules FROM user_status WHERE user_id = $1", user_id)

    if has_accepted is None:
        async with db.acquire() as conn:
            await conn.execute("INSERT INTO user_status(user_id) VALUES ($1) ON CONFLICT DO NOTHING", user_id)
        has_accepted = False


    if not has_accepted:
        rules_text = (
            "<b>📜 Bot Rules & Regulations</b>\n\n"
            "<b>To keep the community safe, respectful, and meaningful, please follow these guidelines when using the bot:</b>\n\n"
            "1.  <b>Stay Relevant:</b> This space is mainly for sharing confessions, experiences, and thoughts.\n\n - Avoid using it just to ask random questions you could easily Google or ask in the right place.\n\n - Some student-related questions may be approved if they benefit the community.\n\n"
            "2.  <b>Respectful Communication:</b> Sensitive topics (political, religious, cultural, etc.) are allowed but must be discussed with respect.\n\n"
            "3.  <b>No Harmful Content:</b> You may mention names, but at your own risk.\n\n - The bot and admins are not responsible for any consequences.\n\n - If someone mentioned requests removal, their name will be taken down.\n\n"
            "4.  <b>Names & Responsibility:</b> Do not share personal identifying information about yourself or others.\n\n"
            "5.  <b>Anonymity & Privacy:</b> don't reveal private details of others (contacts, adress, etc.) without consent.\n\n"
            "6.  <b>Constructive Environment:</b> Keep confessions genuine. Avoid spam, trolling, or repeated submissions.\n\n - Respect moderators' decisions on approvals, edits, or removals.\n\n\n"
            "<i>Use this space to connect, share, and learn, not to spread misinformation or cause unnecessary drama.</i>"
        )
        accept_keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ I Accept the Rules", callback_data="accept_rules")]
        ])
        await message.answer(rules_text, reply_markup=accept_keyboard)
        return

    deep_link_args = command.args if command else None
    if deep_link_args:
        try:
            if deep_link_args.startswith("view_"):
                parts = deep_link_args.split("_")
                conf_id = int(parts[1])
                
                if len(parts) == 4 and parts[2] == "page":
                    page_num = int(parts[3])
                    logging.info(f"User {user_id} deep linked to conf {conf_id}, page {page_num}")
                    await show_comments_for_confession(user_id, conf_id, page=page_num)
                    return

                logging.info(f"User {message.from_user.id} started via deep link for conf {conf_id}")
                async with db.acquire() as conn:
                    conf_data = await conn.fetchrow("SELECT c.text, c.categories, c.status, c.user_id, COUNT(com.id) as comment_count FROM confessions c LEFT JOIN comments com ON c.id = com.confession_id WHERE c.id = $1 GROUP BY c.id", conf_id)
                if not conf_data or conf_data['status'] != 'approved':
                    await message.answer(f"Confession #{conf_id} not found or not approved."); return
                comm_count = conf_data['comment_count']; categories = conf_data['categories'] or []; category_tags = " ".join([f"#{html.quote(cat)}" for cat in categories]) if categories else "#Unknown"
                txt = f"<b>Confession #{conf_id}</b>\n\n{html.quote(conf_data['text'])}\n\n{category_tags}"
                builder = InlineKeyboardBuilder()
                builder.button(text="➕ Add Comment", callback_data=f"add_{conf_id}")
                builder.button(text=f"💬 Browse Comments ({comm_count})", callback_data=f"browse_{conf_id}")
                builder.adjust(1, 1)
                await message.answer(txt, reply_markup=builder.as_markup())
            
            elif deep_link_args.startswith("thread_"):
                # Handle thread view: thread_{confession_id}_{parent_comment_id}
                parts = deep_link_args.split("_")
                if len(parts) >= 3:
                    conf_id = int(parts[1])
                    parent_comment_id = int(parts[2])
                    logging.info(f"User {user_id} deep linked to thread: confession {conf_id}, parent comment {parent_comment_id}")
                    await show_comment_thread(user_id, conf_id, parent_comment_id)
                else:
                    await message.answer("Invalid thread link.", reply_markup=keyboard)
            
            elif deep_link_args.startswith("profile_"):
                # --- FIX IS HERE ---
                # OLD: profile_token = deep_link_args.split("_")[1] 
                # NEW: Use slicing to robustly remove the prefix
                profile_token = deep_link_args[len("profile_"):]

                async with db.acquire() as conn:
                    profile_user_id = await conn.fetchval(
                        "SELECT user_id FROM user_status WHERE profile_token = $1", profile_token
                    )
                
                if profile_user_id:
                    logging.info(f"User {user_id} deep linked to profile of {profile_user_id} via token.")
                    await show_public_profile(user_id, profile_user_id)
                else:
                    await message.answer("This profile link is invalid or has expired.", reply_markup=keyboard)

            else:
                await message.answer("Invalid link.", reply_markup=keyboard)

        except (ValueError, IndexError): await message.answer("Invalid link.")
        except Exception as e: logging.error(f"Err handling deep link '{deep_link_args}': {e}", exc_info=True); await message.answer("Error processing link.")
    else: await message.answer("Welcome! Use Confess to submit confessions", reply_markup=keyboard)

@dp.callback_query(F.data == "accept_rules")
async def handle_accept_rules(callback_query: types.CallbackQuery):
    user_id = callback_query.from_user.id
    async with db.acquire() as conn:
        await conn.execute(
            """INSERT INTO user_status (user_id, has_accepted_rules) VALUES ($1, TRUE)
               ON CONFLICT (user_id) DO UPDATE SET has_accepted_rules = TRUE""",
            user_id
        )
    await callback_query.message.delete()
    await callback_query.message.answer("Thank you for accepting the rules! You can now use the bot.\n\n"
                                          "Use the buttons below to get started.",
                                          reply_markup=get_main_keyboard(user_id))
    await callback_query.answer("Rules accepted!")


@dp.message(Command("help"), StateFilter(None))
@dp.message(F.text == "ℹ️ Help", StateFilter(None))
async def show_help(message: types.Message):
    help_text = (
        "<b>Welcome to the Confession Bot!</b>\n\n"
        "Here's how to use the bot:\n"
        "/confess - Submit a new anonymous confession.\n"
        "/profile - View your profile and history.\n"
        "/start - Show the welcome message.\n"
        "/help - Display this help message.\n"
        "/privacy - View information about data privacy.\n\n"
        "<b>Interact with comments using the buttons:</b>\n"
        "👍/👎: Like/Dislike (+1🏅/-1🏅 for the commenter).\n"
        "↪️ Reply: Reply to a comment (Text, Sticker, or GIF).\n"
        "🤝 Request Contact: (Author only) Ask to contact a commenter.\n\n"
        "Need more info or want to reach the admin directly?"
    )
    action_keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📜 Rules & Regulations", callback_data="show_rules_help")],
        [InlineKeyboardButton(text="✉️ Contact Admin", callback_data="contact_admin_start")]
    ])
    if message.from_user and message.from_user.id == ADMIN_ID:
        help_text += ("\n\n<b>Admin Commands:</b>\n"
                      "🔹 /id &lt;user_id&gt; - Get user info.\n"
                      "🔹 /warn &lt;user_id&gt; &lt;reason&gt; - Send a warning.\n"
                      "🔹 /block &lt;user_id&gt; &lt;duration&gt; [reason] - Temp block (e.g., 7d, 2w).\n"
                      "🔹 /pblock &lt;user_id&gt; [reason] - Permanently block.\n"
                      "🔹 /unblock &lt;user_id&gt; - Unblock a user.")
    elif message.from_user and message.from_user.id == CONTACT_ADMIN_ID:
        help_text += ("\n\n<b>Contact Admin Commands:</b>\n"
                      "🔹 /block &lt;user_id&gt; &lt;duration&gt; [reason] - Temp block (e.g., 7d, 2w).\n"
                      "🔹 /pblock &lt;user_id&gt; [reason] - Permanently block.\n"
                      "🔹 /unblock &lt;user_id&gt; - Unblock a user.")

    await message.answer(help_text, reply_markup=action_keyboard)

@dp.callback_query(F.data == "show_rules_help")
async def show_rules_from_help(callback_query: types.CallbackQuery):
    await callback_query.answer()
    rules_text = (
        "<b>📜 Bot Rules & Regulations</b>\n\n"
        "<b>To keep the community safe, respectful, and meaningful, please follow these guidelines when using the bot:</b>\n\n"
        "1.  <b>Stay Relevant:</b> This space is mainly for sharing confessions, experiences, and thoughts.\n\n - Avoid using it just to ask random questions you could easily Google or ask in the right place.\n\n - Some student-related questions may be approved if they benefit the community.\n\n"
        "2.  <b>Respectful Communication:</b> Sensitive topics (political, religious, cultural, etc.) are allowed but must be discussed with respect.\n\n"
        "3.  <b>No Harmful Content:</b> You may mention names, but at your own risk.\n\n - The bot and admins are not responsible for any consequences.\n\n - If someone mentioned requests removal, their name will be taken down.\n\n"
        "4.  <b>Names & Responsibility:</b> Do not share personal identifying information about yourself or others.\n\n"
        "5.  <b>Anonymity & Privacy:</b> don’t reveal private details of others (contacts, adress, etc.) without consent.\n\n"
        "6.  <b>Constructive Environment:</b> Keep confessions genuine. Avoid spam, trolling, or repeated submissions.\n\n - Respect moderators’ decisions on approvals, edits, or removals.\n\n\n"
        "<i>Use this space to connect, share, and learn, not to spread misinformation or cause unnecessary drama.</i>"
    )
    await callback_query.message.answer(rules_text, reply_markup=get_main_keyboard(callback_query.from_user.id))


@dp.callback_query(F.data == "contact_admin_start", StateFilter(None))
async def start_contact_admin_callback(callback_query: types.CallbackQuery, state: FSMContext):
    await state.set_state(ContactAdminForm.waiting_for_message)
    await callback_query.answer("Please send your message to the admin.")
    await callback_query.message.answer(
        "Please send the message you want to forward to the admin.",
        reply_markup=cancel_keyboard
    )

@dp.message(Command("privacy"), StateFilter(None))
async def show_privacy(message: types.Message):
    privacy_policy_url = "https://telegra.ph/Privacy-Policy-for-AAU-Confessions-Bot-10-28"
    privacy_text = (
    "<b>Privacy Information</b>\n\n"
    "▪️ Your Telegram User ID is stored for functionality but is **never** shown to other users.\n"
    "▪️ Your public identity (Nickname, Emoji, Bio, Aura points) is visible on your comments and profile.\n"
    "▪️ You control what extra details (like Campus or Interests) are visible on your profile.\n"
    "▪️ Other users can follow you and request to chat. You must approve any chat request.\n"
    "▪️ Using AI features sends your confession text to Google's AI for processing.\n"
    "▪️ Reporting a user or comment links your User ID to the report for admin review only.\n"
    f"▪️ The bot admin can access stored User IDs for moderation and support.\n\n"
    f'For more details, read our full <a href="{privacy_policy_url}">Privacy Policy</a>.'
    )
    await message.answer(privacy_text, disable_web_page_preview=True)

@dp.message(Command("cancel"), StateFilter('*'))
@dp.message(F.text == "❌ Cancel", StateFilter('*'))
async def cancel_any_state(message: types.Message, state: FSMContext):
    current_state = await state.get_state()
    if current_state is None:
        await message.answer("You have nothing to cancel.", reply_markup=get_main_keyboard(message.from_user.id))
        return

    await state.clear()
    await message.answer("Action cancelled. You are back at the main menu.", reply_markup=get_main_keyboard(message.from_user.id))

@dp.message(ContactAdminForm.waiting_for_message, F.text)
async def receive_admin_message(message: types.Message, state: FSMContext):
    user_id = message.from_user.id; user_info = message.from_user; message_text = message.text
    if not user_info: await message.answer("Could not identify sender. Action cancelled."); await state.clear(); return
    if len(message_text) < 5: await message.answer("Message too short."); return
    if len(message_text) > 2000: await message.answer("Message too long."); return
    admin_message = ( f"<b>📬 Contact Request from User</b>\n\n"
        f"<b>User ID:</b> <code>{user_id}</code>\n"
        f"<b>Username:</b> @{user_info.username if user_info.username else 'Not Set'}\n"
        f"<b>Message:</b>\n{html.quote(message_text)}"
        f"\n\n---\nReply to this message to respond to User ID <code>{user_id}</code>." )
    try:
        # Send ONLY to contact admin
        await bot.send_message(CONTACT_ADMIN_ID, admin_message)
        await message.answer("✅ Your message has been sent to the admin.", reply_markup=get_main_keyboard(user_id))
    except Exception as e: logging.error(f"Failed forward msg from {user_id} to admin: {e}"); await message.answer("❌ Error sending message.")
    finally: await state.clear()

@dp.message(F.reply_to_message)
async def handle_admin_reply(message: types.Message, state: FSMContext):
    # Only allow contact admin to reply to contact messages
    if message.from_user.id != CONTACT_ADMIN_ID:
        return
    
    if await state.get_state() is not None: return
    replied_to = message.reply_to_message
    if replied_to and replied_to.text and ("⚠️ New Comment Report" in replied_to.text or "⚠️ New User Report" in replied_to.text): return
    global bot_info;
    if not bot_info or not replied_to or not replied_to.from_user or replied_to.from_user.id != bot_info.id: return
    target_user_id = None;
    try:
        text_to_search = replied_to.html_text
        start_index = text_to_search.find("<code>") + len("<code>")
        end_index = text_to_search.find("</code>", start_index)
        target_user_id = int(text_to_search[start_index:end_index])
    except (ValueError, AttributeError):
        logging.warning("Could not extract user ID from admin reply context.")
        return
    if target_user_id:
        sent = await safe_send_message(target_user_id, f"💬 <b>Admin Reply:</b>\n\n{html.quote(message.text or '')}")
        if sent: await message.reply("✅ Reply sent to the user.")
        else: await message.reply("⚠️ Failed to send reply. User may have blocked the bot.")

@dp.message(Command("id"))
async def get_user_info_command(message: types.Message, command: CommandObject):
    if not message.from_user or message.from_user.id != ADMIN_ID: return
    if not command.args: await message.reply("Usage: /id <user_id>"); return
    try: target_user_id = int(command.args.strip())
    except ValueError: await message.reply("Invalid User ID."); return
    info_parts = [f"ℹ️ <b>User Info for ID:</b> <code>{target_user_id}</code>\n"];
    try:
        chat_info = await bot.get_chat(target_user_id)
        info_parts.append(f"<b>Username:</b> @{html.quote(chat_info.username or 'Not Set')}")
        info_parts.append(f"<b>First Name:</b> {html.quote(chat_info.first_name or 'N/A')}")
    except Exception as e: info_parts.append(f"⚠️ <b>Telegram Details:</b> Could not fetch. (Error: {e})")
    try:
        async with db.acquire() as conn:
            user_points = await get_user_points(target_user_id)
            conf_count = await conn.fetchval("SELECT COUNT(*) FROM confessions WHERE user_id = $1", target_user_id)
            comm_count = await conn.fetchval("SELECT COUNT(*) FROM comments WHERE user_id = $1", target_user_id)
            status_data = await conn.fetchrow("SELECT * FROM user_status WHERE user_id = $1", target_user_id)
            
            info_parts.append(f"\n<b>Bot Interaction:</b>\n  - <b>Aura Points:</b> ⚡︎ {user_points}\n  - <b>Confessions:</b> {conf_count}\n  - <b>Comments:</b> {comm_count}")
            if status_data:
                info_parts.append(f"  - <b>Nickname:</b> {html.quote(status_data['nickname'] or 'Default')} {status_data['profile_emoji'] or ''}")
                if status_data['nickname_last_changed_at']:
                    can_change_at = status_data['nickname_last_changed_at'] + NICKNAME_COOLDOWN
                    info_parts.append(f"  - <b>Can Change Nickname:</b> {can_change_at.strftime('%Y-%m-%d')}")
                
                info_parts.append(f"  - <b>Allows Contact:</b> {'Yes' if status_data['allow_contact'] else 'No'}")
                info_parts.append(f"  - <b>Accepted Rules:</b> {'Yes' if status_data['has_accepted_rules'] else 'No'}")
                if status_data['is_blocked']:
                    expiry = f"until {status_data['blocked_until'].strftime('%Y-%m-%d')}" if status_data['blocked_until'] else "Permanently"
                    info_parts.append(f"  - <b>Status:</b> ❌ Blocked ({expiry})")
    except Exception as e: info_parts.append(f"\n❌ <b>Bot Interaction:</b> Error fetching database info: {e}")
    await message.reply("\n".join(info_parts));

# --- /profile Command and Handlers (REORGANIZED) ---

async def _render_customization_menu(user_id: int) -> Tuple[str, InlineKeyboardMarkup]:
    """Helper function to build the main customization menu text and keyboard."""
    async with db.acquire() as conn:
        settings = await conn.fetchrow("SELECT nickname, profile_emoji, bio FROM user_status WHERE user_id = $1", user_id)
    
    current_nickname = settings.get('nickname') if settings else None
    current_emoji = settings.get('profile_emoji') if settings else '👤'
    current_bio = settings.get('bio') if settings else None

    settings_text = (
        "<b>🎨 Profile Customization</b>\n\n"
        "Here you can change your public appearance in the bot.\n\n"
        f"<b>Profile Emoji:</b> {current_emoji}\n"
        f"<b>Nickname:</b> {html.quote(current_nickname or 'Default (Anonymous)')}\n"
        f"<b>Bio:</b> {html.quote(current_bio or 'Not set')}"
    )
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎨 Change Profile Emoji", callback_data="settings_change_emoji")],
        [InlineKeyboardButton(text="✏️ Change Nickname", callback_data="settings_change_nickname")],
        [InlineKeyboardButton(text="📝 Set/Update Bio", callback_data="settings_change_bio")],
        [InlineKeyboardButton(text="ℹ️ Edit Profile Details & Visibility", callback_data="profile_details_menu")],
        [InlineKeyboardButton(text="⬅️ Back to Profile", callback_data="profile_menu_main_1")]
    ])
    return settings_text, keyboard


async def _render_general_settings_menu(user_id: int) -> Tuple[str, InlineKeyboardMarkup]:
    """Helper function to build the general settings submenu."""
    async with db.acquire() as conn:
        settings = await conn.fetchrow(
            "SELECT comments_per_page, allow_contact, voice_effect_preset FROM user_status WHERE user_id = $1", 
            user_id
        )

    current_page_size = settings.get('comments_per_page') if settings else None
    allow_contact = settings.get('allow_contact', True) if settings else True
    cpp_display = "All" if current_page_size == 0 else (current_page_size if current_page_size is not None else f'Default ({PAGE_SIZE})')
    contact_status = "✅ On" if allow_contact else "❌ Off"
    
    # Map voice effect to display name
    voice_effect_display = {
        'original': '🎤 Original',
        'manly': '💪 Manly',
        'female': '👩 Female',
        'chipmunk': '🐿️ Chipmunk'
    }
    current_voice_effect = settings.get('voice_effect_preset') if settings else 'original'
    voice_effect_text = voice_effect_display.get(current_voice_effect or 'original', '🎤 Original')

    settings_text = (
        "<b>⚙️ General Settings</b>\n\n"
        f"<b>Comments Per Page:</b> {cpp_display}\n"
        f"<b>Allow Chat Requests:</b> {contact_status}\n"
        f"<b>Voice Effect:</b> {voice_effect_text}"
    )
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔔 Notification Settings", callback_data="notification_settings_menu")],
        [InlineKeyboardButton(text="🔢 Set Comments Per Page", callback_data="settings_change_cpp")],
        [InlineKeyboardButton(text=f"📬 Toggle Chat Requests ({'Off' if allow_contact else 'On'})", callback_data="settings_toggle_contact")],
        [InlineKeyboardButton(text=f"🎤 Change Voice Effect", callback_data="set_voice_effect")],
        [InlineKeyboardButton(text="⬅️ Back to Profile", callback_data="profile_menu_main_1")]
    ])
    return settings_text, keyboard


def create_profile_pagination_keyboard(base_callback: str, current_page: int, total_pages: int, back_to: str):
    builder = InlineKeyboardBuilder()
    row = []
    if current_page > 1:
        row.append(InlineKeyboardButton(text="⬅️ Prev", callback_data=f"{base_callback}_{current_page - 1}"))
    if total_pages > 1:
        row.append(InlineKeyboardButton(text=f"Page {current_page}/{total_pages}", callback_data="noop"))
    if current_page < total_pages:
        row.append(InlineKeyboardButton(text="Next ➡️", callback_data=f"{base_callback}_{current_page + 1}"))
    if row:
        builder.row(*row)
    builder.row(InlineKeyboardButton(text="⬅️ Back", callback_data=back_to))
    return builder.as_markup()

@dp.message(Command("profile"))
@dp.message(F.text == "👤 Profile")
async def user_profile(message: types.Message, state: FSMContext):
    await state.clear()
    user_id = message.from_user.id
    
    # Fetch user profile data
    async with db.acquire() as conn:
        profile_data = await conn.fetchrow(
            "SELECT nickname, profile_emoji, bio FROM user_status WHERE user_id = $1",
            user_id
        )
        follower_count = await conn.fetchval(
            "SELECT COUNT(*) FROM user_follows WHERE following_id = $1",
            user_id
        ) or 0
        following_count = await conn.fetchval(
            "SELECT COUNT(*) FROM user_follows WHERE follower_id = $1",
            user_id
        ) or 0
    
    points = await get_user_points(user_id)
    
    # Extract profile information
    nickname = profile_data.get('nickname') if profile_data else None
    emoji = profile_data.get('profile_emoji') if profile_data else '👤'
    bio = profile_data.get('bio') if profile_data else None
    
    # Build profile text
    profile_text = (
        f"{emoji} <b>{html.quote(nickname or 'Anonymous')}</b>\n\n"
        f"⚡︎ <b>Aura:</b> {points}\n"
        f"👥 <b>Followers:</b> {follower_count} | <b>Following:</b> {following_count}\n\n"
    )
    
    if bio:
        profile_text += f"📝 <b>Bio:</b>\n<i>{html.quote(bio)}</i>"
    else:
        profile_text += "<i>No bio set</i>"
    
    # Build keyboard with new layout
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✏️ Edit Profile", callback_data="profile_menu_edit_1")],
        [InlineKeyboardButton(text="📝 My Confessions", callback_data="profile_menu_confessions_1"),
         InlineKeyboardButton(text="💬 My Comments", callback_data="profile_menu_comments_1")],
        [InlineKeyboardButton(text="👥 Following", callback_data="profile_menu_following_1"),
         InlineKeyboardButton(text="👥 Followers", callback_data="profile_menu_followers_1")],
        [InlineKeyboardButton(text="⚙️ Settings", callback_data="profile_menu_settings_1")],
        [InlineKeyboardButton(
            text="💬 My Chats", 
            web_app=types.WebAppInfo(url=os.getenv("CHAT_WEB_APP_URL", "https://aau-chat-app.vercel.app"))
        )]
    ])
    
    await message.answer(profile_text, reply_markup=keyboard)

@dp.callback_query(F.data.startswith("profile_menu_"))
async def handle_profile_menu(callback_query: types.CallbackQuery, state: FSMContext):
    await state.clear() 
    user_id = callback_query.from_user.id
    parts = callback_query.data.split("_")
    action = parts[2]
    page = int(parts[-1]) if len(parts) > 3 else 1 # Default page to 1

    try:
        if action == "main":
            # Fetch user profile data
            async with db.acquire() as conn:
                profile_data = await conn.fetchrow(
                    "SELECT nickname, profile_emoji, bio FROM user_status WHERE user_id = $1",
                    user_id
                )
                follower_count = await conn.fetchval(
                    "SELECT COUNT(*) FROM user_follows WHERE following_id = $1",
                    user_id
                ) or 0
                following_count = await conn.fetchval(
                    "SELECT COUNT(*) FROM user_follows WHERE follower_id = $1",
                    user_id
                ) or 0
            
            points = await get_user_points(user_id)
            
            # Extract profile information
            nickname = profile_data.get('nickname') if profile_data else None
            emoji = profile_data.get('profile_emoji') if profile_data else '👤'
            bio = profile_data.get('bio') if profile_data else None
            
            # Build profile text
            profile_text = (
                f"{emoji} <b>{html.quote(nickname or 'Anonymous')}</b>\n\n"
                f"⚡︎ <b>Aura:</b> {points}\n"
                f"👥 <b>Followers:</b> {follower_count} | <b>Following:</b> {following_count}\n\n"
            )
            
            if bio:
                profile_text += f"📝 <b>Bio:</b>\n<i>{html.quote(bio)}</i>"
            else:
                profile_text += "<i>No bio set</i>"
            
            # Build keyboard with new layout
            keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="✏️ Edit Profile", callback_data="profile_menu_edit_1")],
                [InlineKeyboardButton(text="📝 My Confessions", callback_data="profile_menu_confessions_1"),
                 InlineKeyboardButton(text="💬 My Comments", callback_data="profile_menu_comments_1")],
                [InlineKeyboardButton(text="👥 Following", callback_data="profile_menu_following_1"),
                 InlineKeyboardButton(text="👥 Followers", callback_data="profile_menu_followers_1")],
                [InlineKeyboardButton(text="⚙️ Settings", callback_data="profile_menu_settings_1")],
                [InlineKeyboardButton(
                    text="💬 My Chats",
                    web_app=types.WebAppInfo(url=os.getenv("CHAT_WEB_APP_URL", "https://aau-chat-app.vercel.app"))
                )]
            ])
            await callback_query.message.edit_text(profile_text, reply_markup=keyboard)
        
        elif action == "edit":
            settings_text, keyboard = await _render_customization_menu(user_id)
            await callback_query.message.edit_text(settings_text, reply_markup=keyboard)

        elif action == "confessions":
            async with db.acquire() as conn:
                total_count = await conn.fetchval("SELECT COUNT(*) FROM confessions WHERE user_id = $1", user_id) or 0
                if total_count == 0:
                    await callback_query.answer("You haven't submitted any confessions yet.", show_alert=True)
                    return

                total_pages = (total_count + 5 - 1) // 5
                page = max(1, min(page, total_pages))
                offset = (page - 1) * 5
                confessions = await conn.fetch("SELECT id, text, status, created_at FROM confessions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 5 OFFSET $2", user_id, offset)

            response_text = f"<b>📜 Your Confessions (Page {page}/{total_pages})</b>\n\n"
            builder = InlineKeyboardBuilder()
            for conf in confessions:
                snippet = html.quote(conf['text'][:60]) + ('...' if len(conf['text']) > 60 else '')
                status_emoji = {"approved": "✅", "pending": "⏳", "rejected": "❌", "deleted": "🗑️"}.get(conf['status'], "❓")
                response_text += f"<b>ID:</b> #{conf['id']} ({status_emoji} {conf['status'].capitalize()})\n<i>\"{snippet}\"</i>\n\n"
                if conf['status'] in ['approved', 'pending']:
                    builder.row(InlineKeyboardButton(text=f"Request Deletion for #{conf['id']}", callback_data=f"req_del_conf_{conf['id']}"))

            nav_keyboard = create_profile_pagination_keyboard("profile_menu_confessions", page, total_pages, "profile_menu_main_1")
            final_markup = builder.attach(InlineKeyboardBuilder.from_markup(nav_keyboard)).as_markup()
            await callback_query.message.edit_text(response_text, reply_markup=final_markup)

        elif action == "comments":
            async with db.acquire() as conn:
                total_count = await conn.fetchval("SELECT COUNT(*) FROM comments WHERE user_id = $1", user_id) or 0
                if total_count == 0:
                    await callback_query.answer("You haven't made any comments yet.", show_alert=True)
                    return

                total_pages = (total_count + 5 - 1) // 5
                page = max(1, min(page, total_pages))
                offset = (page - 1) * 5
                comments = await conn.fetch("SELECT id, text, sticker_file_id, animation_file_id, confession_id, created_at FROM comments WHERE user_id = $1 ORDER BY created_at DESC LIMIT 5 OFFSET $2", user_id, offset)

            response_text = f"<b>💬 Your Comments (Page {page}/{total_pages})</b>\n\n"
            for comm in comments:
                if comm['text']: snippet = html.quote(comm['text'][:60]) + ('...' if len(comm['text']) > 60 else '')
                elif comm['sticker_file_id']: snippet = "[Sticker]"
                elif comm['animation_file_id']: snippet = "[GIF]"
                else: snippet = "[Unknown Content]"
                link = f"https://t.me/{bot_info.username}?start=view_{comm['confession_id']}"
                response_text += f"On Confession <a href='{link}'>#{comm['confession_id']}</a>:\n<i>\"{snippet}\"</i>\n\n"

            nav_keyboard = create_profile_pagination_keyboard("profile_menu_comments", page, total_pages, "profile_menu_main_1")
            await callback_query.message.edit_text(response_text, reply_markup=nav_keyboard, disable_web_page_preview=True)
        
        elif action == "following":
            async with db.acquire() as conn:
                total_count = await conn.fetchval("SELECT COUNT(*) FROM user_follows WHERE follower_id = $1", user_id) or 0
                if total_count == 0:
                    await callback_query.answer("You are not following anyone yet.", show_alert=True)
                    return

                total_pages = (total_count + 10 - 1) // 10
                page = max(1, min(page, total_pages))
                offset = (page - 1) * 10
                following = await conn.fetch(
                    """SELECT us.user_id, us.nickname, us.profile_emoji 
                       FROM user_follows uf 
                       JOIN user_status us ON uf.following_id = us.user_id 
                       WHERE uf.follower_id = $1 
                       ORDER BY uf.created_at DESC 
                       LIMIT 10 OFFSET $2""",
                    user_id, offset
                )

            response_text = f"<b>👥 Following (Page {page}/{total_pages})</b>\n\n"
            builder = InlineKeyboardBuilder()
            for user in following:
                nickname = user['nickname'] or 'Anonymous'
                emoji = user['profile_emoji'] or '👤'
                response_text += f"{emoji} {html.quote(nickname)}\n"
                builder.row(InlineKeyboardButton(
                    text=f"View {nickname}'s Profile",
                    callback_data=f"view_profile_{user['user_id']}"
                ))

            nav_keyboard = create_profile_pagination_keyboard("profile_menu_following", page, total_pages, "profile_menu_main_1")
            final_markup = builder.attach(InlineKeyboardBuilder.from_markup(nav_keyboard)).as_markup()
            await callback_query.message.edit_text(response_text, reply_markup=final_markup)
        
        elif action == "followers":
            async with db.acquire() as conn:
                total_count = await conn.fetchval("SELECT COUNT(*) FROM user_follows WHERE following_id = $1", user_id) or 0
                if total_count == 0:
                    await callback_query.answer("You don't have any followers yet.", show_alert=True)
                    return

                total_pages = (total_count + 10 - 1) // 10
                page = max(1, min(page, total_pages))
                offset = (page - 1) * 10
                followers = await conn.fetch(
                    """SELECT us.user_id, us.nickname, us.profile_emoji 
                       FROM user_follows uf 
                       JOIN user_status us ON uf.follower_id = us.user_id 
                       WHERE uf.following_id = $1 
                       ORDER BY uf.created_at DESC 
                       LIMIT 10 OFFSET $2""",
                    user_id, offset
                )

            response_text = f"<b>👥 Followers (Page {page}/{total_pages})</b>\n\n"
            builder = InlineKeyboardBuilder()
            for user in followers:
                nickname = user['nickname'] or 'Anonymous'
                emoji = user['profile_emoji'] or '👤'
                response_text += f"{emoji} {html.quote(nickname)}\n"
                builder.row(InlineKeyboardButton(
                    text=f"View {nickname}'s Profile",
                    callback_data=f"view_profile_{user['user_id']}"
                ))

            nav_keyboard = create_profile_pagination_keyboard("profile_menu_followers", page, total_pages, "profile_menu_main_1")
            final_markup = builder.attach(InlineKeyboardBuilder.from_markup(nav_keyboard)).as_markup()
            await callback_query.message.edit_text(response_text, reply_markup=final_markup)
        elif action == "settings":
            settings_text, keyboard = await _render_general_settings_menu(user_id)
            await callback_query.message.edit_text(settings_text, reply_markup=keyboard)
            
    except TelegramBadRequest as e:
        if "message is not modified" in str(e).lower():
            logging.info("Content for profile menu was not modified.")
        else:
            raise
    finally:
        await callback_query.answer()


@dp.callback_query(F.data == "settings_change_nickname")
async def settings_change_nickname_prompt(callback_query: types.CallbackQuery, state: FSMContext):
    user_id = callback_query.from_user.id
    async with db.acquire() as conn:
        last_changed = await conn.fetchval("SELECT nickname_last_changed_at FROM user_status WHERE user_id = $1", user_id)
    
    if last_changed:
        time_since_change = datetime.now(timezone.utc) - last_changed
        if time_since_change < NICKNAME_COOLDOWN:
            remaining_time = NICKNAME_COOLDOWN - time_since_change
            days, seconds = remaining_time.days, remaining_time.seconds
            hours = seconds // 3600
            await callback_query.answer(
                f"You can change your nickname again in {days} days and {hours} hours.",
                show_alert=True
            )
            return

    await state.set_state(SettingsForm.waiting_for_nickname)
    await callback_query.message.edit_text(
        "Please send your new nickname (max 32 alphanumeric characters).\n"
        "Send 'default' to reset to Anonymous."
    )
    await callback_query.message.answer("Waiting for your nickname...", reply_markup=cancel_keyboard)
    await callback_query.answer()

@dp.message(SettingsForm.waiting_for_nickname, F.text)
async def settings_set_nickname(message: types.Message, state: FSMContext):
    user_id = message.from_user.id
    nickname = message.text.strip()
    feedback = ""
    
    async with db.acquire() as conn:
        if nickname.lower() == 'default':
            await conn.execute(
                """INSERT INTO user_status (user_id, nickname, nickname_last_changed_at) VALUES ($1, NULL, NULL)
                   ON CONFLICT (user_id) DO UPDATE SET nickname = NULL, nickname_last_changed_at = NULL""",
                user_id
            )
            feedback = "✅ Nickname reset to default (Anonymous)."
        else:
            if not (3 <= len(nickname) <= 32 and nickname.replace(' ', '').isalnum()):
                await message.answer("⚠️ Invalid nickname. Please use 3-32 alphanumeric characters and spaces.")
                return
            if nickname.lower() in RESERVED_NICKNAMES:
                await message.answer("⚠️ That nickname is reserved. Please choose another.")
                return
            
            existing_user = await conn.fetchval("SELECT user_id FROM user_status WHERE LOWER(nickname) = $1", nickname.lower())
            if existing_user and existing_user != user_id:
                await message.answer("⚠️ That nickname is already taken. Please choose another.")
                return

            await conn.execute(
                """INSERT INTO user_status (user_id, nickname, nickname_last_changed_at) VALUES ($1, $2, CURRENT_TIMESTAMP)
                   ON CONFLICT (user_id) DO UPDATE SET nickname = $2, nickname_last_changed_at = CURRENT_TIMESTAMP""",
                user_id, nickname
            )
            feedback = f"✅ Nickname set to: <b>{html.quote(nickname)}</b>"

    await state.clear()
    await message.answer(feedback, reply_markup=get_main_keyboard(user_id))
    
    settings_text, keyboard = await _render_customization_menu(message.from_user.id)
    await message.answer(settings_text, reply_markup=keyboard)


@dp.callback_query(F.data == "settings_change_cpp")
async def settings_change_cpp_prompt(callback_query: types.CallbackQuery):
    builder = InlineKeyboardBuilder()
    options = [5, 10, 15, 20, 25]
    for opt in options:
        builder.button(text=str(opt), callback_data=f"settings_set_cpp_{opt}")
    builder.adjust(len(options))
    builder.row(InlineKeyboardButton(text="♾️ All", callback_data="settings_set_cpp_0"))
    builder.row(InlineKeyboardButton(text=f"Reset to Default ({PAGE_SIZE})", callback_data="settings_set_cpp_default"))
    builder.row(InlineKeyboardButton(text="⬅️ Back to Settings", callback_data="profile_menu_settings"))

    await callback_query.message.edit_text(
        "Select how many comments you want to see per page.",
        reply_markup=builder.as_markup()
    )
    await callback_query.answer()

@dp.callback_query(F.data.startswith("settings_set_cpp_"))
async def settings_set_cpp(callback_query: types.CallbackQuery, state: FSMContext):
    user_id = callback_query.from_user.id
    value = callback_query.data.split("_")[-1]

    if value == 'default':
        cpp_to_set = None
        feedback = f"✅ Comments per page reset to default ({PAGE_SIZE})."
    else:
        cpp_to_set = int(value)
        if cpp_to_set == 0:
            feedback = "✅ Comments per page set to show all."
        else:
            feedback = f"✅ Comments per page set to {cpp_to_set}."

    async with db.acquire() as conn:
        await conn.execute(
            """INSERT INTO user_status (user_id, comments_per_page) VALUES ($1, $2)
               ON CONFLICT (user_id) DO UPDATE SET comments_per_page = $2""",
            user_id, cpp_to_set
        )
    
    await callback_query.answer(feedback.split("✅ ")[1], show_alert=True)
    
    settings_text, keyboard = await _render_general_settings_menu(user_id)
    await callback_query.message.edit_text(settings_text, reply_markup=keyboard)


@dp.callback_query(F.data == "settings_change_emoji")
async def settings_change_emoji_prompt(callback_query: types.CallbackQuery):
    builder = InlineKeyboardBuilder()
    for emoji in PROFILE_EMOJIS:
        builder.button(text=emoji, callback_data=f"settings_set_emoji_{emoji}")
    builder.adjust(5) 
    builder.row(InlineKeyboardButton(text="⬅️ Back to Edit Profile", callback_data="profile_menu_edit_1"))
    
    await callback_query.message.edit_text(
        "Choose your new profile emoji.",
        reply_markup=builder.as_markup()
    )
    await callback_query.answer()

@dp.callback_query(F.data.startswith("settings_set_emoji_"))
async def settings_set_emoji(callback_query: types.CallbackQuery, state: FSMContext):
    user_id = callback_query.from_user.id
    emoji = callback_query.data.split("_")[-1]

    if emoji not in PROFILE_EMOJIS:
        await callback_query.answer("Invalid emoji selected.", show_alert=True)
        return

    async with db.acquire() as conn:
        await conn.execute(
            """INSERT INTO user_status (user_id, profile_emoji) VALUES ($1, $2)
               ON CONFLICT (user_id) DO UPDATE SET profile_emoji = $2""",
            user_id, emoji
        )
    
    await callback_query.answer(f"Profile emoji set to {emoji}!", show_alert=True)
    
    settings_text, keyboard = await _render_customization_menu(user_id)
    await callback_query.message.edit_text(settings_text, reply_markup=keyboard)


# --- Bio and Contact Settings Handlers ---
@dp.callback_query(F.data == "settings_change_bio")
async def settings_change_bio_prompt(callback_query: types.CallbackQuery, state: FSMContext):
    await state.set_state(SettingsForm.waiting_for_bio)
    await callback_query.message.edit_text(
        "Please send your new bio (max 250 characters).\n"
        "Send 'remove' to clear your bio."
    )
    await callback_query.message.answer("Waiting for your bio...", reply_markup=cancel_keyboard)
    await callback_query.answer()

@dp.message(SettingsForm.waiting_for_bio, F.text)
async def settings_set_bio(message: types.Message, state: FSMContext):
    user_id = message.from_user.id
    bio_text = message.text.strip()
    feedback = ""

    if len(bio_text) > 250:
        await message.answer("⚠️ Your bio is too long (max 250 characters). Please try again.")
        return

    async with db.acquire() as conn:
        if bio_text.lower() == 'remove':
            await conn.execute(
                "UPDATE user_status SET bio = NULL WHERE user_id = $1", user_id
            )
            feedback = "✅ Your bio has been removed."
        else:
            await conn.execute(
                "INSERT INTO user_status (user_id, bio) VALUES ($1, $2) ON CONFLICT (user_id) DO UPDATE SET bio = $2",
                user_id, bio_text
            )
            feedback = "✅ Your bio has been updated."
    
    await state.clear()
    await message.answer(feedback, reply_markup=get_main_keyboard(user_id))

    settings_text, keyboard = await _render_customization_menu(message.from_user.id)
    await message.answer(settings_text, reply_markup=keyboard)


@dp.callback_query(F.data == "settings_toggle_contact")
async def settings_toggle_contact(callback_query: types.CallbackQuery, state: FSMContext):
    user_id = callback_query.from_user.id
    async with db.acquire() as conn:
        await conn.execute("INSERT INTO user_status(user_id) VALUES ($1) ON CONFLICT DO NOTHING", user_id)
        new_status = await conn.fetchval(
            """UPDATE user_status SET allow_contact = NOT allow_contact
               WHERE user_id = $1 RETURNING allow_contact""",
            user_id
        )
    
    status_text = "enabled" if new_status else "disabled"
    await callback_query.answer(f"Chat requests have been {status_text}.", show_alert=True)
    
    settings_text, keyboard = await _render_general_settings_menu(user_id)
    await callback_query.message.edit_text(settings_text, reply_markup=keyboard)


# --- NEW: Notification Settings Handlers ---

async def _render_notification_settings_menu(user_id: int) -> Tuple[str, InlineKeyboardMarkup]:
    """Helper to build the notification settings menu."""
    async with db.acquire() as conn:
        settings = await conn.fetchrow("""
            SELECT notify_on_confession_comment, notify_on_comment_reply, 
                   notify_on_like, notify_on_followed_user_activity
            FROM user_status WHERE user_id = $1
        """, user_id)

    if not settings: # Failsafe in case a user record wasn't created properly
        async with db.acquire() as conn:
            await conn.execute("INSERT INTO user_status(user_id) VALUES ($1) ON CONFLICT DO NOTHING", user_id)
        settings = {}

    def get_status_text(is_on):
        return "✅ On" if is_on else "❌ Off"

    menu_text = "<b>🔔 Notification Settings</b>\n\nChoose which notifications you would like to receive."

    builder = InlineKeyboardBuilder()
    builder.button(text=f"Comment on My Confession: {get_status_text(settings.get('notify_on_confession_comment', True))}", callback_data="toggle_notify_confession_comment")
    builder.button(text=f"Reply to My Comment: {get_status_text(settings.get('notify_on_comment_reply', True))}", callback_data="toggle_notify_comment_reply")
    builder.button(text=f"Like on My Comment: {get_status_text(settings.get('notify_on_like', True))}", callback_data="toggle_notify_like")
    builder.button(text=f"Activity from Users I Follow: {get_status_text(settings.get('notify_on_followed_user_activity', True))}", callback_data="toggle_notify_followed_user_activity")
    builder.adjust(1)
    builder.row(InlineKeyboardButton(text="⬅️ Back to Settings", callback_data="profile_menu_settings"))

    return menu_text, builder.as_markup()

@dp.callback_query(F.data == "notification_settings_menu")
async def show_notification_settings_menu(callback_query: types.CallbackQuery):
    menu_text, keyboard = await _render_notification_settings_menu(callback_query.from_user.id)
    await callback_query.message.edit_text(menu_text, reply_markup=keyboard)
    await callback_query.answer()

@dp.callback_query(F.data.startswith("toggle_notify_"))
async def toggle_notification_setting(callback_query: types.CallbackQuery):
    user_id = callback_query.from_user.id
    setting_field = callback_query.data.replace("toggle_notify_", "")
    
    allowed_fields = [
        "confession_comment", "comment_reply", 
        "like", "followed_user_activity"
    ]
    db_field = f"notify_on_{setting_field}"

    if setting_field not in allowed_fields:
        await callback_query.answer("Invalid setting.", show_alert=True)
        return
    
    async with db.acquire() as conn:
        await conn.execute(f"UPDATE user_status SET {db_field} = NOT {db_field} WHERE user_id = $1", user_id)
    
    menu_text, keyboard = await _render_notification_settings_menu(user_id)
    await callback_query.message.edit_text(menu_text, reply_markup=keyboard)
    await callback_query.answer(f"{setting_field.replace('_', ' ').title()} notifications toggled.")

# --- Handlers for New Customizable Profile Details ---

async def _render_profile_details_menu(user_id: int) -> Tuple[str, InlineKeyboardMarkup]:
    """Helper to build the profile details & visibility menu."""
    async with db.acquire() as conn:
        settings = await conn.fetchrow("""
            SELECT gender, campus, year, department, interests,
                   show_gender, show_campus, show_year, show_department, show_interests
            FROM user_status WHERE user_id = $1
        """, user_id)

    def get_status_emoji(is_shown):
        return "✅" if is_shown else "❌"

    menu_text = "<b>ℹ️ Edit Profile Details & Visibility</b>\n\nSet your details and toggle whether they appear on your public profile."
    
    builder = InlineKeyboardBuilder()
    builder.button(text=f"Gender: {settings.get('gender') or 'Not Set'}", callback_data="set_detail_gender_1")
    builder.button(text=f"Campus: {settings.get('campus') or 'Not Set'}", callback_data="set_detail_campus_1")
    builder.button(text=f"Year: {settings.get('year') or 'Not Set'}", callback_data="set_detail_year_1")
    builder.button(text=f"Department: {settings.get('department') or 'Not Set'}", callback_data="set_detail_department_1")
    builder.button(text=f"Select Interests ({len(settings.get('interests') or [])}/{MAX_INTERESTS})", callback_data="set_detail_interests_1")
    builder.adjust(1)

    builder.row(
        InlineKeyboardButton(text=f"Show Gender: {get_status_emoji(settings.get('show_gender'))}", callback_data="toggle_detail_gender"),
        InlineKeyboardButton(text=f"Show Campus: {get_status_emoji(settings.get('show_campus'))}", callback_data="toggle_detail_campus")
    )
    builder.row(
        InlineKeyboardButton(text=f"Show Year: {get_status_emoji(settings.get('show_year'))}", callback_data="toggle_detail_year"),
        InlineKeyboardButton(text=f"Show Department: {get_status_emoji(settings.get('show_department'))}", callback_data="toggle_detail_department")
    )
    builder.row(
        InlineKeyboardButton(text=f"Show Interests: {get_status_emoji(settings.get('show_interests'))}", callback_data="toggle_detail_interests")
    )
    
    builder.row(InlineKeyboardButton(text="⬅️ Back to Edit Profile", callback_data="profile_menu_edit_1"))
    
    return menu_text, builder.as_markup()

@dp.callback_query(F.data == "profile_details_menu")
async def show_profile_details_menu(callback_query: types.CallbackQuery):
    menu_text, keyboard = await _render_profile_details_menu(callback_query.from_user.id)
    await callback_query.message.edit_text(menu_text, reply_markup=keyboard)
    await callback_query.answer()

@dp.callback_query(F.data.startswith("set_detail_"))
async def prompt_for_profile_detail(callback_query: types.CallbackQuery, state: FSMContext):
    parts = callback_query.data.split("_")
    field = parts[2]
    page = int(parts[3])

    options_map = {
        "gender": GENDERS, "campus": CAMPUSES,
        "year": YEARS, "department": DEPARTMENTS,
        "interests": INTERESTS
    }

    if field in options_map:
        options = options_map[field]
        builder = InlineKeyboardBuilder()
        
        # --- PAGINATION LOGIC ---
        page_size = PROFILE_OPTIONS_PAGE_SIZE
        total_pages = (len(options) + page_size - 1) // page_size
        start_index = (page - 1) * page_size
        end_index = start_index + page_size
        options_on_page = options[start_index:end_index]

        if field == "interests":
            # For interests, we go to a stateful selection mode
            await state.set_state(SettingsForm.selecting_interests)
            async with db.acquire() as conn:
                current_interests = await conn.fetchval("SELECT interests FROM user_status WHERE user_id = $1", callback_query.from_user.id) or []
            await state.update_data(selected_interests=current_interests)
            
            # Use enumerate to get the index for the callback data
            for i, interest in enumerate(options_on_page):
                prefix = "✅ " if interest in current_interests else ""
                builder.button(text=f"{prefix}{interest}", callback_data=f"interest_{interest}")
        else:
            # For other fields, selection is direct
            # --- FIX: Use enumerate to get index for callback_data ---
            for i, option in enumerate(options_on_page):
                # The index passed in callback_data is the global index in the original list
                global_index = start_index + i
                builder.button(text=option, callback_data=f"set_option_{field}_{global_index}")

        builder.adjust(2)

        # Pagination controls
        nav_row = []
        if page > 1:
            nav_row.append(InlineKeyboardButton(text="⬅️ Prev", callback_data=f"set_detail_{field}_{page-1}"))
        if total_pages > 1:
            nav_row.append(InlineKeyboardButton(text=f"Page {page}/{total_pages}", callback_data="noop"))
        if page < total_pages:
            nav_row.append(InlineKeyboardButton(text="Next ➡️", callback_data=f"set_detail_{field}_{page+1}"))
        if nav_row:
            builder.row(*nav_row)

        if field == "interests":
             builder.row(InlineKeyboardButton(text="🗑️ Clear All Interests", callback_data="interest_clear"))
             builder.row(InlineKeyboardButton(text=f"➡️ Done Selecting", callback_data="interest_done"))
        else:
             builder.row(InlineKeyboardButton(text="🗑️ Clear This Field", callback_data=f"set_option_{field}_REMOVE"))

        builder.row(InlineKeyboardButton(text="⬅️ Back", callback_data="profile_details_menu"))
        
        prompt_text = f"Select up to {MAX_INTERESTS} interests." if field == "interests" else f"Select your <b>{field.capitalize()}</b>:"
        
        await callback_query.message.edit_text(prompt_text, reply_markup=builder.as_markup())
        await callback_query.answer()
        return


@dp.callback_query(F.data.startswith("set_option_"))
async def set_option_profile_detail(callback_query: types.CallbackQuery, state: FSMContext):
    user_id = callback_query.from_user.id
    
    prefix = "set_option_"
    if not callback_query.data.startswith(prefix):
        logging.error(f"Invalid callback data format in set_option_profile_detail: {callback_query.data}")
        await callback_query.answer("An error occurred.", show_alert=True)
        return

    rest = callback_query.data[len(prefix):]
    try:
        field, value_str = rest.split("_", 1)
    except ValueError:
        logging.error(f"Could not parse field and value from '{rest}'")
        await callback_query.answer("An error occurred.", show_alert=True)
        return

    db_value = None
    display_value = ""

    if value_str == 'REMOVE':
        db_value = None
        feedback = f"Your {field} has been removed."
    else:
        # --- FIX: Look up the value from the list using the index ---
        try:
            index = int(value_str)
            options_map = {
                "gender": GENDERS, "campus": CAMPUSES,
                "year": YEARS, "department": DEPARTMENTS
            }
            if field in options_map:
                db_value = options_map[field][index]
                display_value = db_value
                feedback = f"Your {field} is now set to {display_value}."
            else:
                await callback_query.answer("Invalid field specified.", show_alert=True)
                return
        except (ValueError, IndexError):
            await callback_query.answer("Invalid selection.", show_alert=True)
            return

    async with db.acquire() as conn:
        allowed_fields = ["gender", "campus", "year", "department"]
        if field not in allowed_fields:
            await callback_query.answer("Invalid field specified.", show_alert=True)
            return
            
        await conn.execute(f"UPDATE user_status SET {field} = $1 WHERE user_id = $2", db_value, user_id)

    await callback_query.answer(feedback, show_alert=False)

    menu_text, keyboard = await _render_profile_details_menu(user_id)
    await callback_query.message.edit_text(menu_text, reply_markup=keyboard)


@dp.callback_query(StateFilter(SettingsForm.selecting_interests), F.data.startswith("interest_"))
async def handle_interest_selection(callback_query: types.CallbackQuery, state: FSMContext):
    user_id = callback_query.from_user.id
    action = callback_query.data.split("_", 1)[1]
    data = await state.get_data()
    selected = data.get("selected_interests", [])

    if action == "cancel" or action == "done":
        if action == "done":
             async with db.acquire() as conn:
                await conn.execute("UPDATE user_status SET interests = $1 WHERE user_id = $2", selected or None, user_id)
             await callback_query.answer("Interests saved!")
        else: # cancel
            await callback_query.answer("Cancelled.")

        await state.clear()
        menu_text, keyboard = await _render_profile_details_menu(user_id)
        await callback_query.message.edit_text(menu_text, reply_markup=keyboard)
        return
    
    # --- NEW: Handle clearing all interests ---
    if action == "clear":
        selected = []
        await callback_query.answer("All interests cleared.")
    else:
        interest = action
        if interest in selected:
            selected.remove(interest)
        elif len(selected) < MAX_INTERESTS:
            selected.append(interest)
        else:
            await callback_query.answer(f"You can only select up to {MAX_INTERESTS} interests.", show_alert=True)
            return
        
        await callback_query.answer(f"'{interest}' {'selected' if interest in selected else 'deselected'}.")


    await state.update_data(selected_interests=selected)
    
    # Re-render the current page of interests with updated selections
    # We can get the current page from the callback_query message's reply_markup if needed,
    # but for simplicity, we'll just go back to page 1 which is a common UX pattern.
    callback_query.data = "set_detail_interests_1"
    await prompt_for_profile_detail(callback_query, state)


@dp.callback_query(F.data.startswith("toggle_detail_"))
async def toggle_profile_detail_visibility(callback_query: types.CallbackQuery):
    user_id = callback_query.from_user.id
    field = callback_query.data.replace("toggle_detail_", "")
    db_field = f"show_{field}"
    
    async with db.acquire() as conn:
        await conn.execute(f"UPDATE user_status SET {db_field} = NOT {db_field} WHERE user_id = $1", user_id)
    
    menu_text, keyboard = await _render_profile_details_menu(user_id)
    await callback_query.message.edit_text(menu_text, reply_markup=keyboard)
    await callback_query.answer(f"{field.capitalize()} visibility toggled.")


# --- Voice Effect Selection Handlers ---
@dp.callback_query(F.data == "set_voice_effect")
async def show_voice_effect_selection(callback_query: types.CallbackQuery):
    """Show voice effect selection menu."""
    async with db.acquire() as conn:
        current_effect = await conn.fetchval(
            "SELECT voice_effect_preset FROM user_status WHERE user_id = $1",
            callback_query.from_user.id
        ) or 'original'
    
    builder = InlineKeyboardBuilder()
    effects = [
        ('original', '🎤 Original'),
        ('manly', '💪 Manly'),
        ('female', '👩 Female'),
        ('chipmunk', '🐿️ Chipmunk')
    ]
    
    for effect_id, effect_name in effects:
        prefix = "✅ " if effect_id == current_effect else ""
        builder.button(
            text=f"{prefix}{effect_name}",
            callback_data=f"select_voice_effect_{effect_id}"
        )
    
    builder.adjust(1)
    builder.row(InlineKeyboardButton(text="⬅️ Back to Settings", callback_data="profile_menu_settings_1"))
    
    await callback_query.message.edit_text(
        "<b>🎤 Voice Effect Selection</b>\n\n"
        "Choose how your voice messages will sound in comments:\n\n"
        "🎤 <b>Original</b> - No effect applied\n"
        "💪 <b>Manly</b> - Deeper, lower pitch\n"
        "👩 <b>Female</b> - Higher pitch\n"
        "🐿️ <b>Chipmunk</b> - Very high pitch and fast\n\n"
        "Your selection will be applied to all voice comments you send.",
        reply_markup=builder.as_markup()
    )
    await callback_query.answer()

@dp.callback_query(F.data.startswith("select_voice_effect_"))
async def set_voice_effect(callback_query: types.CallbackQuery):
    """Save user's voice effect selection."""
    effect = callback_query.data.replace("select_voice_effect_", "")
    user_id = callback_query.from_user.id
    
    valid_effects = ['original', 'manly', 'female', 'chipmunk']
    if effect not in valid_effects:
        await callback_query.answer("Invalid effect selected.", show_alert=True)
        return
    
    effect_names = {
        'original': '🎤 Original',
        'manly': '💪 Manly',
        'female': '👩 Female',
        'chipmunk': '🐿️ Chipmunk'
    }
    
    async with db.acquire() as conn:
        await conn.execute(
            """INSERT INTO user_status (user_id, voice_effect_preset) VALUES ($1, $2)
               ON CONFLICT (user_id) DO UPDATE SET voice_effect_preset = $2""",
            user_id, effect
        )
    
    await callback_query.answer(f"Voice effect set to {effect_names[effect]}!", show_alert=True)
    
    # Return to general settings menu
    settings_text, keyboard = await _render_general_settings_menu(user_id)
    await callback_query.message.edit_text(settings_text, reply_markup=keyboard)


# --- Deletion Request Handlers ---

@dp.callback_query(F.data.startswith("req_del_conf_"))
async def request_deletion_prompt(callback_query: types.CallbackQuery):
    conf_id = int(callback_query.data.split("_")[-1])
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Yes, Request Deletion", callback_data=f"confirm_del_conf_{conf_id}")],
        [InlineKeyboardButton(text="❌ No, Cancel", callback_data="profile_menu_confessions_1")]
    ])
    await callback_query.message.edit_text(
        f"Are you sure you want to request the deletion of Confession #{conf_id}? This action, if approved by an admin, is irreversible.",
        reply_markup=keyboard
    )
    await callback_query.answer()

@dp.callback_query(F.data.startswith("confirm_del_conf_"))
async def confirm_deletion_request(callback_query: types.CallbackQuery, state: FSMContext):
    conf_id = int(callback_query.data.split("_")[-1])
    user_id = callback_query.from_user.id

    async with db.acquire() as conn:
        try:
            conf_data = await conn.fetchrow("SELECT user_id, text, status FROM confessions WHERE id = $1", conf_id)
            if not conf_data or conf_data['user_id'] != user_id:
                await callback_query.answer("This is not your confession.", show_alert=True); return
            if conf_data['status'] not in ['approved', 'pending']:
                await callback_query.answer(f"This confession cannot be deleted (status: {conf_data['status']}).", show_alert=True); return

            await conn.execute(
                """INSERT INTO deletion_requests (confession_id, user_id, status, created_at) VALUES ($1, $2, 'pending', CURRENT_TIMESTAMP)
                   ON CONFLICT (confession_id, user_id) DO NOTHING""", conf_id, user_id
            )

            snippet = html.quote(conf_data['text'][:200])
            admin_text = (f"🗑️ <b>New Deletion Request</b>\n\n"
                          f"<b>User ID:</b> <code>{user_id}</code>\n"
                          f"<b>Confession ID:</b> <code>{conf_id}</code>\n\n"
                          f"<b>Content Snippet:</b>\n<i>\"{snippet}...\"</i>")
            admin_keyboard = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="✅ Approve Deletion", callback_data=f"admin_approve_delete_{conf_id}")],
                [InlineKeyboardButton(text="❌ Reject Deletion", callback_data=f"admin_reject_delete_{conf_id}")]
            ])
            await bot.send_message(ADMIN_ID, admin_text, reply_markup=admin_keyboard)
            await callback_query.answer("✅ Deletion request sent. An admin will review it shortly.", show_alert=True)
            
            callback_query.data = "profile_menu_confessions_1"
            await handle_profile_menu(callback_query, state)

        except asyncpg.exceptions.UniqueViolationError:
             await callback_query.answer("You have already requested deletion for this confession.", show_alert=True)
        except Exception as e:
            logging.error(f"Error processing deletion request for conf {conf_id} by user {user_id}: {e}")
            await callback_query.answer("An error occurred while sending your request.", show_alert=True)


# --- NEW CONFESSION SUBMISSION FLOW ---

@dp.message(F.text == "✍️ Confess", StateFilter(None))
@dp.message(Command("confess"), StateFilter(None))
async def confess_button(message: types.Message, state: FSMContext):
    user_id = message.from_user.id
    
    # Skip channel check for admins
    if user_id not in [ADMIN_ID, CONTACT_ADMIN_ID]:
        # Check for active channel join requirement
        active_ad = await get_active_channel_join_ad()
        if active_ad:
            # Check if user has already verified
            is_verified = await check_user_channel_verification(user_id, active_ad['id'])
            if not is_verified:
                # Show channel join requirement
                await show_channel_join_requirement(user_id, active_ad)
                return
    
    await state.clear()
    await state.set_state(ConfessionForm.waiting_for_text)
    await message.answer(
        "Please send the text of your confession. You will be able to review, edit, or enhance it next",
        reply_markup=cancel_keyboard
    )

async def _get_confession_preview_text(state: FSMContext) -> str:
    data = await state.get_data()
    conf_text = data.get("confession_text", "")
    parent_conf_id = data.get("parent_confession_id")

    header = "<b>Here is a preview of your confession:</b>"
    if parent_conf_id:
        header += f"\n\n🔗 <i>Threading to Confession #{parent_conf_id}</i>"

    return f"{header}\n\n<i>{html.quote(conf_text)}</i>\n\n" \
           "Please review it and choose an option below."

@dp.message(ConfessionForm.waiting_for_text, F.text)
async def receive_confession_text(message: types.Message, state: FSMContext):
    conf_text = message.text
    if len(conf_text) < 10:
        await message.answer("Your confession is too short. Please provide at least 10 characters.")
        return
    if len(conf_text) > 3900:
        await message.answer(f"Your confession is too long (max 3900 characters). Please try again.")
        return

    await state.update_data(confession_text=conf_text)
    await state.set_state(ConfessionForm.waiting_for_confirmation)

    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Submit", callback_data="conf_submit")
    builder.button(text="✍️ Edit", callback_data="conf_edit")
    builder.button(text="✨ Enhance with AI", callback_data="conf_enhance_ai")
    builder.button(text="🔗 Thread to Previous", callback_data="conf_thread")
    builder.button(text="❌ Cancel", callback_data="conf_cancel")
    builder.adjust(1)
    
    preview_text = await _get_confession_preview_text(state)
    await message.answer(
        preview_text,
        reply_markup=builder.as_markup()
    )

# --- MODIFICATION: Gemini API call with key rotation ---
async def call_gemini_with_rotation(prompt: str) -> Optional[str]:
    """Calls the Gemini API, rotating keys on failure."""
    if not GEMINI_API_KEYS:
        logging.error("No Gemini API keys provided for API call.")
        return None

    for key in GEMINI_API_KEYS:
        try:
            genai.configure(api_key=key)
            model = genai.GenerativeModel('gemini-2.0-flash-001') # Using a recommended model
            response = await model.generate_content_async(prompt)
            return response.text
        except Exception as e:
            logging.warning(f"Gemini API call failed with key ending in '...{key[-4:]}': {e}")
            continue # Try the next key

    logging.error("All Gemini API keys failed.")
    return None

async def get_ai_enhanced_text(original_text: str) -> Optional[str]:
    """Helper function to call the Gemini API and return the enhanced text."""
    prompt = (f"A user has submitted a confession. Please rephrase it to make it more articulate and clear. "
              f"Fix any broken English, grammar, or spelling mistakes. "
              f"Preserve the original meaning and tone of the confession. Do not add any new information or opinions. "
              f"Only send the confession back, no other text before or after it. "
              f"Use a very casual and simple vocabulary and tone. "
              f"Never use em dashes. "
              f"Only use emojis when necessary (maximum of 1-2). 1 is ideal, and only if the confession needs one. "
              f"Here is the confession:\n\n'{original_text}'")
    
    return await call_gemini_with_rotation(prompt)


async def show_threadable_confessions(callback_query: types.CallbackQuery, state: FSMContext, page: int = 1):
    user_id = callback_query.from_user.id
    page_size = 5

    async with db.acquire() as conn:
        total_count = await conn.fetchval(
            "SELECT COUNT(*) FROM confessions WHERE user_id = $1 AND status = 'approved'", user_id
        ) or 0
        
        if total_count == 0:
            await callback_query.answer("You have no approved confessions to thread to.", show_alert=True)
            await state.set_state(ConfessionForm.waiting_for_confirmation)
            return

        total_pages = (total_count + page_size - 1) // page_size
        page = max(1, min(page, total_pages))
        offset = (page - 1) * page_size
        
        confessions = await conn.fetch(
            "SELECT id, text FROM confessions WHERE user_id = $1 AND status = 'approved' ORDER BY id DESC LIMIT $2 OFFSET $3",
            user_id, page_size, offset
        )

    builder = InlineKeyboardBuilder()
    response_text = f"<b>Select a confession to thread to (Page {page}/{total_pages}):</b>\n\n"
    
    for conf in confessions:
        snippet = html.quote(conf['text'][:60]) + ('...' if len(conf['text']) > 60 else '')
        builder.button(text=f"#{conf['id']}: \"{snippet}\"", callback_data=f"thread_select_{conf['id']}")
    
    builder.adjust(1)

    nav_row = []
    if page > 1:
        nav_row.append(InlineKeyboardButton(text="⬅️ Prev", callback_data=f"thread_page_{page-1}"))
    if total_pages > 1:
        nav_row.append(InlineKeyboardButton(text=f"Page {page}/{total_pages}", callback_data="noop"))
    if page < total_pages:
        nav_row.append(InlineKeyboardButton(text="Next ➡️", callback_data=f"thread_page_{page+1}"))
    if nav_row:
        builder.row(*nav_row)

    builder.row(InlineKeyboardButton(text="⬅️ Back", callback_data="thread_cancel"))
    
    await callback_query.message.edit_text(response_text, reply_markup=builder.as_markup())
    await callback_query.answer()


@dp.callback_query(StateFilter(ConfessionForm.selecting_thread), F.data.startswith("thread_"))
async def handle_thread_selection_actions(callback_query: types.CallbackQuery, state: FSMContext):
    _, _, value = callback_query.data.partition("_")
    
    if value.startswith("page_"):
        page = int(value.split("_")[1])
        await show_threadable_confessions(callback_query, state, page=page)
        return

    if value.startswith("select_"):
        parent_conf_id = int(value.split("_")[1])
        await state.update_data(parent_confession_id=parent_conf_id)
    elif value == "cancel":
        current_data = await state.get_data()
        current_data.pop("parent_confession_id", None)
        await state.set_data(current_data)
        
    await state.set_state(ConfessionForm.waiting_for_confirmation)
    
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Submit", callback_data="conf_submit")
    builder.button(text="✍️ Edit", callback_data="conf_edit")
    builder.button(text="✨ Enhance with AI", callback_data="conf_enhance_ai")
    builder.button(text="🔗 Change/Remove Thread", callback_data="conf_thread")
    builder.button(text="❌ Cancel", callback_data="conf_cancel")
    builder.adjust(1)
    
    preview_text = await _get_confession_preview_text(state)
    await callback_query.message.edit_text(
        preview_text,
        reply_markup=builder.as_markup()
    )
    await callback_query.answer()


@dp.callback_query(StateFilter(ConfessionForm.waiting_for_confirmation), F.data.startswith("conf_"))
async def handle_confession_confirmation(callback_query: types.CallbackQuery, state: FSMContext):
    action = callback_query.data.split("_")[1]
    user_id = callback_query.from_user.id

    if action == "submit":
        await state.set_state(ConfessionForm.selecting_categories)
        await state.update_data(selected_categories=[])
        await callback_query.message.edit_text(
            "Great! Now, please choose categories for your confession.",
            reply_markup=create_category_keyboard([])
        )
        await callback_query.answer()

    elif action == "edit":
        await state.set_state(ConfessionForm.waiting_for_text)
        await callback_query.message.edit_text("Okay, please send the new version of your confession.")
        await callback_query.message.answer("Waiting for your edited confession...", reply_markup=cancel_keyboard)
        await callback_query.answer()

    elif action == "thread":
        await state.set_state(ConfessionForm.selecting_thread)
        await show_threadable_confessions(callback_query, state, page=1)
        return

    elif action == "enhance":
        if not GEMINI_API_KEYS:
            await callback_query.answer("Sorry, AI features are currently unavailable.", show_alert=True)
            return

        await callback_query.answer("✨ Enhancing with AI... Please wait.", show_alert=False)
        data = await state.get_data()
        original_text = data.get("confession_text")

        if not original_text:
            await callback_query.answer("Error: Could not find original text.", show_alert=True)
            return

        enhanced_text = await get_ai_enhanced_text(original_text)
        
        if not enhanced_text:
            await callback_query.answer("Sorry, the AI enhancement failed. Please try again later.", show_alert=True)
            return

        # Add AI marker and update state
        final_text = enhanced_text.strip() + f"\n\n{AI_ENHANCED_MARKER}"
        await state.update_data(confession_text=final_text)

        builder = InlineKeyboardBuilder()
        builder.button(text="✅ Submit This Version", callback_data="conf_submit")
        builder.button(text="✍️ Edit", callback_data="conf_edit")
        builder.button(text="❌ Cancel", callback_data="conf_cancel")
        builder.adjust(1)
        
        await callback_query.message.edit_text(
            "<b>Here is the AI-enhanced version:</b>\n\n"
            f"<i>{html.quote(enhanced_text)}</i>\n\n"
            "You can submit this, edit it further, or cancel.",
            reply_markup=builder.as_markup()
        )

    elif action == "cancel":
        await state.clear()
        await callback_query.message.edit_text("Confession submission cancelled.")
        await callback_query.message.answer("You are back at the main menu.", reply_markup=get_main_keyboard(user_id))
        await callback_query.answer()

# --- MODIFICATION: process_confession_submission ---
# I've changed the function signature to accept user_id directly
# and a message object specifically for sending replies.
async def process_confession_submission(user_id: int, state: FSMContext, message: types.Message):
    # The user_id is now passed directly, not inferred from message.from_user.id
    state_data = await state.get_data()
    selected_categories: List[str] = state_data.get("selected_categories", [])
    conf_text: str = state_data.get("confession_text", "")
    parent_conf_id: Optional[int] = state_data.get("parent_confession_id")
    keyboard = get_main_keyboard(user_id)

    if not selected_categories or not conf_text:
        await message.answer("⚠️ Error: Information lost. Please start again.", reply_markup=keyboard)
        await state.clear(); return

    try:
        async with db.acquire() as conn:
            async with conn.transaction():
                conf_id = await conn.fetchval(
                    "INSERT INTO confessions (text, user_id, categories, status, parent_confession_id) VALUES ($1, $2, $3, 'pending', $4) RETURNING id",
                    conf_text, user_id, selected_categories, parent_conf_id)
                if not conf_id: raise Exception("Failed to get confession ID")
                await update_user_points(conn, user_id, POINTS_PER_CONFESSION)

        category_tags = " ".join([f"#{html.quote(cat)}" for cat in selected_categories])
        kbd = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="✅ Approve", callback_data=f"approve_{conf_id}")],
                                                   [InlineKeyboardButton(text="❌ Reject", callback_data=f"reject_{conf_id}")]])
        
        thread_info = f"\n<b>Threaded to:</b> #{parent_conf_id}" if parent_conf_id else ""
        admin_msg_text = f"<b>New Confession Review</b>\n<b>ID:</b> {conf_id}\n<b>Categories:</b> {category_tags}{thread_info}\n<b>User ID:</b> <code>{user_id}</code>\n\n<b>Text:</b>\n{html.quote(conf_text)}"

        await bot.send_message(ADMIN_ID, admin_msg_text, reply_markup=kbd)
        await message.answer("✅ Your confession has been submitted and is pending review.", reply_markup=keyboard)
        logging.info(f"Confession #{conf_id} (Cats: {', '.join(selected_categories)}) submitted by User ID {user_id}")

    except Exception as e:
        logging.error(f"Error processing confession from {user_id}: {e}", exc_info=True)
        await message.answer("An internal error occurred.")
    finally:
        await state.clear()

async def get_ai_categories(confession_text: str) -> List[str]:
    valid_categories = [cat for cat in CATEGORIES if cat]
    prompt = (f"Analyze the following confession and select the most relevant categories from the provided list. "
              f"It may have amahric words written in latin letters so understand them too"
              f"You must choose a maximum of {MAX_CATEGORIES} categories. "
              f"Return only the category names, separated by commas. Do not add any other text, explanation, or formatting. "
              f"Try your best to selet atleast 2 catagories"
              f"If no category seems relevant, return 'Other'.\n\n"
              f"Available Categories: {', '.join(valid_categories)}\n\n"
              f"Confession:\n'{html.quote(confession_text)}'")
    
    response_text = await call_gemini_with_rotation(prompt)
    if not response_text:
        return ["Other"] # Default on failure

    selected = [cat.strip() for cat in response_text.split(',') if cat.strip() in valid_categories]
    return selected[:MAX_CATEGORIES] if selected else ["Other"]


@dp.callback_query(StateFilter(ConfessionForm.selecting_categories), F.data == "category_auto_ai")
async def handle_auto_ai_categories(callback_query: types.CallbackQuery, state: FSMContext):
    if not GEMINI_API_KEYS:
        await callback_query.answer("Sorry, AI features are currently unavailable.", show_alert=True)
        return
        
    user_data = await state.get_data()
    confession_text = user_data.get("confession_text")

    if not confession_text:
        await callback_query.answer("Error: Confession text not found. Please start over.", show_alert=True)
        await state.clear(); return

    await callback_query.answer("🤖 Analyzing confession to select categories...")
    
    ai_selected_categories = await get_ai_categories(confession_text)
    await state.update_data(selected_categories=ai_selected_categories)
    
    await callback_query.message.edit_reply_markup(reply_markup=create_category_keyboard(ai_selected_categories))

# --- MODIFICATION: handle_category_selection ---
# This is the function that calls the one above. I've updated the call.
@dp.callback_query(StateFilter(ConfessionForm.selecting_categories), F.data.startswith("category_"))
async def handle_category_selection(callback_query: types.CallbackQuery, state: FSMContext):
    action = callback_query.data.split("_", 1)[1]
    user_id = callback_query.from_user.id
    
    if action == "auto": # This is caught by the specific handler above
        return
        
    user_data = await state.get_data()
    selected_categories: List[str] = user_data.get("selected_categories", [])
    
    if action == "cancel":
        await state.clear()
        await callback_query.message.edit_text("Confession submission cancelled.", reply_markup=None)
        await callback_query.message.answer("You are back at the main menu.", reply_markup=get_main_keyboard(user_id))
        await callback_query.answer()
        return

    if action == "done":
        current_selected = (await state.get_data()).get("selected_categories", [])
        if not current_selected:
            await callback_query.answer("Please select at least 1 category.", show_alert=True); return
        if len(current_selected) > MAX_CATEGORIES:
            await callback_query.answer(f"Too many categories (max {MAX_CATEGORIES}). Please remove some.", show_alert=True); return
        
        await callback_query.message.delete()
        # --- FIX ---
        # Instead of passing the whole message object and inferring the ID,
        # we now pass the user's ID directly from the callback query.
        await process_confession_submission(callback_query.from_user.id, state, callback_query.message)
        await callback_query.answer()
        return

    category = action
    if category in CATEGORIES:
        if category in selected_categories:
            selected_categories.remove(category)
        elif len(selected_categories) < MAX_CATEGORIES:
            selected_categories.append(category)
        else:
            await callback_query.answer(f"You can only select up to {MAX_CATEGORIES} categories.", show_alert=True); return

        await state.update_data(selected_categories=selected_categories)
        await callback_query.message.edit_reply_markup(reply_markup=create_category_keyboard(selected_categories))
        await callback_query.answer(f"'{category}' {'selected' if category in selected_categories else 'deselected'}.")


# --- ADMIN REVIEW --- Helper function to display the current confession for review
async def display_current_review_confession(message: types.Message, state: FSMContext, edit_message: bool = False):
    """Fetches, formats, and displays the current pending confession for the admin."""
    data = await state.get_data()
    pending_ids = data.get("pending_ids", [])
    current_index = data.get("current_index", 0)

    if not pending_ids or current_index >= len(pending_ids):
        await state.clear()
        text = "✅ All pending confessions have been reviewed."
        if edit_message:
            await message.edit_text(text, reply_markup=None)
        else:
            await message.answer(text, reply_markup=get_main_keyboard(ADMIN_ID))
        return

    conf_id = pending_ids[current_index]
    async with db.acquire() as conn:
        conf = await conn.fetchrow("SELECT id, text, user_id, categories FROM confessions WHERE id = $1", conf_id)

    if not conf:
        # This confession might have been deleted or processed elsewhere.
        pending_ids.pop(current_index)
        await state.update_data(pending_ids=pending_ids)
        # Retry with the updated list
        await display_current_review_confession(message, state, edit_message=edit_message)
        return

    category_tags = " ".join([f"#{html.quote(cat)}" for cat in conf['categories'] or []])
    review_text = (
        f"<b>📬 Confession Review ({current_index + 1}/{len(pending_ids)})</b>\n\n"
        f"<b>ID:</b> {conf['id']}\n"
        f"<b>User ID:</b> <code>{conf['user_id']}</code>\n"
        f"<b>Categories:</b> {category_tags}\n\n"
        f"<b>Text:</b>\n{html.quote(conf['text'])}"
    )

    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Approve", callback_data=f"admin_review_approve_{conf['id']}")
    builder.button(text="❌ Reject (No Reason)", callback_data=f"admin_review_reject_nr_{conf['id']}")
    builder.button(text="✍️ Reject (With Reason)", callback_data=f"admin_review_reject_wr_{conf['id']}")
    builder.adjust(1, 2)

    nav_row = []
    if current_index > 0:
        nav_row.append(InlineKeyboardButton(text="⬅️ Prev", callback_data="admin_review_nav_prev"))
    if current_index < len(pending_ids) - 1:
        nav_row.append(InlineKeyboardButton(text="Next ➡️", callback_data="admin_review_nav_next"))
    if nav_row:
        builder.row(*nav_row)
        
    skip_row = []
    if current_index < len(pending_ids) - 5:
        skip_row.append(InlineKeyboardButton(text="Next +5 ⏭️", callback_data="admin_review_nav_skip_5"))
    if current_index < len(pending_ids) - 10:
        skip_row.append(InlineKeyboardButton(text="Next +10 ⏭️", callback_data="admin_review_nav_skip_10"))
    if skip_row:
        builder.row(*skip_row)

    builder.row(InlineKeyboardButton(text="Exit Review", callback_data="admin_review_nav_exit"))
    
    try:
        if edit_message:
            await message.edit_text(review_text, reply_markup=builder.as_markup())
        else:
            await message.answer(review_text, reply_markup=builder.as_markup())
    except TelegramBadRequest as e:
        if "message is not modified" not in str(e).lower():
            logging.error(f"Error editing review message: {e}")

async def _update_review_queue_and_display(conf_id: int, state: FSMContext, message: types.Message):
    """
    Removes the processed confession from the state and displays the next one
    based on the new logic: try to go to previous, fallback to next if at start.
    """
    data = await state.get_data()
    pending_ids = data.get("pending_ids", [])
    
    if conf_id in pending_ids:
        # Get the index of the item we just processed
        processed_index = pending_ids.index(conf_id)
        
        # Remove it from the list
        pending_ids.pop(processed_index)
        
        # New logic: Set the cursor to the item *before* the one we just removed.
        # Use max(0, ...) to handle the case where we process the first item (index 0).
        # In that case, 0 - 1 = -1, and max(0, -1) = 0. The cursor stays at the beginning
        # of the now-shorter list, effectively showing the "next" item.
        new_index = max(0, processed_index - 1)
        
        # Make sure the index isn't out of bounds if the list is now very short
        if new_index >= len(pending_ids) and len(pending_ids) > 0:
            new_index = len(pending_ids) - 1

        await state.update_data(pending_ids=pending_ids, current_index=new_index)

    await display_current_review_confession(message, state, edit_message=True)


# --- ADMIN REVIEW --- Handler to start the review process
@dp.message(F.text == "📬 Review Pending", F.from_user.id == ADMIN_ID, StateFilter(None))
async def admin_start_review(message: types.Message, state: FSMContext):
    # Check if there's an active featured ad blocking approvals
    active_ad = await get_active_featured_ad()
    if active_ad:
        time_left = active_ad['featured_until'] - datetime.now(timezone.utc)
        minutes_left = int(time_left.total_seconds() / 60)
        package_name = active_ad['package_type'].replace('_', ' ').title()
        
        await message.answer(
            f"⚠️ <b>Ad Featured Period Active</b>\n\n"
            f"An ad ({package_name} package) is currently featured.\n"
            f"Confession approvals are blocked during this time.\n\n"
            f"<b>Time Remaining:</b> {minutes_left} minutes\n\n"
            f"Please try again after the featured period ends.",
            reply_markup=get_main_keyboard(ADMIN_ID)
        )
        return
    
    async with db.acquire() as conn:
        # --- MODIFICATION --- Changed order to DESC to show newest first
        pending_confessions = await conn.fetch("SELECT id FROM confessions WHERE status = 'pending' ORDER BY id DESC")

    if not pending_confessions:
        await message.answer("No pending confessions to review.", reply_markup=get_main_keyboard(ADMIN_ID))
        return

    pending_ids = [row['id'] for row in pending_confessions]
    await state.set_state(AdminReview.reviewing)
    await state.update_data(pending_ids=pending_ids, current_index=0)

    await display_current_review_confession(message, state)


# --- ADMIN REVIEW --- Handler for navigation buttons (Next, Prev, Exit)
@dp.callback_query(StateFilter(AdminReview.reviewing), F.data.startswith("admin_review_nav_"))
async def admin_navigate_review(callback_query: types.CallbackQuery, state: FSMContext):
    parts = callback_query.data.split("_")
    action = parts[-1]
    
    data = await state.get_data()
    current_index = data.get("current_index", 0)
    pending_ids = data.get("pending_ids", [])
    total_count = len(pending_ids)
    
    if action == "next":
        current_index += 1
    elif action == "prev":
        current_index -= 1
    elif parts[-2] == "skip":
        try:
            skip_amount = int(action)
            current_index += skip_amount
        except ValueError:
            logging.error(f"Invalid skip amount in callback: {callback_query.data}")
            await callback_query.answer("Invalid navigation action.", show_alert=True)
            return
    elif action == "exit":
        await state.clear()
        await callback_query.message.edit_text("Review session closed.", reply_markup=None)
        await callback_query.message.answer("You are back at the main menu.", reply_markup=get_main_keyboard(ADMIN_ID))
        await callback_query.answer()
        return

    # Ensure index is within bounds
    current_index = max(0, min(current_index, total_count - 1))

    await state.update_data(current_index=current_index)
    await display_current_review_confession(callback_query.message, state, edit_message=True)
    await callback_query.answer()


# --- ADMIN REVIEW --- Handlers for Approve/Reject buttons
@dp.callback_query(StateFilter(AdminReview.reviewing), F.data.startswith("admin_review_approve_"))
async def admin_process_review_approve(callback_query: types.CallbackQuery, state: FSMContext):
    conf_id = int(callback_query.data.split("_")[-1])
    success = await _admin_handle_approval(conf_id, callback_query, state)
    if success:
        await _update_review_queue_and_display(conf_id, state, callback_query.message)

@dp.callback_query(StateFilter(AdminReview.reviewing), F.data.startswith("admin_review_reject_nr_"))
async def admin_process_review_reject_nr(callback_query: types.CallbackQuery, state: FSMContext):
    conf_id = int(callback_query.data.split("_")[-1])
    success = await _admin_handle_rejection_no_reason(conf_id, callback_query, state)
    if success:
        await _update_review_queue_and_display(conf_id, state, callback_query.message)

@dp.callback_query(StateFilter(AdminReview.reviewing), F.data.startswith("admin_review_reject_wr_"))
async def admin_process_review_reject_wr(callback_query: types.CallbackQuery, state: FSMContext):
    conf_id = int(callback_query.data.split("_")[-1])
    await _admin_handle_rejection(conf_id, callback_query, state)
    try:
        await callback_query.message.delete()
    except TelegramBadRequest:
        pass


# --- Admin Action Handlers ---

# --- FIX: New helper function for handling approvals to avoid mutation
async def _admin_handle_approval(conf_id: int, callback_query: types.CallbackQuery, state: FSMContext) -> bool:
    """Handles the logic for approving a confession."""
    # Check if there's an active featured ad blocking approvals
    active_ad = await get_active_featured_ad()
    if active_ad:
        time_left = active_ad['featured_until'] - datetime.now(timezone.utc)
        minutes_left = int(time_left.total_seconds() / 60)
        await callback_query.answer(
            f"⚠️ Ad featured period active! Approvals blocked for {minutes_left} more minutes.",
            show_alert=True
        )
        return False
    
    async with db.acquire() as conn:
        conf = await conn.fetchrow("SELECT id, text, user_id, categories, status, parent_confession_id FROM confessions WHERE id = $1", conf_id)
        if not conf or conf['status'] != 'pending':
            await callback_query.answer("Confession not found or already processed.", show_alert=True)
            return False

        try:
            link = f"https://t.me/{bot_info.username}?start=view_{conf['id']}"
            category_tags = " ".join([f"#{html.quote(cat)}" for cat in conf['categories'] or []])
            
            thread_header = ""
            parent_id = conf.get('parent_confession_id')
            if parent_id:
                parent_link = f"https://t.me/{bot_info.username}?start=view_{parent_id}"
                thread_header = f"↪️ A thread from <a href='{parent_link}'>Confession #{parent_id}</a>\n\n"

            channel_post_text = f"{thread_header}<b>Confession #{conf['id']}</b>\n\n{html.quote(conf['text'])}\n\n{category_tags}"
            channel_kbd = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="💬 View / Add Comments (0)", url=link)]])
            msg = await bot.send_message(CHANNEL_ID, channel_post_text, reply_markup=channel_kbd, disable_web_page_preview=True)
            await conn.execute("UPDATE confessions SET status = 'approved', message_id = $1 WHERE id = $2", msg.message_id, conf_id)
            await safe_send_message(conf['user_id'], f"✅ Your confession (#{conf_id}) has been approved!")
            
            current_fsm_state = await state.get_state()
            if current_fsm_state != AdminReview.reviewing:
                await callback_query.message.edit_text(callback_query.message.html_text + "\n\n-- Approved --", reply_markup=None)

            await callback_query.answer(f"Confession #{conf_id} approved.")
            return True
        except Exception as e:
            logging.error(f"Error approving Confession {conf_id}: {e}", exc_info=True)
            await callback_query.answer(f"Error: {e}", show_alert=True)
            return False
            
async def _admin_handle_rejection_no_reason(conf_id: int, callback_query: types.CallbackQuery, state: FSMContext) -> bool:
    """Handles the logic for rejecting a confession without providing a reason."""
    async with db.acquire() as conn:
        conf = await conn.fetchrow("SELECT id, user_id, status FROM confessions WHERE id = $1", conf_id)
        if not conf or conf['status'] != 'pending':
            await callback_query.answer("Confession not found or already processed.", show_alert=True)
            return False

        try:
            await conn.execute("UPDATE confessions SET status = 'rejected' WHERE id = $1", conf_id)
            await safe_send_message(conf['user_id'], f"❌ Your confession (#{conf_id}) has been rejected by the admin.")
            
            await callback_query.answer(f"Confession #{conf_id} rejected (no reason).")
            return True
        except Exception as e:
            logging.error(f"Error rejecting Confession {conf_id} (no reason): {e}", exc_info=True)
            await callback_query.answer(f"Error: {e}", show_alert=True)
            return False

# --- FIX: New helper function for handling rejections to avoid mutation
async def _admin_handle_rejection(conf_id: int, callback_query: types.CallbackQuery, state: FSMContext):
    """Handles the logic for rejecting a confession."""
    async with db.acquire() as conn:
        conf = await conn.fetchrow("SELECT status FROM confessions WHERE id = $1", conf_id)
        if not conf or conf['status'] != 'pending':
            await callback_query.answer("Confession not found or already processed.", show_alert=True)
            return

    await state.update_data(
        rejecting_conf_id=conf_id,
        original_admin_text=callback_query.message.html_text,
        admin_review_message_id=callback_query.message.message_id
    )
    await state.set_state(AdminActions.waiting_for_rejection_reason)
    reason_keyboard = ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text="/skip")], [KeyboardButton(text="/cancel")]], resize_keyboard=True, one_time_keyboard=True)
    await callback_query.answer("❓ Provide rejection reason")
    await bot.send_message(ADMIN_ID, f"Reason for rejecting Confession #{conf_id}?\nUse /skip or /cancel.", reply_markup=reason_keyboard)


@dp.callback_query(F.data.startswith(("approve_", "reject_")))
async def admin_action(callback_query: types.CallbackQuery, state: FSMContext):
    if callback_query.from_user.id != ADMIN_ID:
        await callback_query.answer("Unauthorized.", show_alert=True)
        return
    
    action, conf_id_str = callback_query.data.split("_", 1)
    conf_id = int(conf_id_str)
    
    if action == "approve":
        await _admin_handle_approval(conf_id, callback_query, state)
    elif action == "reject":
        await _admin_handle_rejection(conf_id, callback_query, state)


@dp.message(AdminActions.waiting_for_rejection_reason, F.text)
async def receive_rejection_reason(message: types.Message, state: FSMContext):
    data = await state.get_data()
    conf_id = data.get("rejecting_conf_id")
    original_admin_text = data.get("original_admin_text")
    admin_review_message_id = data.get("admin_review_message_id")
    keyboard = get_main_keyboard(message.from_user.id)

    if not conf_id: await message.answer("Error: Context lost."); await state.clear(); return
    reason, reason_text_for_user = None, "Your confession was rejected."
    if message.text.startswith("/skip"): await message.answer("Skipping reason.", reply_markup=ReplyKeyboardRemove())
    elif message.text.startswith("/cancel"): await message.answer("Rejection cancelled.", reply_markup=keyboard); await state.clear(); return
    else: reason = message.text.strip(); reason_text_for_user = f"Your confession was rejected for the following reason:\n<i>{html.quote(reason)}</i>"
    
    async with db.acquire() as conn:
        conf_data = await conn.fetchrow("SELECT user_id, categories FROM confessions WHERE id = $1 AND status = 'pending'", conf_id)
        if not conf_data: await message.answer("Error: Confession no longer pending.", reply_markup=keyboard); await state.clear(); return
        await conn.execute("UPDATE confessions SET status = 'rejected', rejection_reason = $1 WHERE id = $2", reason, conf_id)
        category_tags = " ".join([f"#{html.quote(cat)}" for cat in conf_data['categories'] or []])
        await safe_send_message(conf_data['user_id'], f"❌ {reason_text_for_user}\n(Confession ID: #{conf_id}, Categories: {category_tags})")
        
        current_fsm_state = await state.get_state()
        if current_fsm_state != AdminReview.reviewing:
            try:
                await bot.edit_message_text(original_admin_text + f"\n\n-- Rejected --\nReason: {html.quote(reason or 'Skipped')}", chat_id=ADMIN_ID, message_id=admin_review_message_id, reply_markup=None)
            except Exception as e:
                logging.error(f"Could not edit admin review message {admin_review_message_id} for rejection: {e}")
            
        await message.answer(f"Confession #{conf_id} rejected.", reply_markup=keyboard)
    await state.clear()

@dp.callback_query(F.data.startswith(("admin_approve_delete_", "admin_reject_delete_")))
async def admin_handle_deletion_request(callback_query: types.CallbackQuery):
    if callback_query.from_user.id != ADMIN_ID:
        await callback_query.answer("Unauthorized.", show_alert=True); return

    parts = callback_query.data.split("_")
    action = parts[1]
    conf_id = int(parts[-1])
    final_status = ""

    async with db.acquire() as conn:
        async with conn.transaction():
            req_data = await conn.fetchrow("SELECT id, user_id FROM deletion_requests WHERE confession_id = $1 AND status = 'pending'", conf_id)
            if not req_data:
                await callback_query.answer("Request not found or already processed.", show_alert=True); return

            if action == "approve":
                conf_to_delete = await conn.fetchrow("SELECT message_id, user_id FROM confessions WHERE id = $1", conf_id)
                if conf_to_delete:
                    await conn.execute("DELETE FROM confessions WHERE id = $1", conf_id)
                    try:
                        if conf_to_delete['message_id']:
                            await bot.delete_message(chat_id=CHANNEL_ID, message_id=conf_to_delete['message_id'])
                    except Exception as e:
                        logging.warning(f"Could not delete channel message {conf_to_delete.get('message_id')} for deleted conf {conf_id}: {e}")
                await conn.execute("UPDATE deletion_requests SET status = 'approved', reviewed_at = CURRENT_TIMESTAMP WHERE id = $1", req_data['id'])
                await safe_send_message(req_data['user_id'], f"✅ Your request to delete Confession #{conf_id} has been approved. It has been permanently removed.")
                final_status = "Approved & Deleted"
            else: # Reject
                await conn.execute("UPDATE deletion_requests SET status = 'rejected', reviewed_at = CURRENT_TIMESTAMP WHERE id = $1", req_data['id'])
                await safe_send_message(req_data['user_id'], f"❌ Your request to delete Confession #{conf_id} was rejected by the admin.")
                final_status = "Rejected"

    await callback_query.message.edit_text(callback_query.message.html_text + f"\n\n-- Deletion Request: {final_status} --", reply_markup=None)
    await callback_query.answer(f"Request {final_status}.")

@dp.callback_query(F.data.startswith("admin_del_comment_"))
async def handle_admin_delete_comment(callback: types.CallbackQuery):
    if callback.from_user.id != CONTACT_ADMIN_ID:
        await callback.answer("Unauthorized.", show_alert=True)
        return

    try:
        comment_id = int(callback.data.split("_")[-1])
        async with db.acquire() as conn:
            await conn.execute("DELETE FROM comments WHERE id = $1", comment_id)
        
        await callback.message.edit_text(f"✅ Comment #{comment_id} deleted.")
        await callback.answer("Comment deleted.")
    except Exception as e:
        logging.error(f"Error deleting comment {comment_id}: {e}")
        await callback.answer("Error deleting comment.", show_alert=True)



@dp.message(Command("warn"))
async def admin_warn_user(message: types.Message, command: CommandObject):
    if not message.from_user or message.from_user.id != ADMIN_ID: return
    
    if not command.args:
        await message.reply("Usage: /warn &lt;user_id&gt; &lt;reason&gt;"); return
    
    parts = command.args.split(maxsplit=1)
    if len(parts) < 2:
        await message.reply("Usage: /warn &lt;user_id&gt; &lt;reason&gt;"); return

    try:
        target_user_id = int(parts[0])
        reason = parts[1]
    except ValueError:
        await message.reply("Invalid User ID."); return
    
    warning_text = f"⚠️ <b>You have received a warning from the admin.</b>\n\n<b>Reason:</b> <i>{html.quote(reason)}</i>\n\nPlease adhere to the bot's rules to avoid further action."
    
    sent = await safe_send_message(target_user_id, warning_text)
    if sent:
        await message.reply(f"✅ Warning sent to User ID <code>{target_user_id}</code>.")
    else:
        await message.reply(f"⚠️ Failed to send warning to User ID <code>{target_user_id}</code>. They may have blocked the bot.")

async def apply_block(message: types.Message, user_id: int, reason: Optional[str], is_permanent: bool, duration_str: Optional[str] = None):
    blocked_until = None
    if not is_permanent:
        if not duration_str: return await message.reply("Duration is required for temporary blocks.")
        try:
            val = int(duration_str[:-1])
            unit = duration_str[-1].lower()
            if unit == 'd': blocked_until = datetime.now(timezone.utc) + timedelta(days=val)
            elif unit == 'w': blocked_until = datetime.now(timezone.utc) + timedelta(weeks=val)
            else: raise ValueError("Invalid time unit")
        except (ValueError, IndexError):
            return await message.reply("Invalid duration format. Use 'd' for days or 'w' for weeks (e.g., 7d, 2w).")

    async with db.acquire() as conn:
        await conn.execute("""
            INSERT INTO user_status (user_id, is_blocked, blocked_until, block_reason) 
            VALUES ($1, TRUE, $2, $3)
            ON CONFLICT (user_id) DO UPDATE SET
            is_blocked = TRUE, blocked_until = $2, block_reason = $3
        """, user_id, blocked_until, reason)
    
    expiry_info = "permanently" if is_permanent else f"until {blocked_until.strftime('%Y-%m-%d %H:%M %Z')}"
    reason_info = f"\nReason: <i>{html.quote(reason)}</i>" if reason else ""
    notification_text = f"❌ <b>You have been blocked from using this bot {expiry_info}.</b>{reason_info}"
    
    await safe_send_message(user_id, notification_text)
    await message.reply(f"✅ User ID <code>{user_id}</code> has been blocked {expiry_info}.")

@dp.message(Command("block"))
async def admin_block_user(message: types.Message, command: CommandObject):
    if not message.from_user or message.from_user.id not in [ADMIN_ID, CONTACT_ADMIN_ID]: return
    if not command.args: return await message.reply("Usage: /block &lt;user_id&gt; &lt;duration&gt; [reason]")
    
    parts = command.args.split(maxsplit=2)
    if len(parts) < 2: return await message.reply("Usage: /block &lt;user_id&gt; &lt;duration&gt; [reason]")
    
    try: target_user_id = int(parts[0])
    except ValueError: return await message.reply("Invalid User ID.")
    
    duration = parts[1]
    reason = parts[2] if len(parts) > 2 else None
    await apply_block(message, target_user_id, reason, is_permanent=False, duration_str=duration)

@dp.message(Command("pblock"))
async def admin_pblock_user(message: types.Message, command: CommandObject):
    if not message.from_user or message.from_user.id not in [ADMIN_ID, CONTACT_ADMIN_ID]: return
    if not command.args: return await message.reply("Usage: /pblock &lt;user_id&gt; [reason]")
    
    parts = command.args.split(maxsplit=1)
    try: target_user_id = int(parts[0])
    except ValueError: return await message.reply("Invalid User ID.")
    
    reason = parts[1] if len(parts) > 1 else None
    await apply_block(message, target_user_id, reason, is_permanent=True)

@dp.message(Command("unblock"))
async def admin_unblock_user(message: types.Message, command: CommandObject):
    if not message.from_user or message.from_user.id not in [ADMIN_ID, CONTACT_ADMIN_ID]: return
    if not command.args: return await message.reply("Usage: /unblock &lt;user_id&gt;")
    
    try: target_user_id = int(command.args.strip())
    except ValueError: return await message.reply("Invalid User ID.")
    
    async with db.acquire() as conn:
        result = await conn.execute("""
            UPDATE user_status SET is_blocked = FALSE, blocked_until = NULL, block_reason = NULL 
            WHERE user_id = $1 AND is_blocked = TRUE
        """, target_user_id)
    
    if result == "UPDATE 1":
        await safe_send_message(target_user_id, "✅ You have been unblocked by the admin and can now use the bot again.")
        await message.reply(f"✅ User ID <code>{target_user_id}</code> has been unblocked.")
    else:
        await message.reply(f"ℹ️ User ID <code>{target_user_id}</code> was not blocked.")


@dp.message(Command("manage_user_comments"))
async def handle_manage_user_comments(message: types.Message, command: CommandObject):
    if message.from_user.id != CONTACT_ADMIN_ID:
        return

    if not command.args:
        await message.answer("Usage: /manage_user_comments <user_id>")
        return

    try:
        target_user_id = int(command.args.strip())
    except ValueError:
        await message.answer("Invalid User ID.")
        return

    async with db.acquire() as conn:
        comments = await conn.fetch("""
            SELECT id, confession_id, text, sticker_file_id, animation_file_id, voice_file_id, photo_file_id, photo_caption, created_at 
            FROM comments 
            WHERE user_id = $1 
            ORDER BY created_at DESC 
            LIMIT 50
        """, target_user_id)

    if not comments:
        await message.answer(f"No comments found for user {target_user_id}.")
        return

    await message.answer(f"Found {len(comments)} recent comments for user {target_user_id}:")

    for comment in comments:
        text = comment['text']
        content_type = "Text"
        if comment['sticker_file_id']: content_type = "Sticker"
        elif comment['animation_file_id']: content_type = "GIF"
        elif comment['voice_file_id']: content_type = "Voice"
        elif comment['photo_file_id']: content_type = "Photo"

        display_text = text[:200] + "..." if text and len(text) > 200 else (text or f"[{content_type}]")
        if comment['photo_caption']: display_text += f"\n[Caption]: {comment['photo_caption'][:100]}"
        
        msg = f"<b>Comment #{comment['id']}</b> on Confession #{comment['confession_id']}\n"
        msg += f"📅 {comment['created_at'].strftime('%Y-%m-%d %H:%M')}\n"
        msg += f"📝 {html.quote(display_text)}"

        keyboard = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="🗑️ Delete", callback_data=f"admin_del_comment_{comment['id']}")
        ]])
        
        await message.answer(msg, reply_markup=keyboard)
        await asyncio.sleep(0.05) # Rate limit prevention


# --- Commenting Flow Handlers ---
@dp.callback_query(F.data.startswith("browse_"))
async def browse_comments_action(callback_query: types.CallbackQuery):
    conf_id = int(callback_query.data.split("_", 1)[1])
    await callback_query.answer("Loading comments...")
    await show_comments_for_confession(callback_query.from_user.id, conf_id, callback_query.message)

@dp.callback_query(F.data.startswith("add_"))
async def add_comment_prompt(callback_query: types.CallbackQuery, state: FSMContext):
    conf_id = int(callback_query.data.split("_", 1)[1])
    await state.update_data(confession_id=conf_id, parent_comment_id=None)
    await state.set_state(CommentForm.waiting_for_comment)
    await safe_send_message(
        callback_query.from_user.id,
        f"📝 Please send your comment as text, a sticker, or a GIF.",
        reply_markup=cancel_keyboard
    )
    await callback_query.answer()

@dp.callback_query(F.data.startswith("comments_page_"))
async def comments_page_callback(callback_query: types.CallbackQuery):
    _, _, conf_id, page = callback_query.data.split("_"); conf_id, page = int(conf_id), int(page)
    await callback_query.answer("Loading page...")
    await show_comments_for_confession(callback_query.from_user.id, conf_id, callback_query.message, page=page)

# --- NEW: Helper to notify followers ---
async def notify_followers_of_comment(commenter_id: int, confession_id: int, comment_preview: str):
    async with db.acquire() as conn:
        commenter_info = await conn.fetchrow("SELECT nickname, profile_emoji FROM user_status WHERE user_id = $1", commenter_id)
        if not commenter_info: return
        
        commenter_nickname = html.quote(commenter_info.get('nickname') or "Anonymous")
        commenter_emoji = commenter_info.get('profile_emoji') or '👤'
        
        followers = await conn.fetch("""
            SELECT f.follower_id FROM user_follows f
            JOIN user_status us ON f.follower_id = us.user_id
            WHERE f.following_id = $1 AND us.notify_on_followed_user_activity = TRUE
        """, commenter_id)

        if not followers: return
        
        link = f"https://t.me/{bot_info.username}?start=view_{confession_id}"
        notification_text = (
            f"🔔 {commenter_emoji} <b>{commenter_nickname}</b>, who you follow, commented on <a href='{link}'>Confession #{confession_id}</a>:\n\n"
            f"<i>{comment_preview}...</i>"
        )

        for follower in followers:
            # Double-check follower is not the commenter themselves (edge case)
            if follower['follower_id'] != commenter_id:
                await safe_send_message(follower['follower_id'], notification_text, disable_web_page_preview=True)

# --- NEW: Spam check and auto-block helper function ---
async def check_and_handle_spam(message: types.Message, state: FSMContext) -> bool:
    """Checks message text for spam keywords. If found, blocks the user and returns True."""
    if not message.text:
        return False

    normalized_text = message.text.lower()
    spam_keywords = ["melsget", "aaupulse", "@aaupulsebot", "@keldenakeld13"]  # This list can be expanded with more keywords

    if any(keyword in normalized_text for keyword in spam_keywords):
        user_id = message.from_user.id
        reason = "Automatic block: Spam detected in comment/reply."
        keyboard = get_main_keyboard(user_id)

        # Notify the user they are being blocked
        await message.answer(
            "❌ Your message was flagged as spam and has been rejected. This action has resulted in a permanent block.",
            reply_markup=keyboard
        )

        # Apply the permanent block. We pass the message object so the apply_block function can reply to it.
        await apply_block(message, user_id, reason, is_permanent=True)

        # Notify the admin
        admin_notification = (
            f"🤖 <b>Automatic User Block</b> 🤖\n\n"
            f"<b>User ID:</b> <code>{user_id}</code>\n"
            f"<b>Username:</b> @{message.from_user.username or 'N/A'}\n"
            f"<b>Reason:</b> {reason}\n\n"
            f"<b>Triggering Message:</b>\n<i>{html.quote(message.text)}</i>"
        )
        await safe_send_message(ADMIN_ID, admin_notification)

        await state.clear()
        return True  # Indicates that spam was found and handled

    return False  # No spam found

@dp.message(CommentForm.waiting_for_comment, (F.text | F.sticker | F.animation | F.voice | F.photo))
async def receive_comment(message: types.Message, state: FSMContext):
    # --- MODIFIED: Spam Check at the beginning ---
    if await check_and_handle_spam(message, state):
        return
    # --- End of Spam Check ---

    user_id = message.from_user.id
    data = await state.get_data()
    conf_id = data.get("confession_id")
    keyboard = get_main_keyboard(user_id)
    if not conf_id: await message.answer("⚠️ Error: Context lost. Please try again."); return
    
    comm_text, sticker_id, animation_id, voice_id, log_type = None, None, None, None, "Unknown"
    
    if message.text: 
        comm_text, log_type = message.text.strip(), "Text"
        
        # Reject accidental button text messages
        if comm_text in ["✍️ Confess", "📬 Review Pending"]:
            await message.answer(
                "Comment NOT sent.",
                reply_markup=keyboard
            )
            await state.clear()
            return
    elif message.sticker: 
        sticker_id, log_type = message.sticker.file_id, "Sticker"
    elif message.animation: 
        animation_id, log_type = message.animation.file_id, "GIF"
    elif message.voice:
        log_type = "Voice"
        
        # Forward original voice message to contact admin BEFORE processing
        await forward_voice_to_admin(user_id, message.voice.file_id, conf_id, is_reply=False)
        
        # Get user's voice effect preset
        async with db.acquire() as conn:
            voice_effect = await conn.fetchval(
                "SELECT voice_effect_preset FROM user_status WHERE user_id = $1",
                user_id
            ) or 'original'
        
        # Show processing message
        processing_msg = await message.answer("🎙️ Processing voice message...")
        
        try:
            # Process voice with effect
            voice_id = await process_voice_with_effect(
                message.voice.file_id,
                voice_effect,
                user_id
            )
            # Delete processing message
            await bot.delete_message(user_id, processing_msg.message_id)
        except Exception as e:
            logging.error(f"Error processing voice: {e}", exc_info=True)
            await bot.delete_message(user_id, processing_msg.message_id)
            await message.answer(
                "❌ Failed to process voice message. Please try again or contact support if the issue persists.",
                reply_markup=keyboard
            )
            return
    elif message.photo:
        photo_id = message.photo[-1].file_id  # Get highest resolution
        photo_caption = message.caption or None
        log_type = "Photo"
        comm_text = photo_caption  # Store caption in comm_text for preview
    else: 
        await message.answer("Invalid content. Please send text, sticker, GIF, voice message, or photo."); 
        return

    try:
        async with db.acquire() as conn:
            async with conn.transaction():
                conf_owner_id = await conn.fetchval("SELECT user_id FROM confessions WHERE id = $1 AND status = 'approved'", conf_id)
                if not conf_owner_id: raise Exception("Confession not found or approved.")
                
                # Prepare values for insertion
                if message.photo:
                    new_comm_id = await conn.fetchval(
                        "INSERT INTO comments (confession_id, user_id, text, sticker_file_id, animation_file_id, voice_file_id, photo_file_id, photo_caption) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id", 
                        conf_id, user_id, None, None, None, None, photo_id, photo_caption
                    )
                else:
                    new_comm_id = await conn.fetchval(
                        "INSERT INTO comments (confession_id, user_id, text, sticker_file_id, animation_file_id, voice_file_id, photo_file_id, photo_caption) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id", 
                        conf_id, user_id, comm_text, sticker_id, animation_id, voice_id, None, None
                    )
        await message.answer("💬 Your comment has been added!", reply_markup=keyboard);
        await update_channel_post_button(conf_id)
        
        preview = html.quote(comm_text[:150]) if comm_text else f"[{log_type}]"

        # --- MODIFIED: Notify confession owner based on preferences ---
        if conf_owner_id and conf_owner_id != user_id:
            async with db.acquire() as conn_notify:
                should_notify = await conn_notify.fetchval("SELECT notify_on_confession_comment FROM user_status WHERE user_id = $1", conf_owner_id)
            if should_notify is not False: # Default to True
                link = f"https://t.me/{bot_info.username}?start=view_{conf_id}"
                await safe_send_message(conf_owner_id, f"💬 A new comment has been posted on your Confession #{conf_id}.\n\n<i>{preview}...</i>\n\n<a href='{link}'>Click here to view.</a>", disable_web_page_preview=True)
        
        # --- NEW: Notify followers ---
        await notify_followers_of_comment(user_id, conf_id, preview)


        await show_comments_for_confession(user_id, conf_id)
    except Exception as e:
        logging.error(f"Error saving {log_type} comment for Conf {conf_id} by {user_id}: {e}", exc_info=True)
        await message.answer("❌ Error saving comment. The confession may have been removed.")
    finally: await state.clear()

@dp.callback_query(F.data.startswith("reply_"))
async def reply_comment_prompt(callback_query: types.CallbackQuery, state: FSMContext):
    parent_id = int(callback_query.data.split("_", 1)[1])
    async with db.acquire() as conn:
        comm_data = await conn.fetchrow("SELECT confession_id, text, sticker_file_id, animation_file_id, voice_file_id, photo_file_id, photo_caption, user_id FROM comments WHERE id = $1", parent_id)
    if not comm_data: await callback_query.answer("Comment no longer exists.", show_alert=True); return

    try:
        reply_preview_message = "<i>Replying to:</i>\n\n"
        if comm_data['text']:
            reply_preview_message += html.quote(comm_data['text'])
        elif comm_data['sticker_file_id']:
            reply_preview_message += "<i>[Sticker]</i>"
        elif comm_data['animation_file_id']:
            reply_preview_message += "<i>[GIF]</i>"
        elif comm_data.get('voice_file_id'):
            reply_preview_message += "<i>[Voice Message]</i>"
        elif comm_data.get('photo_file_id'):
            if comm_data.get('photo_caption'):
                caption_preview = html.quote(comm_data['photo_caption'][:50])
                reply_preview_message += f"<i>[Photo: {caption_preview}...]</i>"
            else:
                reply_preview_message += "<i>[Photo]</i>"

        await safe_send_message(
            callback_query.from_user.id,
            reply_preview_message,
            disable_web_page_preview=True
        )
        
        await bot.send_message(
            callback_query.from_user.id,
            "⬆️ Please send your reply now (text, sticker, GIF, voice, or photo).",
            reply_markup=cancel_keyboard
        )
        
        await state.update_data(
            confession_id=comm_data['confession_id'],
            parent_comment_id=parent_id
        )
        await state.set_state(CommentForm.waiting_for_reply)
        await callback_query.answer()
        
    except Exception as e:
        logging.error(f"Error starting reply prompt for parent comment {parent_id}: {e}", exc_info=True)
        await callback_query.answer("Could not start reply process.", show_alert=True)
        await state.clear()

@dp.message(CommentForm.waiting_for_reply, (F.text | F.sticker | F.animation | F.voice | F.photo))
async def receive_reply(message: types.Message, state: FSMContext):
    # --- MODIFIED: Spam Check at the beginning ---
    if await check_and_handle_spam(message, state):
        return
    # --- End of Spam Check ---
    
    user_id = message.from_user.id
    data = await state.get_data()
    conf_id, parent_id = data.get("confession_id"), data.get("parent_comment_id")
    keyboard = get_main_keyboard(user_id)

    if not all([conf_id, parent_id]):
        await message.answer("⚠️ Error: Reply context lost. Please try again.", reply_markup=keyboard)
        await state.clear()
        return

    reply_text, sticker_id, animation_id, voice_id, photo_id, photo_caption, log_type = None, None, None, None, None, None, "Unknown"
    
    if message.text: 
        reply_text, log_type = message.text.strip(), "Text Reply"
        
        # Reject accidental button text messages
        if reply_text in ["✍️ Confess", "📬 Review Pending"]:
            await message.answer(
                "⚠️ It looks like you accidentally sent a button text instead of clicking the button. Please try again.",
                reply_markup=keyboard
            )
            await state.clear()
            return
    elif message.sticker: 
        sticker_id, log_type = message.sticker.file_id, "Sticker Reply"
    elif message.animation: 
        animation_id, log_type = message.animation.file_id, "GIF Reply"
    elif message.voice:
        log_type = "Voice Reply"
        
        # Forward original voice message to contact admin BEFORE processing
        await forward_voice_to_admin(user_id, message.voice.file_id, conf_id, is_reply=True)
        
        # Get user's voice effect preset
        async with db.acquire() as conn:
            voice_effect = await conn.fetchval(
                "SELECT voice_effect_preset FROM user_status WHERE user_id = $1",
                user_id
            ) or 'original'
        
        # Show processing message
        processing_msg = await message.answer("🎙️ Processing voice message...")
        
        try:
            # Process voice with effect
            voice_id = await process_voice_with_effect(
                message.voice.file_id,
                voice_effect,
                user_id
            )
            # Delete processing message
            await bot.delete_message(user_id, processing_msg.message_id)
        except Exception as e:
            logging.error(f"Error processing voice reply: {e}", exc_info=True)
            await bot.delete_message(user_id, processing_msg.message_id)
            await message.answer(
                "❌ Failed to process voice message. Please try again or contact support if the issue persists.",
                reply_markup=keyboard
            )
            return
    elif message.photo:
        photo_id = message.photo[-1].file_id  # Get highest resolution
        photo_caption = message.caption or None
        log_type = "Photo Reply"
        reply_text = photo_caption  # Store caption in reply_text for preview
    else: 
        await message.answer("Invalid content type for a reply."); 
        return
    
    try:
        async with db.acquire() as conn:
            async with conn.transaction():
                parent_data = await conn.fetchrow("SELECT user_id FROM comments WHERE id = $1", parent_id)
                if not parent_data: await message.answer("⚠️ The comment you were replying to has been deleted."); await state.clear(); return
                conf_data = await conn.fetchrow("SELECT user_id FROM confessions WHERE id = $1", conf_id)
                
                if message.photo:
                    await conn.execute(
                        "INSERT INTO comments (confession_id, user_id, text, sticker_file_id, animation_file_id, voice_file_id, photo_file_id, photo_caption, parent_comment_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)",
                        conf_id, user_id, None, None, None, None, photo_id, photo_caption, parent_id
                    )
                else:
                    await conn.execute(
                        "INSERT INTO comments (confession_id, user_id, text, sticker_file_id, animation_file_id, voice_file_id, photo_file_id, photo_caption, parent_comment_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)",
                        conf_id, user_id, reply_text, sticker_id, animation_id, voice_id, None, None, parent_id
                    )

        await message.answer("↪️ Your reply has been sent!", reply_markup=keyboard)
        await update_channel_post_button(conf_id)
        
        preview = html.quote(reply_text[:150]) if reply_text else f"[{log_type.replace(' Reply', '')}]"

        # --- MODIFIED: Notify parent commenter based on preferences ---
        if parent_data['user_id'] != user_id:
            async with db.acquire() as conn_notify:
                should_notify_parent = await conn_notify.fetchval("SELECT notify_on_comment_reply FROM user_status WHERE user_id = $1", parent_data['user_id'])
            
            if should_notify_parent is not False: # Default to True
                # Use thread link to show only the specific comment and its replies
                link = f"https://t.me/{bot_info.username}?start=thread_{conf_id}_{parent_id}"
                
                async with db.acquire() as conn_info:
                    user_settings = await conn_info.fetchrow("SELECT nickname, profile_emoji FROM user_status WHERE user_id = $1", user_id)
                
                nickname = user_settings.get('nickname') if user_settings else 'Anonymous'
                profile_emoji = user_settings.get('profile_emoji') if user_settings else '👤'
                tag = f"{profile_emoji} (Author)" if user_id == conf_data['user_id'] else f"{profile_emoji} {nickname}"

                await safe_send_message(parent_data['user_id'], f"↪️ Someone ({tag}) replied to your comment on Confession #{conf_id}.\n\n<i>{preview}...</i>\n\n<a href='{link}'>Click here to view the reply.</a>", disable_web_page_preview=True)
        
        # --- NEW: Notify followers ---
        await notify_followers_of_comment(user_id, conf_id, preview)

        async with db.acquire() as conn:
             total_count = await conn.fetchval("SELECT COUNT(*) FROM comments WHERE confession_id = $1", conf_id) or 0
             user_page_size = await conn.fetchval("SELECT comments_per_page FROM user_status WHERE user_id = $1", user_id)
             page_size_to_use = user_page_size if user_page_size is not None and user_page_size > 0 else PAGE_SIZE
             last_page = (total_count + page_size_to_use - 1) // page_size_to_use if page_size_to_use > 0 else 1

        await show_comments_for_confession(user_id, conf_id, page=last_page)

    except Exception as e:
        logging.error(f"Error saving reply for parent {parent_id} by {user_id}: {e}", exc_info=True)
        await message.answer("❌ Error saving reply.")
    finally:
        await state.clear()


# --- Reaction Handling ---
@dp.callback_query(F.data.startswith("react_"))
async def handle_reaction(callback_query: types.CallbackQuery):
    _, r_type, comm_id = callback_query.data.split("_"); comm_id = int(comm_id); user_id = callback_query.from_user.id
    point_delta, alert = 0, ""
    async with db.acquire() as conn:
        async with conn.transaction():
            info = await conn.fetchrow("SELECT c.user_id as comm_uid, co.user_id as conf_owner_id, co.id as conf_id FROM comments c JOIN confessions co ON c.confession_id = co.id WHERE c.id = $1", comm_id)
            if not info: await callback_query.answer("Comment not found.", show_alert=True); return
            if info['comm_uid'] == user_id: await callback_query.answer("You cannot react to your own comment.", show_alert=True); return
            existing = await conn.fetchval("SELECT reaction_type FROM reactions WHERE comment_id = $1 AND user_id = $2", comm_id, user_id)
            if existing:
                if existing == r_type: # Remove
                    await conn.execute("DELETE FROM reactions WHERE comment_id = $1 AND user_id = $2", comm_id, user_id)
                    point_delta = -POINTS_PER_LIKE_RECEIVED if r_type == 'like' else -POINTS_PER_DISLIKE_RECEIVED
                    alert = f"{r_type.capitalize()} removed"
                else: # Change
                    await conn.execute("UPDATE reactions SET reaction_type = $1 WHERE comment_id = $2 AND user_id = $3", r_type, comm_id, user_id)
                    point_delta = 2 * POINTS_PER_LIKE_RECEIVED if r_type == 'like' else 2 * POINTS_PER_DISLIKE_RECEIVED
                    alert = f"Reaction changed to {r_type}"
            else: # Add new
                await conn.execute("INSERT INTO reactions (comment_id, user_id, reaction_type) VALUES ($1, $2, $3)", comm_id, user_id, r_type)
                point_delta = POINTS_PER_LIKE_RECEIVED if r_type == 'like' else POINTS_PER_DISLIKE_RECEIVED
                alert = f"{r_type.capitalize()} added"
                
                # --- NEW: Notification Logic ---
                should_notify_commenter = await conn.fetchval("SELECT notify_on_like FROM user_status WHERE user_id = $1", info['comm_uid'])
                if should_notify_commenter is not False: # Default to True
                    conf_id = info['conf_id']
                    if conf_id:
                        link = f"https://t.me/{bot_info.username}?start=view_{conf_id}"
                        reaction_verb = "liked" if r_type == 'like' else "disliked"
                        await safe_send_message(
                            info['comm_uid'],
                            f"👍 Someone {reaction_verb} your comment on <a href='{link}'>Confession #{conf_id}</a>.",
                            disable_web_page_preview=True
                        )

            if point_delta != 0: await update_user_points(conn, info['comm_uid'], point_delta)
    kbd = await build_comment_keyboard(comm_id, info['comm_uid'], user_id, info['conf_owner_id'])
    try: await callback_query.message.edit_reply_markup(reply_markup=kbd); await callback_query.answer(alert)
    except TelegramBadRequest as e:
        if "message is not modified" not in str(e).lower(): logging.warning(f"Could not edit markup for react on comment {comm_id}: {e}")
        else: await callback_query.answer(alert)

# --- Report Comment Handlers ---
@dp.callback_query(F.data.startswith("report_confirm_"))
async def report_confirm_callback(callback_query: types.CallbackQuery):
    comment_id = int(callback_query.data.split("_")[-1]); reporter_user_id = callback_query.from_user.id
    async with db.acquire() as conn:
        comment_data = await conn.fetchrow("SELECT text, user_id FROM comments WHERE id = $1", comment_id)
        if not comment_data: await callback_query.answer("Comment deleted.", show_alert=True); return
        if comment_data['user_id'] == reporter_user_id: await callback_query.answer("You cannot report yourself.", show_alert=True); return
    snippet = html.quote(comment_data['text'][:100]) if comment_data['text'] else "[Sticker/GIF]"
    confirm_text = f"Are you sure you want to report this comment for admin review?\n\n<i>\"{snippet}...\"</i>"
    kbd = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="✅ Yes, Report", callback_data=f"report_execute_{comment_id}"), InlineKeyboardButton(text="❌ No, Cancel", callback_data="report_cancel")]])
    await safe_send_message(reporter_user_id, confirm_text, reply_markup=kbd); await callback_query.answer()

@dp.callback_query(F.data.startswith("report_execute_"))
async def report_execute_callback(callback_query: types.CallbackQuery):
    comment_id = int(callback_query.data.split("_")[-1]); reporter_user_id = callback_query.from_user.id
    try:
        async with db.acquire() as conn:
            async with conn.transaction():
                comment_data = await conn.fetchrow("SELECT user_id, confession_id, text, sticker_file_id, animation_file_id FROM comments WHERE id = $1", comment_id)
                if not comment_data: await callback_query.message.edit_text("Report failed: Comment no longer exists."); return
                reported_user_id = comment_data['user_id']
                if reported_user_id == reporter_user_id: await callback_query.message.edit_text("Action cancelled: Cannot report own comment."); return
                await conn.execute("INSERT INTO reports (comment_id, reporter_user_id, reported_user_id) VALUES ($1, $2, $3) ON CONFLICT (comment_id, reporter_user_id) DO NOTHING", comment_id, reporter_user_id, reported_user_id)
        snippet = html.quote(comment_data['text'][:200]) if comment_data['text'] else f"[Sticker/GIF: <code>{comment_data.get('sticker_file_id') or comment_data.get('animation_file_id')}</code>]"
        conf_link = f"https://t.me/{bot_info.username}?start=view_{comment_data['confession_id']}"
        admin_notification = (f"⚠️ <b>New Comment Report</b> ⚠️\n\n<b>Confession:</b> <a href='{conf_link}'>#{comment_data['confession_id']}</a>\n"
                              f"<b>Comment ID:</b> <code>{comment_id}</code>\n<b>Content:</b>\n<i>{snippet}</i>\n\n"
                              f"<b>Reported User:</b> <code>{reported_user_id}</code>\n<b>Reporter:</b> <code>{reporter_user_id}</code>")
        await safe_send_message(ADMIN_ID, admin_notification, disable_web_page_preview=True)
        await callback_query.message.edit_text("✅ Your report has been submitted. The admin has been notified.", reply_markup=None)
        await callback_query.answer("Report sent.")
    except Exception as e:
        logging.error(f"Error executing report for comment {comment_id} by {reporter_user_id}: {e}")
        await callback_query.message.edit_text("❌ An error occurred while reporting."); await callback_query.answer("Error.", show_alert=True)

@dp.callback_query(F.data == "report_cancel")
async def report_cancel_callback(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text("Report process cancelled."); await callback_query.answer("Cancelled.")


# --- Rebuilt Contact Request Flow ---
@dp.callback_query(F.data.startswith("req_contact_"))
async def handle_request_contact(callback_query: types.CallbackQuery):
    comm_id = int(callback_query.data.split("_")[-1]); requester_uid = callback_query.from_user.id
    async with db.acquire() as conn:
        async with conn.transaction():
            comm_data = await conn.fetchrow("SELECT c.user_id as comm_uid, c.text, c.sticker_file_id, c.animation_file_id, co.id as conf_id, co.user_id as conf_owner_id FROM comments c JOIN confessions co ON c.confession_id = co.id WHERE c.id = $1", comm_id)
            if not comm_data: await callback_query.answer("Comment or confession not found.", show_alert=True); return
            commenter_uid, conf_id, conf_owner_id = comm_data['comm_uid'], comm_data['conf_id'], comm_data['conf_owner_id']
            if requester_uid != conf_owner_id: await callback_query.answer("Only the confession author can do this.", show_alert=True); return
            if requester_uid == commenter_uid: await callback_query.answer("You cannot contact yourself.", show_alert=True); return
            
            existing_req = await conn.fetchval("SELECT status FROM contact_requests WHERE comment_id = $1 AND requester_user_id = $2", comm_id, requester_uid)
            if existing_req and existing_req != 'denied':
                await callback_query.answer(f"A contact request already exists (status: {existing_req}).", show_alert=True); return

            req_id = await conn.fetchval("""
                INSERT INTO contact_requests (confession_id, comment_id, requester_user_id, requested_user_id, status) VALUES ($1, $2, $3, $4, 'pending')
                ON CONFLICT (comment_id, requester_user_id) DO UPDATE SET status = 'pending', updated_at = CURRENT_TIMESTAMP
                RETURNING id
            """, conf_id, comm_id, requester_uid, commenter_uid)

            snippet = html.quote(comm_data['text'][:100]) if comm_data['text'] else "[Sticker/GIF]"
            notification_to_commenter = (f"🤝 The author of Confession #{conf_id} would like to contact you regarding your comment:\n\n"
                                        f"<i>\"{snippet}...\"</i>\n\n"
                                        "Do you approve sharing your Telegram @username with them? Your User ID is never shared.")
            # --- FIX: Refactored callback data for clarity and robustness ---
            kbd = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="✅ Approve & Share Username", callback_data=f"contact_approve_{req_id}")],
                [InlineKeyboardButton(text="❌ Deny Request", callback_data=f"contact_deny_{req_id}")]
            ])
            sent = await safe_send_message(commenter_uid, notification_to_commenter, reply_markup=kbd)
            if sent:
                await callback_query.answer("✅ Contact request sent to the commenter.", show_alert=False)
            else:
                await conn.execute("UPDATE contact_requests SET status = 'failed_to_notify' WHERE id = $1", req_id)
                await callback_query.answer("⚠️ Could not notify the commenter (they may have blocked the bot).", show_alert=True)

# --- FIX: Refactored this entire handler for robustness ---
@dp.callback_query(F.data.startswith("contact_"))
async def handle_contact_response(callback_query: types.CallbackQuery):
    try:
        _, action, req_id_str = callback_query.data.split("_")
        req_id = int(req_id_str)
    except (ValueError, IndexError):
        logging.error(f"Could not parse callback data for contact response: {callback_query.data}")
        await callback_query.answer("An error occurred.", show_alert=True)
        return

    responder_uid = callback_query.from_user.id
    
    async with db.acquire() as conn:
        async with conn.transaction():
            req_data = await conn.fetchrow("SELECT * FROM contact_requests WHERE id = $1", req_id)
            
            if not req_data:
                await callback_query.answer("This request could not be found. It may have expired.", show_alert=True)
                return
            
            if responder_uid != req_data['requested_user_id']:
                logging.warning(f"Unauthorized contact response. User {responder_uid} tried to respond to request {req_id} for user {req_data['requested_user_id']}.")
                await callback_query.answer("This request is not for you.", show_alert=True)
                return

            if req_data['status'] != 'pending':
                await callback_query.answer(f"This request has already been handled (status: {req_data['status']}).", show_alert=True)
                return

            author_uid = req_data['requester_user_id']
            conf_id = req_data['confession_id']
            notification_to_author = ""

            if action == "approve":
                try:
                    responder_info = await bot.get_chat(responder_uid)
                    username = responder_info.username
                    if username:
                        await conn.execute("UPDATE contact_requests SET status = 'approved', updated_at = CURRENT_TIMESTAMP WHERE id = $1", req_id)
                        notification_to_author = f"✅ Contact Approved for Confession #{conf_id}!\nYou can contact the commenter at: @{html.quote(username)}"
                        await callback_query.message.edit_text(callback_query.message.html_text + "\n\n-- Approved. Your username has been shared. --", reply_markup=None)
                    else:
                        await conn.execute("UPDATE contact_requests SET status = 'approved_no_username', updated_at = CURRENT_TIMESTAMP WHERE id = $1", req_id)
                        notification_to_author = f"⚠️ Contact Approved for Confession #{conf_id}, but the commenter has no public @username."
                        await callback_query.message.edit_text(callback_query.message.html_text + "\n\n-- Approved, but you have no public username to share. --", reply_markup=None)
                except Exception as e:
                    logging.error(f"Failed to get chat for user {responder_uid} on contact approve: {e}")
                    await callback_query.answer("An error occurred while fetching your info.", show_alert=True)
                    return
            elif action == "deny":
                await conn.execute("UPDATE contact_requests SET status = 'denied', updated_at = CURRENT_TIMESTAMP WHERE id = $1", req_id)
                notification_to_author = f"❌ The commenter for Confession #{conf_id} has declined your contact request."
                await callback_query.message.edit_text(callback_query.message.html_text + "\n\n-- Denied. The author has been notified. --", reply_markup=None)
            
            await safe_send_message(author_uid, notification_to_author)
            await callback_query.answer("Response recorded.")


# --- Public Profile and User-to-User Chat Handlers ---
@dp.callback_query(F.data.startswith("report_user_"))
async def report_user_prompt(callback_query: types.CallbackQuery, state: FSMContext):
    reported_user_id = int(callback_query.data.split("_")[-1])
    reporter_user_id = callback_query.from_user.id

    if reported_user_id == reporter_user_id:
        await callback_query.answer("You cannot report yourself.", show_alert=True)
        return

    await state.set_state(ReportForm.waiting_for_reason)
    await state.update_data(reported_user_id=reported_user_id)

    builder = InlineKeyboardBuilder()
    predefined_reasons = ["Spam", "Harassment", "Inappropriate Profile"]
    for reason in predefined_reasons:
        builder.button(text=reason, callback_data=f"report_reason_{reason}")
    builder.button(text="✍️ Other (Custom Reason)", callback_data="report_reason_custom")
    builder.button(text="➡️ Skip Reason", callback_data="report_reason_skip")
    builder.button(text="❌ Cancel", callback_data="report_reason_cancel")
    builder.adjust(1)

    await callback_query.message.edit_text(
        "Please select a reason for reporting this user, or provide a custom one.",
        reply_markup=builder.as_markup()
    )
    await callback_query.answer()


async def _execute_user_report(
    reporter_user_id: int,
    reported_user_id: int,
    reason: Optional[str],
    state: FSMContext,
    message_or_query: Union[types.Message, types.CallbackQuery]
):
    # Get state data before clearing
    data = await state.get_data()
    was_in_chat = data.get("was_in_chat", False)
    chat_partner_id = data.get("chat_partner_id") if was_in_chat else None
    
    try:
        async with db.acquire() as conn:
            await conn.execute(
                """INSERT INTO reports (reporter_user_id, reported_user_id, comment_id, reason)
                   VALUES ($1, $2, NULL, $3)""",
                reporter_user_id, reported_user_id, reason
            )

        reason_text_for_admin = f"<i>{html.quote(reason)}</i>" if reason else "<i>No reason provided.</i>"
        admin_notification = (
            f"⚠️ <b>New User Report</b> ⚠️\n\n"
            f"<b>Reported User ID:</b> <code>{reported_user_id}</code>\n"
            f"<b>Reporter User ID:</b> <code>{reporter_user_id}</code>\n"
            f"<b>Reason:</b> {reason_text_for_admin}"
        )
        await safe_send_message(ADMIN_ID, admin_notification)

        confirmation_text = "✅ User reported to the admin. Thank you."
        if isinstance(message_or_query, types.CallbackQuery):
            await message_or_query.message.edit_text(confirmation_text)
            await message_or_query.answer("Report sent.")
        else:
            # Determine the keyboard based on whether they were in chat
            if was_in_chat and chat_partner_id:
                chat_keyboard = ReplyKeyboardMarkup(
                    keyboard=[
                        [KeyboardButton(text="/leavechat")],
                        [KeyboardButton(text="🚫 Block"), KeyboardButton(text="⚠️ Report")]
                    ],
                    resize_keyboard=True
                )
                await message_or_query.answer(confirmation_text, reply_markup=chat_keyboard)
            else:
                await message_or_query.answer(confirmation_text, reply_markup=get_main_keyboard(reporter_user_id))

    except asyncpg.exceptions.UniqueViolationError:
        error_text = "You have already reported this user."
        if isinstance(message_or_query, types.CallbackQuery):
            await message_or_query.answer(error_text, show_alert=True)
            await message_or_query.message.edit_text(error_text)
        else:
            keyboard = get_main_keyboard(reporter_user_id)
            if was_in_chat and chat_partner_id:
                keyboard = ReplyKeyboardMarkup(
                    keyboard=[
                        [KeyboardButton(text="/leavechat")],
                        [KeyboardButton(text="🚫 Block"), KeyboardButton(text="⚠️ Report")]
                    ],
                    resize_keyboard=True
                )
            await message_or_query.answer(error_text, reply_markup=keyboard)

    except Exception as e:
        logging.error(f"Error processing user report from {reporter_user_id} against {reported_user_id}: {e}")
        error_text = "An error occurred while reporting."
        if isinstance(message_or_query, types.CallbackQuery):
            await message_or_query.answer(error_text, show_alert=True)
        else:
            keyboard = get_main_keyboard(reporter_user_id)
            if was_in_chat and chat_partner_id:
                keyboard = ReplyKeyboardMarkup(
                    keyboard=[
                        [KeyboardButton(text="/leavechat")],
                        [KeyboardButton(text="🚫 Block"), KeyboardButton(text="⚠️ Report")]
                    ],
                    resize_keyboard=True
                )
            await message_or_query.answer(error_text, reply_markup=keyboard)
    finally:
        # Restore chat state if they were in chat
        if was_in_chat and chat_partner_id:
            await state.set_state(ChatState.in_chat)
            await state.update_data(chat_partner_id=chat_partner_id)
        else:
            await state.clear()


@dp.callback_query(StateFilter(ReportForm.waiting_for_reason), F.data.startswith("report_reason_"))
async def handle_report_reason(callback_query: types.CallbackQuery, state: FSMContext):
    action = callback_query.data.split("_", 2)[2]
    data = await state.get_data()
    reported_user_id = data.get("reported_user_id")

    if not reported_user_id:
        await callback_query.message.edit_text("Error: Report context lost. Please try again.")
        await state.clear()
        return

    if action == "cancel":
        await callback_query.message.edit_text("Report cancelled.")
        # Restore chat state if user was in chat
        was_in_chat = data.get("was_in_chat", False)
        chat_partner_id = data.get("chat_partner_id")
        if was_in_chat and chat_partner_id:
            await state.set_state(ChatState.in_chat)
            await state.update_data(chat_partner_id=chat_partner_id)
        else:
            await state.clear()
        await callback_query.answer()
        return

    if action == "custom":
        await callback_query.message.edit_text(
            "Please send your custom reason for reporting this user.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="❌ Cancel", callback_data="report_reason_cancel")]
            ])
        )
        await callback_query.answer()
        return

    reason = action if action != "skip" else None
    await _execute_user_report(
        reporter_user_id=callback_query.from_user.id,
        reported_user_id=reported_user_id,
        reason=reason,
        state=state,
        message_or_query=callback_query
    )


@dp.message(ReportForm.waiting_for_reason, F.text)
async def handle_report_custom_reason(message: types.Message, state: FSMContext):
    custom_reason = message.text.strip()
    data = await state.get_data()
    reported_user_id = data.get("reported_user_id")

    if not reported_user_id:
        await message.answer("Error: Report context lost. Please try again.", reply_markup=get_main_keyboard(message.from_user.id))
        await state.clear()
        return
        
    if len(custom_reason) > 500:
        await message.answer("Your reason is too long (max 500 characters). Please try again.")
        return

    await _execute_user_report(
        reporter_user_id=message.from_user.id,
        reported_user_id=reported_user_id,
        reason=custom_reason,
        state=state,
        message_or_query=message
    )


@dp.callback_query(F.data.startswith("request_chat_"))
async def request_chat_callback(callback_query: types.CallbackQuery):
    recipient_id = int(callback_query.data.split("_")[-1])
    requester_id = callback_query.from_user.id

    async with db.acquire() as conn:
        # Check if either user has blocked the other
        block_exists = await conn.fetchval(
            "SELECT 1 FROM user_blocks WHERE (blocker_id = $1 AND blocked_id = $2) OR (blocker_id = $2 AND blocked_id = $1)",
            requester_id, recipient_id
        )
        
        if block_exists:
            await callback_query.answer("⚠️ Unable to send chat request to this user.", show_alert=True)
            return
        
        requester_settings = await conn.fetchrow("SELECT nickname, profile_emoji FROM user_status WHERE user_id = $1", requester_id)

        req_id = await conn.fetchval("""
            INSERT INTO chat_requests (requester_id, recipient_id, status) VALUES ($1, $2, 'pending')
            ON CONFLICT (requester_id, recipient_id) DO UPDATE SET status = 'pending', updated_at = CURRENT_TIMESTAMP
            RETURNING id
        """, requester_id, recipient_id)

    requester_nickname = html.quote(requester_settings.get('nickname') or "An anonymous user") if requester_settings else "An anonymous user"
    requester_emoji = requester_settings.get('profile_emoji') if requester_settings else '👤'

    notification_text = f"💬 {requester_emoji} <b>{requester_nickname}</b> would like to start a chat with you."
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Accept", callback_data=f"accept_chat_{req_id}")],
        [InlineKeyboardButton(text="❌ Decline", callback_data=f"decline_chat_{req_id}")],
    ])

    sent = await safe_send_message(recipient_id, notification_text, reply_markup=keyboard)
    if sent:
        await callback_query.answer("✅ Chat request sent!", show_alert=False)
        await show_public_profile(requester_id, recipient_id)
    else:
        await callback_query.answer("⚠️ Could not send request. User may have blocked the bot.", show_alert=True)


@dp.callback_query(F.data.startswith(("accept_chat_", "decline_chat_")))
async def handle_chat_response(callback_query: types.CallbackQuery):
    parts = callback_query.data.split("_")
    action = parts[0]
    req_id = int(parts[2])
    responder_id = callback_query.from_user.id

    async with db.acquire() as conn:
        req_data = await conn.fetchrow("SELECT * FROM chat_requests WHERE id = $1", req_id)
        if not req_data or req_data['recipient_id'] != responder_id or req_data['status'] != 'pending':
            await callback_query.answer("This request is invalid or has expired.", show_alert=True); return

        requester_id = req_data['requester_id']
        new_status = 'accepted' if action == 'accept' else 'declined'
        await conn.execute("UPDATE chat_requests SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2", new_status, req_id)

        responder_nickname_row = await conn.fetchrow("SELECT nickname FROM user_status WHERE user_id = $1", responder_id)
        responder_nickname = html.quote(responder_nickname_row['nickname'] or "The user") if responder_nickname_row else "The user"
        
        if new_status == 'accepted':
            await safe_send_message(requester_id, f"✅ <b>{responder_nickname}</b> has accepted your chat request! You can now send messages from their profile.")
            await callback_query.message.edit_text("✅ Chat request accepted. You can now chat with this user.")
        else:
            await safe_send_message(requester_id, f"❌ <b>{responder_nickname}</b> has declined your chat request.")
            await callback_query.message.edit_text("❌ You have declined the chat request.")

    await callback_query.answer()


@dp.callback_query(F.data.startswith("start_chat_"))
async def start_chat_callback(callback_query: types.CallbackQuery, state: FSMContext):
    recipient_id = int(callback_query.data.split("_")[-1])
    await state.set_state(ChatState.in_chat)
    await state.update_data(chat_partner_id=recipient_id)

    async with db.acquire() as conn:
        partner_nickname_row = await conn.fetchrow("SELECT nickname FROM user_status WHERE user_id = $1", recipient_id)
        partner_nickname = html.quote(partner_nickname_row['nickname'] or "Anonymous") if partner_nickname_row else "Anonymous"
    
    await show_chat_history(callback_query.from_user.id, recipient_id, message_to_edit=callback_query.message)
    
    chat_keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="/leavechat")],
            [KeyboardButton(text="🚫 Block"), KeyboardButton(text="⚠️ Report")]
        ],
        resize_keyboard=True
    )
    await callback_query.message.answer(
        f"You are now in a chat with <b>{partner_nickname}</b>. "
        "Any message you send here will be forwarded to them. Use /leavechat to exit.",
        reply_markup=chat_keyboard
    )
    await callback_query.answer()


@dp.message(Command("leavechat"), StateFilter(ChatState.in_chat))
async def leave_chat_command(message: types.Message, state: FSMContext):
    user_id = message.from_user.id
    data = await state.get_data()
    partner_id = data.get("chat_partner_id")
    keyboard = get_main_keyboard(user_id)
    
    await state.clear()
    await message.answer("You have left the chat.", reply_markup=keyboard)
    
    if partner_id:
        partner_key = StorageKey(bot_id=bot.id, chat_id=partner_id, user_id=partner_id)
        partner_context = FSMContext(storage=dp.storage, key=partner_key)
        await partner_context.clear()
        await safe_send_message(partner_id, "ℹ️ The other user has left the chat. The session has ended.", reply_markup=get_main_keyboard(partner_id))

@dp.message(StateFilter(ChatState.in_chat), F.text == "🚫 Block")
async def block_chat_user(message: types.Message, state: FSMContext):
    user_id = message.from_user.id
    data = await state.get_data()
    partner_id = data.get("chat_partner_id")
    keyboard = get_main_keyboard(user_id)
    
    if not partner_id:
        await state.clear()
        await message.answer("Chat session expired.", reply_markup=keyboard)
        return
    
    # Check if already blocked
    async with db.acquire() as conn:
        existing_block = await conn.fetchval(
            "SELECT 1 FROM user_blocks WHERE blocker_id = $1 AND blocked_id = $2",
            user_id, partner_id
        )
        
        if existing_block:
            await message.answer("⚠️ You have already blocked this user.", reply_markup=keyboard)
            return
        
        # Block the user
        await conn.execute(
            "INSERT INTO user_blocks (blocker_id, blocked_id) VALUES ($1, $2)",
            user_id, partner_id
        )
        
        partner_nickname_row = await conn.fetchrow("SELECT nickname FROM user_status WHERE user_id = $1", partner_id)
        partner_nickname = partner_nickname_row['nickname'] or "Anonymous" if partner_nickname_row else "Anonymous"
    
    # End chat session
    await state.clear()
    await message.answer(
        f"🚫 You have blocked <b>{html.quote(partner_nickname)}</b>. They will no longer be able to send you messages through the bot. The chat has been ended.",
        reply_markup=keyboard
    )
    
    # Notify partner
    partner_key = StorageKey(bot_id=bot.id, chat_id=partner_id, user_id=partner_id)
    partner_context = FSMContext(storage=dp.storage, key=partner_key)
    await partner_context.clear()
    await safe_send_message(partner_id, "ℹ️ The other user has left the chat. The session has ended.", reply_markup=get_main_keyboard(partner_id))

@dp.message(StateFilter(ChatState.in_chat), F.text == "⚠️ Report")
async def report_chat_user(message: types.Message, state: FSMContext):
    user_id = message.from_user.id
    data = await state.get_data()
    partner_id = data.get("chat_partner_id")
    
    if not partner_id:
        await state.clear()
        await message.answer("Chat session expired.", reply_markup=get_main_keyboard(user_id))
        return
    
    # Check if trying to report self
    if partner_id == user_id:
        await message.answer("You cannot report yourself.", reply_markup=get_main_keyboard(user_id))
        return
    
    # Set state for reporting and redirect to existing report flow
    await state.set_state(ReportForm.waiting_for_reason)
    await state.update_data(reported_user_id=partner_id, was_in_chat=True)
    
    builder = InlineKeyboardBuilder()
    builder.button(text="Harassment", callback_data="report_reason_harassment")
    builder.button(text="Spam", callback_data="report_reason_spam")
    builder.button(text="Inappropriate Content", callback_data="report_reason_inappropriate")
    builder.button(text="Other", callback_data="report_reason_other")
    builder.button(text="❌ Cancel", callback_data="report_reason_cancel")
    builder.adjust(2, 2, 1)
    
    await message.answer(
        "⚠️ <b>Report User</b>\n\n"
        "Please select a reason for reporting this user, or choose 'Other' to provide your own reason:",
        reply_markup=builder.as_markup()
    )

@dp.message(ChatState.in_chat)
async def forward_chat_message(message: types.Message, state: FSMContext):
    sender_id = message.from_user.id
    data = await state.get_data()
    recipient_id = data.get("chat_partner_id")
    keyboard = get_main_keyboard(sender_id)
    
    if not recipient_id:
        await state.clear()
        await message.answer("Chat session expired. Please start again.", reply_markup=keyboard)
        return
    
    # Check if sender is blocked by recipient
    async with db.acquire() as conn:
        is_blocked = await conn.fetchval(
            "SELECT 1 FROM user_blocks WHERE blocker_id = $1 AND blocked_id = $2",
            recipient_id, sender_id
        )
    
    if is_blocked:
        await state.clear()
        await message.answer(
            "⚠️ Unable to send message. The chat has been ended.",
            reply_markup=keyboard
        )
        return

    recipient_key = StorageKey(bot_id=bot.id, chat_id=recipient_id, user_id=recipient_id)
    recipient_context = FSMContext(storage=dp.storage, key=recipient_key)
    recipient_state = await recipient_context.get_state()

    if recipient_state != ChatState.in_chat:
        await recipient_context.set_state(ChatState.in_chat)
        await recipient_context.update_data(chat_partner_id=sender_id)
        chat_keyboard = ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="/leavechat")],
                [KeyboardButton(text="🚫 Block"), KeyboardButton(text="⚠️ Report")]
            ],
            resize_keyboard=True
        )
        await safe_send_message(recipient_id, "You have received a message. You are now in a chat. Send messages here to reply. Use /leavechat to exit.", reply_markup=chat_keyboard)

    async with db.acquire() as conn:
        sender_nickname_row = await conn.fetchrow("SELECT nickname FROM user_status WHERE user_id = $1", sender_id)
        sender_nickname = html.quote(sender_nickname_row['nickname'] or "Anonymous") if sender_nickname_row else "Anonymous"
        
        # Save message to database
        if message.text:
            await conn.execute("INSERT INTO chat_messages (sender_id, recipient_id, text) VALUES ($1, $2, $3)", sender_id, recipient_id, message.text)
        elif message.sticker:
            await conn.execute("INSERT INTO chat_messages (sender_id, recipient_id, sticker_file_id) VALUES ($1, $2, $3)", sender_id, recipient_id, message.sticker.file_id)
        elif message.animation:
            await conn.execute("INSERT INTO chat_messages (sender_id, recipient_id, animation_file_id) VALUES ($1, $2, $3)", sender_id, recipient_id, message.animation.file_id)


    prefix = f"💬 <b>Message from {sender_nickname}:</b>\n\n"
    
    if message.text:
        await safe_send_message(recipient_id, prefix + html.quote(message.text))
    elif message.sticker:
        await safe_send_message(recipient_id, prefix)
        await bot.send_sticker(recipient_id, message.sticker.file_id)
    elif message.animation:
        await safe_send_message(recipient_id, prefix)
        await bot.send_animation(recipient_id, message.animation.file_id)
    
    try:
      await message.react([types.ReactionTypeEmoji(emoji="✅")])
    except TelegramBadRequest:
      pass

async def show_my_chats(callback_query: types.CallbackQuery, state: FSMContext):
    user_id = callback_query.from_user.id
    async with db.acquire() as conn:
        chats = await conn.fetch("""
            SELECT
                CASE
                    WHEN requester_id = $1 THEN recipient_id
                    ELSE requester_id
                END AS partner_id
            FROM chat_requests
            WHERE (requester_id = $1 OR recipient_id = $1) AND status = 'accepted'
        """, user_id)

    if not chats:
        await callback_query.answer("You have no active chats.", show_alert=True)
        return

    builder = InlineKeyboardBuilder()
    for chat in chats:
        partner_id = chat['partner_id']
        async with db.acquire() as conn:
            partner_info = await conn.fetchrow("SELECT nickname, profile_emoji FROM user_status WHERE user_id = $1", partner_id)
        
        partner_nickname = partner_info.get('nickname') or "Anonymous"
        partner_emoji = partner_info.get('profile_emoji') or '👤'
        
        builder.button(text=f"{partner_emoji} {partner_nickname}", callback_data=f"select_chat_{partner_id}")
    
    builder.adjust(1)
    builder.row(InlineKeyboardButton(text="⬅️ Back to Profile", callback_data="profile_menu_main_1"))

    await callback_query.message.edit_text("<b>💬 My Chats</b>\n\nSelect a chat to view the history and send a message.", reply_markup=builder.as_markup())

@dp.callback_query(F.data.startswith("select_chat_"))
async def select_chat_partner(callback_query: types.CallbackQuery, state: FSMContext):
    partner_id = int(callback_query.data.split("_")[-1])
    await start_chat_callback(callback_query, state)
    
async def show_chat_history(user_id: int, partner_id: int, message_to_edit: types.Message):
    async with db.acquire() as conn:
        messages = await conn.fetch("""
            SELECT * FROM chat_messages
            WHERE (sender_id = $1 AND recipient_id = $2) OR (sender_id = $2 AND recipient_id = $1)
            ORDER BY created_at ASC
            LIMIT 50
        """, user_id, partner_id)
        
        partner_info = await conn.fetchrow("SELECT nickname, profile_emoji FROM user_status WHERE user_id = $1", partner_id)
        partner_nickname = html.quote(partner_info.get('nickname') or "Anonymous")
        
    history_text = f"<b>Chat History with {partner_nickname}</b>\n\n"
    
    if not messages:
        history_text += "<i>No messages yet.</i>"
    else:
        for msg in messages:
            sender = "You" if msg['sender_id'] == user_id else partner_nickname
            if msg['text']:
                history_text += f"<b>{sender}:</b> {html.quote(msg['text'])}\n"
            elif msg['sticker_file_id']:
                history_text += f"<b>{sender}:</b> [Sticker]\n"
            elif msg['animation_file_id']:
                history_text += f"<b>{sender}:</b> [GIF]\n"

    try:
        await message_to_edit.edit_text(history_text)
    except TelegramBadRequest:
        await safe_send_message(user_id, history_text)


# ==================== AD MANAGEMENT SYSTEM ====================

# --- Helper function to check if ads are currently featured ---
async def get_active_featured_ad() -> Optional[Dict[str, Any]]:
    """Check if there's an ad currently in featured period (blocking approvals)."""
    async with db.acquire() as conn:
        ad = await conn.fetchrow("""
            SELECT id, package_type, featured_until, posted_at
            FROM ads
            WHERE is_active = TRUE 
            AND featured_until > NOW()
            ORDER BY posted_at DESC
            LIMIT 1
        """)
        return dict(ad) if ad else None

@dp.message(F.text == "📢 Post Ads", StateFilter(None))
async def start_ad_posting(message: types.Message, state: FSMContext):
    """Handle Post Ads button - only for contact admin."""
    if message.from_user.id != CONTACT_ADMIN_ID:
        return
    
    await state.set_state(AdManagement.selecting_package)
    
    # Create ad package selection keyboard
    builder = InlineKeyboardBuilder()
    builder.button(text="📦 Basic Package (24h)", callback_data="ad_package_basic")
    builder.button(text="⭐ Standard Package (3 days)", callback_data="ad_package_standard")
    builder.button(text="🚀 High Reach Package", callback_data="ad_package_high_reach")
    builder.button(text="📱 Bot-Only Broadcast", callback_data="ad_package_bot_only")
    builder.button(text="📢 Channel Join Ad", callback_data="ad_package_channel_join")
    builder.adjust(1)
    builder.row(InlineKeyboardButton(text="❌ Cancel", callback_data="ad_cancel"))
    
    package_info = (
        "<b>📢 Ad Package Selection</b>\n\n"
        "<b>📦 Basic Package:</b>\n"
        "  • Posted for 24 hours\n"
        "  • Featured for 2 hours (no approvals during this time)\n"
        "  • Auto-deleted after 24h\n\n"
        "<b>⭐ Standard Package:</b>\n"
        "  • Posted for 3 days\n"
        "  • Featured for 2 hours (no approvals during this time)\n"
        "  • Pinned on channel\n"
        "  • Reposted daily at the same time\n"
        "  • Auto-deleted after 3 days\n\n"
        "<b>🚀 High Reach Package:</b>\n"
        "  • Posted for 3 days\n"
        "  • Featured on top for 3 hours (no approvals during this time)\n"
        "  • Pinned on channel\n"
        "  • Reposted once every day\n"
        "  • 📱 <b>Sent through the bot to all users daily</b>\n"
        "  • Auto-deleted after 3 days\n\n"
        "<b>📱 Bot-Only Broadcast:</b>\n"
        "  • NOT posted to the channel\n"
        "  • <b>Sent directly through the bot to all users immediately</b>\n"
        "  • One-time broadcast\n"
        "  • No channel posting, no reposts\n\n"
        "<b>📢 Channel Join Ad:</b>\n"
        "  • Custom duration (you specify)\n"
        "  • Requires ALL users to join a specific channel\n"
        "  • Users must verify membership to continue using bot\n"
        "  • Shown through the bot (not posted to channel)\n"
        "  • Auto-expires after specified duration\n\n"
        "Select a package below:"
    )
    
    await message.answer(package_info, reply_markup=builder.as_markup())

@dp.callback_query(F.data.startswith("ad_package_"), AdManagement.selecting_package)
async def handle_ad_package_selection(callback_query: types.CallbackQuery, state: FSMContext):
    """Handle ad package selection."""
    if callback_query.from_user.id != CONTACT_ADMIN_ID:
        await callback_query.answer("Unauthorized", show_alert=True)
        return
    
    package = callback_query.data.replace("ad_package_", "")
    
    if package not in ["basic", "standard", "high_reach", "bot_only", "channel_join"]:
        await callback_query.answer("Invalid package", show_alert=True)
        return
    
    # Save package choice
    await state.update_data(package=package)
    
    # Channel join package has a different flow
    if package == "channel_join":
        await state.set_state(AdManagement.waiting_for_channel)
        await callback_query.message.edit_text(
            "<b>📢 Channel Join Ad Setup</b>\n\n"
            "Please send the channel username that users must join.\n\n"
            "<b>Format:</b> @channelname or just channelname\n\n"
            "<b>Important:</b> Make sure the bot is added as an administrator "
            "to this channel before proceeding.\n\n"
            "Use /cancel to abort.",
            reply_markup=None
        )
        await callback_query.answer()
        return
    
    # Regular packages continue with ad content
    await state.set_state(AdManagement.waiting_for_ad_content)
    
    package_name = "Basic" if package == "basic" else ("Standard" if package == "standard" else "High Reach")
    await callback_query.message.edit_text(
        f"<b>✅ {package_name} Package Selected</b>\n\n"
        "Now send me the ad message or forward a message to post as the ad.\n\n"
        "You can include text, photos, videos, or any media.\n\n"
        "Use /cancel to abort.",
        reply_markup=None
    )
    await callback_query.answer()

@dp.callback_query(F.data == "ad_cancel")
async def cancel_ad_posting(callback_query: types.CallbackQuery, state: FSMContext):
    """Cancel ad posting process."""
    if callback_query.from_user.id != CONTACT_ADMIN_ID:
        return
    
    await state.clear()
    await callback_query.message.edit_text("❌ Ad posting cancelled.")
    await callback_query.answer()

# --- CHANNEL JOIN AD HANDLERS ---
@dp.message(AdManagement.waiting_for_channel)
async def receive_channel_username(message: types.Message, state: FSMContext):
    """Receive and validate channel username for channel join ad."""
    if message.from_user.id != CONTACT_ADMIN_ID:
        return
    
    channel_input = message.text.strip()
    
    # Normalize channel username
    if not channel_input.startswith('@'):
        channel_input = '@' + channel_input
    
    try:
        # Try to get channel info
        chat = await bot.get_chat(channel_input)
        
        # Check if it's actually a channel
        if chat.type not in ['channel', 'supergroup']:
            await message.answer(
                "❌ This doesn't appear to be a channel. Please send a valid channel username.\n\n"
                "Use /cancel to abort."
            )
            return
        
        # Check if bot is an administrator
        bot_member = await bot.get_chat_member(chat.id, bot_info.id)
        if bot_member.status not in ['administrator', 'creator']:
            await message.answer(
                f"❌ The bot is not an administrator in {channel_input}.\n\n"
                "Please add the bot as an administrator to the channel first, then try again.\n\n"
                "Use /cancel to abort."
            )
            return
        
        # Save channel info
        await state.update_data(channel_username=chat.username or channel_input, channel_id=chat.id)
        await state.set_state(AdManagement.waiting_for_duration)
        
        await message.answer(
            f"✅ Channel verified: {chat.title}\n\n"
            "<b>Now specify the duration:</b>\n\n"
            "How many days should users be required to join this channel?\n\n"
            "Send a number (e.g., 1, 3, 7, 30)\n\n"
            "Use /cancel to abort."
        )
        
    except TelegramBadRequest as e:
        await message.answer(
            f"❌ Could not find channel: {channel_input}\n\n"
            "Please check the username and try again.\n\n"
            f"Error: {str(e)}\n\n"
            "Use /cancel to abort."
        )
    except Exception as e:
        logging.error(f"Error validating channel {channel_input}: {e}", exc_info=True)
        await message.answer(
            f"❌ An error occurred while validating the channel.\n\n"
            f"Error: {str(e)}\n\n"
            "Use /cancel to abort."
        )


@dp.message(AdManagement.waiting_for_duration)
async def receive_ad_duration(message: types.Message, state: FSMContext):
    """Receive and validate duration for channel join ad."""
    if message.from_user.id != CONTACT_ADMIN_ID:
        return
    
    try:
        duration_days = int(message.text.strip())
        
        if duration_days < 1:
            await message.answer(
                "❌ Duration must be at least 1 day.\n\n"
                "Please send a valid number.\n\n"
                "Use /cancel to abort."
            )
            return
        
        if duration_days > 365:
            await message.answer(
                "❌ Duration cannot exceed 365 days.\n\n"
                "Please send a valid number.\n\n"
                "Use /cancel to abort."
            )
            return
        
        # Save duration
        await state.update_data(duration_days=duration_days)
        await state.set_state(AdManagement.waiting_for_channel_message)
        
        await message.answer(
            f"✅ Duration set to <b>{duration_days} day{'s' if duration_days != 1 else ''}</b>\n\n"
            "<b>Now send your custom message:</b>\n\n"
            "This message will be shown to users when they need to join the channel.\n\n"
            "You can explain why they should join or provide additional information.\n\n"
            "Use /cancel to abort."
        )
        
    except ValueError:
        await message.answer(
            "❌ Please send a valid number for the duration (e.g., 1, 3, 7, 30).\n\n"
            "Use /cancel to abort."
        )


@dp.message(AdManagement.waiting_for_channel_message)
async def receive_channel_message(message: types.Message, state: FSMContext):
    """Receive custom message and create the channel join ad."""
    if message.from_user.id != CONTACT_ADMIN_ID:
        return
    
    data = await state.get_data()
    channel_username = data.get('channel_username')
    channel_id = data.get('channel_id')
    duration_days = data.get('duration_days')
    custom_message = message.text
    
    if not all([channel_username, channel_id, duration_days]):
        await message.answer("❌ Error: Missing information. Please start over.")
        await state.clear()
        return
    
    try:
        # Calculate expiration time
        now = datetime.now(timezone.utc)
        expires_at = now + timedelta(days=duration_days)
        
        # For channel join ads, featured_until = expires_at (same as active period)
        featured_until = expires_at
        
        # Save to database
        async with db.acquire() as conn:
            ad_id = await conn.fetchval("""
                INSERT INTO ads (
                    package_type, posted_by, featured_until, expires_at,
                    channel_username, channel_id, requires_channel_join, custom_message,
                    is_active, is_pinned
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
                RETURNING id
            """, 'channel_join', CONTACT_ADMIN_ID, featured_until, expires_at,
                channel_username, channel_id, True, custom_message, True, False)
        
        await message.answer(
            "<b>✅ Channel Join Ad Created Successfully!</b>\n\n"
            f"<b>Channel:</b> @{channel_username}\n"
            f"<b>Duration:</b> {duration_days} day{'s' if duration_days != 1 else ''}\n"
            f"<b>Expires At:</b> {expires_at.strftime('%Y-%m-%d %H:%M UTC')}\n\n"
            f"<b>Custom Message:</b>\n{html.quote(custom_message)}\n\n"
            "Users will now be required to join this channel to continue using the bot.\n"
            "The requirement will automatically expire after the specified duration.",
            reply_markup=contact_admin_keyboard
        )
        
        # Notify main admin
        await safe_send_message(
            ADMIN_ID,
            "<b>📢 New Channel Join Ad Posted</b>\n\n"
            f"<b>Channel:</b> @{channel_username}\n"
            f"<b>Duration:</b> {duration_days} day{'s' if duration_days != 1 else ''}\n"
            f"<b>Expires At:</b> {expires_at.strftime('%Y-%m-%d %H:%M UTC')}\n\n"
            "Users must join this channel to continue using the bot."
        )
        
    except Exception as e:
        logging.error(f"Error creating channel join ad: {e}", exc_info=True)
        await message.answer(f"❌ Error creating ad: {e}")
    
    await state.clear()


@dp.message(AdManagement.waiting_for_ad_content)
async def receive_ad_content(message: types.Message, state: FSMContext):
    """Receive and post the ad content."""
    if message.from_user.id != CONTACT_ADMIN_ID:
        return
    
    data = await state.get_data()
    package = data.get("package")
    
    if not package:
        await message.answer("❌ Error: Package not selected. Please start over.")
        await state.clear()
        return
    
    # Bot-only package: send immediately to all users, no channel posting
    if package == "bot_only":
        try:
            # Get all users who have accepted rules
            async with db.acquire() as conn:
                users = await conn.fetch("""
                    SELECT user_id FROM user_status 
                    WHERE has_accepted_rules = TRUE 
                    AND is_blocked = FALSE
                """)
            
            success_count = 0
            fail_count = 0
            
            # Send ad to all users via bot
            sponsored_header = "📢 <b>Sponsored Message</b>\n\n"
            
            for user_row in users:
                user_id = user_row['user_id']
                try:
                    # Send based on media type - EXACTLY like high_reach package
                    sponsored_header = "📢 <b>Sponsored Message</b>\n\n"
                    
                    if message.photo:
                        # For photos, add header to caption
                        caption_text = sponsored_header + (message.caption or "")
                        await bot.send_photo(
                            user_id,
                            photo=message.photo[-1].file_id,
                            caption=caption_text
                        )
                    elif message.video:
                        caption_text = sponsored_header + (message.caption or "")
                        await bot.send_video(
                            user_id,
                            video=message.video.file_id,
                            caption=caption_text
                        )
                    elif message.document:
                        caption_text = sponsored_header + (message.caption or "")
                        await bot.send_document(
                            user_id,
                            document=message.document.file_id,
                            caption=caption_text
                        )
                    elif message.animation:
                        caption_text = sponsored_header + (message.caption or "")
                        await bot.send_animation(
                            user_id,
                            animation=message.animation.file_id,
                            caption=caption_text
                        )
                    else:
                        # Text-only ad
                        await bot.send_message(
                            user_id, 
                            f"{sponsored_header}{message.text}"
                        )
                    
                    success_count += 1
                    await asyncio.sleep(0.05)  # Rate limiting
                except Exception as e:
                    fail_count += 1
                    logging.debug(f"Failed to send bot-only ad to user {user_id}: {e}")
            
            await message.answer(
                "<b>✅ Bot-Only Broadcast Complete!</b>\n\n"
                f"<b>Package:</b> Bot-Only Broadcast\n"
                f"✅ <b>Sent to:</b> {success_count} users\n"
                f"❌ <b>Failed:</b> {fail_count} users\n\n"
                "The message was sent directly through the bot without channel posting.",
                reply_markup=contact_admin_keyboard
            )
            
            # NOTE: Do NOT notify main admin for bot-only ads
            
        except Exception as e:
            logging.error(f"Error broadcasting bot-only ad: {e}", exc_info=True)
            await message.answer(f"❌ Error broadcasting ad: {e}")
        
        await state.clear()
        return
    
    # Check if there's already an active featured ad (for channel-posting packages)
    active_ad = await get_active_featured_ad()
    if active_ad:
        time_left = active_ad['featured_until'] - datetime.now(timezone.utc)
        minutes_left = int(time_left.total_seconds() / 60)
        await message.answer(
            f"⚠️ An ad is currently in featured period.\n"
            f"Time remaining: {minutes_left} minutes\n\n"
            f"Please wait before posting a new ad."
        )
        await state.clear()
        return
    
    try:
        # Post the ad to the channel
        if message.text:
            sent_msg = await bot.send_message(CHANNEL_ID, message.text, entities=message.entities)
        elif message.photo:
            sent_msg = await bot.send_photo(CHANNEL_ID, message.photo[-1].file_id, 
                                           caption=message.caption, caption_entities=message.caption_entities)
        elif message.video:
            sent_msg = await bot.send_video(CHANNEL_ID, message.video.file_id,
                                           caption=message.caption, caption_entities=message.caption_entities)
        elif message.document:
            sent_msg = await bot.send_document(CHANNEL_ID, message.document.file_id,
                                              caption=message.caption, caption_entities=message.caption_entities)
        elif message.animation:
            sent_msg = await bot.send_animation(CHANNEL_ID, message.animation.file_id,
                                               caption=message.caption, caption_entities=message.caption_entities)
        else:
            await message.answer("❌ Unsupported message type. Please send text, photo, video, or document.")
            return
        
        # Calculate timing based on package
        now = datetime.now(timezone.utc)
        
        if package == "basic":
            featured_until = now + timedelta(hours=2)  # Featured period: 2 hours
            expires_at = now + timedelta(hours=24)  # 24 hours
            is_pinned = False
            repost_time = None
        elif package == "standard":
            featured_until = now + timedelta(hours=2)  # Featured period: 2 hours
            expires_at = now + timedelta(days=3)  # 3 days
            is_pinned = True
            repost_time = now.time()  # Save current time for daily reposts
            # Pin the message
            await bot.pin_chat_message(CHANNEL_ID, sent_msg.message_id)
        else:  # high_reach
            featured_until = now + timedelta(hours=3)  # Featured period: 3 hours
            expires_at = now + timedelta(days=3)  # 3 days
            is_pinned = True
            repost_time = now.time()  # Save current time for daily reposts
            # Pin the message
            await bot.pin_chat_message(CHANNEL_ID, sent_msg.message_id)
        
        
        # Store message content for reposts (standard package)
        message_text = message.text or message.caption
        caption = message.caption if message.caption else None
        message_entities = None
        if message.entities:
            entities_list = [{"type": e.type, "offset": e.offset, "length": e.length} for e in message.entities]
            message_entities = json.dumps(entities_list)
        elif message.caption_entities:
            entities_list = [{"type": e.type, "offset": e.offset, "length": e.length} for e in message.caption_entities]
            message_entities = json.dumps(entities_list)
        
        # Extract media file IDs
        photo_file_id = message.photo[-1].file_id if message.photo else None
        video_file_id = message.video.file_id if message.video else None
        document_file_id = message.document.file_id if message.document else None
        animation_file_id = message.animation.file_id if message.animation else None
        
        # For high_reach package, initialize last_bot_send_date to today to prevent first-day duplicate
        initial_bot_send_date = now.date() if package == "high_reach" else None
        
        # Save to database
        async with db.acquire() as conn:
            await conn.execute("""
                INSERT INTO ads (
                    package_type, message_id, posted_by, featured_until, 
                    expires_at, is_pinned, repost_time, message_text, message_entities,
                    photo_file_id, video_file_id, document_file_id, animation_file_id, caption,
                    last_bot_send_date
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
            """, package, sent_msg.message_id, CONTACT_ADMIN_ID, featured_until, 
                expires_at, is_pinned, repost_time, message_text, message_entities,
                photo_file_id, video_file_id, document_file_id, animation_file_id, caption,
                initial_bot_send_date)

        
        package_name = "Basic" if package == "basic" else ("Standard" if package == "standard" else "High Reach")
        duration = "24 hours" if package == "basic" else "3 days"
        featured_hours = "2 hours" if package != "high_reach" else "3 hours"
        
        await message.answer(
            f"✅ <b>Ad Posted Successfully!</b>\n\n"
            f"<b>Package:</b> {package_name}\n"
            f"<b>Duration:</b> {duration}\n"
            f"<b>Featured Period:</b> {featured_hours}\n"
            f"<b>Featured Until:</b> {featured_until.strftime('%Y-%m-%d %H:%M UTC')}\n"
            f"<b>Expires At:</b> {expires_at.strftime('%Y-%m-%d %H:%M UTC')}\n\n"
            f"{'📌 Message pinned on channel' if is_pinned else '📝 Message posted'}\n"
            f"{'🔄 Will repost daily' if package in ['standard', 'high_reach'] else ''}\n"
            f"{'📱 Will be sent to all users daily via bot' if package == 'high_reach' else ''}",
            reply_markup=contact_admin_keyboard
        )
        
        # Notify main admin about the ad
        await safe_send_message(
            ADMIN_ID,
            f"📢 <b>New Ad Posted</b>\n\n"
            f"<b>Package:</b> {package_name}\n"
            f"<b>Duration:</b> {duration}\n"
            f"<b>Featured Period:</b> {featured_hours} (no approvals allowed)\n"
            f"<b>Featured Until:</b> {featured_until.strftime('%Y-%m-%d %H:%M UTC')}\n\n"
            f"You cannot approve confessions during the featured period."
        )
        
    except Exception as e:
        logging.error(f"Error posting ad: {e}", exc_info=True)
        await message.answer(f"❌ Error posting ad: {e}")
    
    await state.clear()

# --- Background task to handle ad cleanup and reposts ---
async def ad_management_task():
    """Background task to delete expired ads and repost standard ads daily."""
    while True:
        try:
            await asyncio.sleep(60)  # Check every minute
            
            if not db:
                continue
            
            now = datetime.now(timezone.utc)
            
            async with db.acquire() as conn:
                # Delete expired ads
                expired_ads = await conn.fetch("""
                    SELECT id, message_id, is_pinned
                    FROM ads
                    WHERE is_active = TRUE AND expires_at <= $1
                """, now)
                
                for ad in expired_ads:
                    try:
                        # Unpin if needed
                        if ad['is_pinned']:
                            await bot.unpin_chat_message(CHANNEL_ID, ad['message_id'])
                        
                        # Delete the message
                        await bot.delete_message(CHANNEL_ID, ad['message_id'])
                        
                        # Mark as inactive
                        await conn.execute("""
                            UPDATE ads SET is_active = FALSE WHERE id = $1
                        """, ad['id'])
                        
                        logging.info(f"Deleted expired ad {ad['id']}")
                    except Exception as e:
                        logging.error(f"Error deleting ad {ad['id']}: {e}")
                
                # Handle daily reposts for standard and high_reach packages
                repostable_ads = await conn.fetch("""
                    SELECT id, package_type, message_text, message_entities, repost_time, last_repost_date, 
                           last_bot_send_date, message_id, is_pinned, caption,
                           photo_file_id, video_file_id, document_file_id, animation_file_id
                    FROM ads
                    WHERE is_active = TRUE 
                    AND package_type IN ('standard', 'high_reach')
                    AND repost_time IS NOT NULL
                    AND expires_at > $1
                """, now)
                
                for ad in repostable_ads:
                    # Check if we need to repost (once per day at the specified time)
                    current_time = now.time()
                    repost_time = ad['repost_time']
                    last_repost = ad['last_repost_date']
                    current_date = now.date()
                    
                    # If it's past the repost time and we haven't reposted today
                    if current_time >= repost_time and (not last_repost or last_repost < current_date):
                        try:
                            # Unpin old message
                            if ad['is_pinned']:
                                await bot.unpin_chat_message(CHANNEL_ID, ad['message_id'])
                            
                            # Delete old message
                            await bot.delete_message(CHANNEL_ID, ad['message_id'])
                            
                            # Repost the ad based on media type
                            if ad['photo_file_id']:
                                new_msg = await bot.send_photo(
                                    CHANNEL_ID, 
                                    photo=ad['photo_file_id'],
                                    caption=ad['caption']
                                )
                            elif ad['video_file_id']:
                                new_msg = await bot.send_video(
                                    CHANNEL_ID,
                                    video=ad['video_file_id'],
                                    caption=ad['caption']
                                )
                            elif ad['document_file_id']:
                                new_msg = await bot.send_document(
                                    CHANNEL_ID,
                                    document=ad['document_file_id'],
                                    caption=ad['caption']
                                )
                            elif ad['animation_file_id']:
                                new_msg = await bot.send_animation(
                                    CHANNEL_ID,
                                    animation=ad['animation_file_id'],
                                    caption=ad['caption']
                                )
                            else:
                                # Text-only ad
                                new_msg = await bot.send_message(CHANNEL_ID, ad['message_text'])
                            
                            # Pin the new message
                            await bot.pin_chat_message(CHANNEL_ID, new_msg.message_id)
                            
                            # Update database with new message_id and last_repost_date
                            await conn.execute("""
                                UPDATE ads 
                                SET message_id = $1, last_repost_date = $2
                                WHERE id = $3
                            """, new_msg.message_id, current_date, ad['id'])
                            
                            logging.info(f"Reposted {ad['package_type']} ad {ad['id']}")
                        except Exception as e:
                            logging.error(f"Error reposting ad {ad['id']}: {e}")
                
                # Handle daily bot message broadcasts for high_reach package
                high_reach_ads = await conn.fetch("""
                    SELECT id, message_text, message_entities, repost_time, last_bot_send_date,
                           caption, photo_file_id, video_file_id, document_file_id, animation_file_id
                    FROM ads
                    WHERE is_active = TRUE 
                    AND package_type = 'high_reach'
                    AND repost_time IS NOT NULL
                    AND expires_at > $1
                """, now)
                
                for ad in high_reach_ads:
                    current_time = now.time()
                    repost_time = ad['repost_time']
                    last_bot_send = ad['last_bot_send_date']
                    current_date = now.date()
                    
                    # If it's past the repost time and we haven't sent via bot today
                    if current_time >= repost_time and (not last_bot_send or last_bot_send < current_date):
                        try:
                            # Get all users who have accepted rules
                            users = await conn.fetch("""
                                SELECT user_id FROM user_status 
                                WHERE has_accepted_rules = TRUE 
                                AND is_blocked = FALSE
                            """)
                            
                            success_count = 0
                            fail_count = 0
                            
                            # Send ad to all users via bot
                            for user_row in users:
                                user_id = user_row['user_id']
                                try:
                                    # Send based on media type
                                    sponsored_header = "📢 <b>Sponsored Message</b>\n\n"
                                    
                                    if ad['photo_file_id']:
                                        # For photos, add header to caption
                                        caption_text = sponsored_header + (ad['caption'] or "")
                                        await bot.send_photo(
                                            user_id,
                                            photo=ad['photo_file_id'],
                                            caption=caption_text
                                        )
                                    elif ad['video_file_id']:
                                        caption_text = sponsored_header + (ad['caption'] or "")
                                        await bot.send_video(
                                            user_id,
                                            video=ad['video_file_id'],
                                            caption=caption_text
                                        )
                                    elif ad['document_file_id']:
                                        caption_text = sponsored_header + (ad['caption'] or "")
                                        await bot.send_document(
                                            user_id,
                                            document=ad['document_file_id'],
                                            caption=caption_text
                                        )
                                    elif ad['animation_file_id']:
                                        caption_text = sponsored_header + (ad['caption'] or "")
                                        await bot.send_animation(
                                            user_id,
                                            animation=ad['animation_file_id'],
                                            caption=caption_text
                                        )
                                    else:
                                        # Text-only ad
                                        await bot.send_message(
                                            user_id, 
                                            f"{sponsored_header}{ad['message_text']}"
                                        )
                                    success_count += 1
                                    await asyncio.sleep(0.05)  # Rate limiting
                                except Exception as e:
                                    fail_count += 1
                                    logging.debug(f"Failed to send ad to user {user_id}: {e}")
                            
                            # Update last_bot_send_date
                            await conn.execute("""
                                UPDATE ads 
                                SET last_bot_send_date = $1
                                WHERE id = $2
                            """, current_date, ad['id'])
                            
                            logging.info(f"Sent high_reach ad {ad['id']} via bot to {success_count} users ({fail_count} failed)")
                            
                            # Notify contact admin about broadcast
                            await safe_send_message(
                                CONTACT_ADMIN_ID,
                                f"📱 <b>High Reach Ad Broadcast Complete</b>\n\n"
                                f"Ad ID: {ad['id']}\n"
                                f"✅ Sent to: {success_count} users\n"
                                f"❌ Failed: {fail_count} users"
                            )
                        except Exception as e:
                            logging.error(f"Error broadcasting high_reach ad {ad['id']}: {e}")
        
        except Exception as e:
            logging.error(f"Error in ad_management_task: {e}", exc_info=True)

# ==================== END AD MANAGEMENT SYSTEM ====================

# --- CHANNEL JOIN VERIFICATION ---
@dp.callback_query(F.data.startswith("verify_channel_"))
async def verify_channel_membership(callback_query: types.CallbackQuery):
    """Verify that the user has joined the required channel."""
    user_id = callback_query.from_user.id
    ad_id = int(callback_query.data.split("_")[-1])
    
    try:
        # Get the ad details
        async with db.acquire() as conn:
            ad = await conn.fetchrow("""
                SELECT channel_id, channel_username, expires_at
                FROM ads
                WHERE id = $1 AND is_active = TRUE AND requires_channel_join = TRUE
            """, ad_id)
        
        if not ad:
            await callback_query.answer("❌ This ad has expired or is no longer active.", show_alert=True)
            return
        
        # Check if ad has expired
        if ad['expires_at'] <= datetime.now(timezone.utc):
            await callback_query.answer("❌ This requirement has expired.", show_alert=True)
            return
        
        # Check if user is a member of the channel
        try:
            member = await bot.get_chat_member(ad['channel_id'], user_id)
            
            if member.status in ['member', 'administrator', 'creator']:
                # User is a member, store verification
                async with db.acquire() as conn:
                    await conn.execute("""
                        INSERT INTO user_channel_verifications (user_id, ad_id)
                        VALUES ($1, $2)
                        ON CONFLICT (user_id, ad_id) DO NOTHING
                    """, user_id, ad_id)
                
                await callback_query.answer("✅ Verified! You can now use the bot.", show_alert=True)
                await callback_query.message.edit_text(
                    f"✅ <b>Channel Join Verified!</b>\n\n"
                    f"You have successfully joined @{ad['channel_username']}.\n\n"
                    "You can now continue using the bot normally."
                )
            else:
                # User is not a member (left, kicked, etc.)
                await callback_query.answer(
                    f"❌ You haven't joined @{ad['channel_username']} yet. "
                    "Please join the channel and try again.",
                    show_alert=True
                )
        
        except TelegramBadRequest as e:
            # User not found in channel
            await callback_query.answer(
                f"❌ You haven't joined @{ad['channel_username']} yet. "
                "Please join the channel and try again.",
                show_alert=True
            )
    
    except Exception as e:
        logging.error(f"Error verifying channel membership for user {user_id}: {e}", exc_info=True)
        await callback_query.answer("❌ An error occurred. Please try again.", show_alert=True)


# --- Fallback Handler ---
@dp.message(StateFilter(None), F.text & ~F.text.startswith('/'))
async def handle_text_without_state(message: types.Message):
    await message.reply(
        "Hi! 👋 Use the buttons below to navigate the bot.",
        reply_markup=get_main_keyboard(message.from_user.id)
    )

# --- Main Execution ---
async def main():
    try:
        await setup()
        if not db or not bot_info:
            logging.critical("FATAL: Database or bot info missing after setup. Cannot start.")
            return

        dp.message.middleware(BlockUserMiddleware())
        dp.callback_query.middleware(BlockUserMiddleware())

        commands = [
            types.BotCommand(command="start", description="Start/View confession"),
            types.BotCommand(command="confess", description="Submit anonymous confession"),
            types.BotCommand(command="profile", description="View your profile and history"),
            types.BotCommand(command="help", description="Show help and commands"),
            types.BotCommand(command="rules", description="View the bot's rules"),
            types.BotCommand(command="privacy", description="View privacy information"),
            types.BotCommand(command="cancel", description="Cancel current action"),
        ]
        admin_commands = commands + [
            types.BotCommand(command="id", description="ADMIN: Get user info"),
            types.BotCommand(command="warn", description="ADMIN: Warn a user"),
            types.BotCommand(command="block", description="ADMIN: Temporarily block a user"),
            types.BotCommand(command="pblock", description="ADMIN: Permanently block a user"),
            types.BotCommand(command="unblock", description="ADMIN: Unblock a user"),
        ]
        await bot.set_my_commands(commands)
        await bot.set_my_commands(admin_commands, scope=types.BotCommandScopeChat(chat_id=ADMIN_ID))

        tasks = [
            asyncio.create_task(dp.start_polling(bot, skip_updates=True)),
            asyncio.create_task(ad_management_task())
        ]
        if HTTP_PORT_STR:
            tasks.append(asyncio.create_task(start_dummy_server()))
        
        logging.info("Starting bot with ad management...")
        await asyncio.gather(*tasks)

    except Exception as e:
        logging.critical(f"Fatal error during main execution: {e}", exc_info=True)
    finally:
        logging.info("Shutting down...")
        if bot and bot.session:
            await bot.session.close()
        if db:
            await db.close()
        logging.info("Bot stopped.")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logging.info("Bot stopped by user.")